-- Dumping database: creawork
CREATE DATABASE IF NOT EXISTS creawork;
SET NAMES utf8mb4;
USE creawork;

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `whitelist` tinyint(1) NOT NULL DEFAULT 0,
  `priority` int(50) NOT NULL DEFAULT 0,
  `chars` int(10) NOT NULL DEFAULT 1,
  `gems` int(20) NOT NULL DEFAULT 0,
  `discord` varchar(50) NOT NULL DEFAULT '0',
  `license` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `license` (`license`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `accounts` VALUES ('1', '1', '0', '2', '2430', '0', '09dda1ae3be63b9cc0822954d47483339ef574e7');
INSERT INTO `accounts` VALUES ('2', '1', '0', '1', '0', '0', '3d9e4ec82f31f77c0daaf7c37a05e74fd7eadd36');
INSERT INTO `accounts` VALUES ('4', '1', '0', '1', '498970', '0', 'fa81b3b77111a18525a1510ff78076fba773babb');
INSERT INTO `accounts` VALUES ('5', '1', '0', '1', '23231', '0', 'ef5e5e4ad370e9f65984086f207a29b60e267199');
INSERT INTO `accounts` VALUES ('6', '1', '0', '1', '0', '0', '116dd1a5d93561b01c33887a46c3a3acd1adc3ad');
INSERT INTO `accounts` VALUES ('7', '1', '0', '1', '0', '0', 'ff7bd7e82e20180302a542224c7c1b03c2d75764');
INSERT INTO `accounts` VALUES ('8', '1', '0', '1', '0', '0', '49b23a9ba54b1c064d21ba195b2a97b573877576');
INSERT INTO `accounts` VALUES ('9', '1', '0', '1', '0', '0', 'f20f0c3e560b60590641c503cdade61b1af6fcfd');
INSERT INTO `accounts` VALUES ('10', '1', '0', '1', '0', '0', '85e4f87b2ded45c3c399debfcf44bb10314232e3');
INSERT INTO `accounts` VALUES ('11', '1', '0', '1', '0', '0', '7725d29db3d252c4889ca3116064cd5fa2f8d74d');
INSERT INTO `accounts` VALUES ('12', '1', '0', '1', '0', '0', '529407eb0ad6549beaf21673d5179786d7b9f200');
INSERT INTO `accounts` VALUES ('13', '1', '0', '1', '0', '0', '8518c8521276146fd3da01cf061720416fa0ee43');
INSERT INTO `accounts` VALUES ('14', '1', '0', '1', '0', '0', '07d40d427a7f5cf44ccbfb2fbd69f7f09894aeb1');
INSERT INTO `accounts` VALUES ('15', '1', '0', '1', '0', '0', '253d39c97bd9445aeb9c940db89f1036289f9ea8');
INSERT INTO `accounts` VALUES ('16', '1', '0', '1', '0', '0', '4305297ee5b2eaf88a45ca190a773cc356acdbc4');

DROP TABLE IF EXISTS `au_admin_log`;
CREATE TABLE `au_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `action` varchar(70) DEFAULT NULL,
  `hour` varchar(255) DEFAULT NULL,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `banneds`;
CREATE TABLE `banneds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license` varchar(50) NOT NULL,
  `time` int(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `characters`;
CREATE TABLE `characters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license` varchar(50) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `name` varchar(50) DEFAULT 'Individuo',
  `name2` varchar(50) DEFAULT 'Indigente',
  `sex` varchar(1) NOT NULL DEFAULT 'M',
  `prison` int(10) NOT NULL,
  `bank` int(20) NOT NULL DEFAULT 0,
  `medicplan` int(20) NOT NULL DEFAULT 0,
  `blood` int(1) NOT NULL DEFAULT 1,
  `fines` int(20) NOT NULL DEFAULT 0,
  `tracking` int(30) NOT NULL DEFAULT 0,
  `spending` int(20) NOT NULL DEFAULT 0,
  `cardlimit` int(20) NOT NULL DEFAULT 0,
  `cardpassword` int(11) NOT NULL DEFAULT 0,
  `deleted` int(1) NOT NULL DEFAULT 0,
  `created` int(20) NOT NULL DEFAULT 0,
  `paypal` int(11) DEFAULT 0,
  `age` int(11) DEFAULT 20,
  `time` int(11) DEFAULT 0,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `license` (`license`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `characters` VALUES ('1', '09dda1ae3be63b9cc0822954d47483339ef574e7', '295-435', 'Attila', 'Penna', 'M', '0', '267865', '0', '2', '0', '0', '1400', '600', '9677', '0', '0', '0', '32', '0', '0');
INSERT INTO `characters` VALUES ('2', '3d9e4ec82f31f77c0daaf7c37a05e74fd7eadd36', '741-879', 'Not', 'Braga', 'M', '0', '2476', '0', '1', '0', '0', '0', '2000', '1111', '0', '0', '0', '20', '0', '0');
INSERT INTO `characters` VALUES ('3', 'fa81b3b77111a18525a1510ff78076fba773babb', '666-666', 'Dev', 'Tester', 'M', '0', '17452', '0', '2', '0', '0', '0', '0', '0', '0', '0', '0', '23', '0', NULL);
INSERT INTO `characters` VALUES ('4', 'ef5e5e4ad370e9f65984086f207a29b60e267199', '222-777', 'Victor', 'Gagaryn', 'M', '0', '19638638', '0', '2', '0', '0', '1910', '90', '2527', '0', '0', '0', '27', '0', NULL);
INSERT INTO `characters` VALUES ('5', 'ff7bd7e82e20180302a542224c7c1b03c2d75764', '334-530', 'Nego', 'Black', 'M', '0', '5000', '0', '4', '0', '0', '0', '0', '0', '0', '0', '0', '20', '0', NULL);
INSERT INTO `characters` VALUES ('6', '49b23a9ba54b1c064d21ba195b2a97b573877576', '902-893', 'Sertaneijo', 'Silva', 'M', '0', '98660', '0', '4', '0', '0', '1325', '675', '1425', '0', '0', '0', '21', '0', NULL);
INSERT INTO `characters` VALUES ('7', 'f20f0c3e560b60590641c503cdade61b1af6fcfd', '335-410', 'Maya', 'Dellacruz', 'F', '0', '1473', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '20', '0', NULL);
INSERT INTO `characters` VALUES ('8', '85e4f87b2ded45c3c399debfcf44bb10314232e3', '259-423', 'Rubi', 'Beckeer', 'F', '0', '2607', '0', '1', '0', '0', '0', '0', '2025', '0', '0', '0', '20', '0', NULL);
INSERT INTO `characters` VALUES ('9', '7725d29db3d252c4889ca3116064cd5fa2f8d74d', '370-709', 'Lasconne', 'Dusete', 'M', '0', '2747', '0', '4', '0', '0', '0', '0', '0', '0', '0', '0', '23', '0', NULL);
INSERT INTO `characters` VALUES ('10', '529407eb0ad6549beaf21673d5179786d7b9f200', '875-124', 'Shelby', 'Nuu', 'M', '0', '1', '0', '3', '0', '0', '0', '0', '0', '0', '0', '1301609', '20', '0', NULL);
INSERT INTO `characters` VALUES ('11', '09dda1ae3be63b9cc0822954d47483339ef574e7', '900-879', 'Pitbull', 'Jr', 'M', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '20', '0', NULL);
INSERT INTO `characters` VALUES ('12', '8518c8521276146fd3da01cf061720416fa0ee43', '287-360', 'Individuo', 'Indigente', 'M', '0', '5000', '0', '3', '0', '0', '0', '0', '0', '0', '0', '0', '20', '0', NULL);
INSERT INTO `characters` VALUES ('13', '07d40d427a7f5cf44ccbfb2fbd69f7f09894aeb1', '494-063', 'Lkz', 'Koovaks', 'F', '0', '3651', '0', '2', '0', '0', '0', '2000', '1234', '0', '0', '0', '25', '0', NULL);
INSERT INTO `characters` VALUES ('14', '253d39c97bd9445aeb9c940db89f1036289f9ea8', '571-361', 'Individuo', 'Indigente', 'M', '0', '5001', '0', '3', '0', '0', '0', '0', '0', '0', '0', '0', '20', '0', NULL);
INSERT INTO `characters` VALUES ('15', '4305297ee5b2eaf88a45ca190a773cc356acdbc4', '109-407', 'Gaviria', 'Escobar', 'M', '0', '4600', '0', '3', '0', '0', '0', '0', '0', '0', '0', '0', '20', '0', NULL);

DROP TABLE IF EXISTS `chests`;
CREATE TABLE `chests` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Permission` varchar(50) DEFAULT NULL,
  `Weight` int(10) NOT NULL DEFAULT 500,
  `Slots` int(20) NOT NULL DEFAULT 50,
  `Logs` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `chests` VALUES ('1', 'Police', 'Police', '500', '50', '0');
INSERT INTO `chests` VALUES ('2', 'Paramedic', 'Paramedic', '5000', '50', '0');
INSERT INTO `chests` VALUES ('3', 'Paramedic-2', 'Paramedic', '500', '50', '0');
INSERT INTO `chests` VALUES ('4', 'Bennys', 'Bennys', '500', '50', '0');

DROP TABLE IF EXISTS `dependents`;
CREATE TABLE `dependents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Passport` int(10) NOT NULL DEFAULT 0,
  `Dependent` int(10) NOT NULL DEFAULT 0,
  `Name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Passport` (`Passport`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `dependents` VALUES ('1', '6', '8', 'Rubi Beckeer');

DROP TABLE IF EXISTS `electrician`;
CREATE TABLE `electrician` (
  `id` char(50) DEFAULT NULL,
  `profiledata` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `electrician` VALUES ('1', '{"xp":0,"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png","identifier":1,"name":"Attila","level":1}');
INSERT INTO `electrician` VALUES ('2', '{"level":1,"xp":0,"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png","name":"Not","identifier":2}');
INSERT INTO `electrician` VALUES ('3', '{"xp":0,"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png","identifier":3,"name":"Dev","level":1}');
INSERT INTO `electrician` VALUES ('4', '{"identifier":4,"xp":0,"level":1,"name":"Victor","avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png"}');
INSERT INTO `electrician` VALUES ('5', '{"xp":0,"name":"Nego","level":1,"identifier":5,"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png"}');
INSERT INTO `electrician` VALUES ('6', '{"identifier":6,"xp":0,"level":1,"name":"Sertaneijo","avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png"}');
INSERT INTO `electrician` VALUES ('7', '{"level":1,"name":"Maya","xp":0,"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png","identifier":7}');
INSERT INTO `electrician` VALUES ('8', '{"identifier":8,"xp":0,"level":1,"name":"Rubi","avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png"}');
INSERT INTO `electrician` VALUES ('9', '{"xp":0,"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png","identifier":9,"name":"Lasconne","level":1}');
INSERT INTO `electrician` VALUES ('10', '{"xp":0,"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png","identifier":10,"name":"Shelby","level":1}');
INSERT INTO `electrician` VALUES ('12', '{"level":1,"xp":0,"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png","name":"Individuo","identifier":12}');
INSERT INTO `electrician` VALUES ('13', '{"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png","name":"Lkz","identifier":13,"xp":0,"level":1}');
INSERT INTO `electrician` VALUES ('14', '{"avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png","name":"Individuo","identifier":14,"xp":0,"level":1}');
INSERT INTO `electrician` VALUES ('11', '{"level":1,"xp":0,"identifier":11,"name":"Pitbull","avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png"}');
INSERT INTO `electrician` VALUES ('15', '{"identifier":15,"xp":0,"level":1,"name":"Gaviria","avatar":"https://cdn-icons-png.flaticon.com/512/8847/8847419.png"}');

DROP TABLE IF EXISTS `entitydata`;
CREATE TABLE `entitydata` (
  `dkey` varchar(100) NOT NULL,
  `dvalue` longtext DEFAULT NULL,
  PRIMARY KEY (`dkey`),
  KEY `dkey` (`dkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `entitydata` VALUES ('1:g7cross:42PEY253', '{"wheelAngular":{"x":{"1":0.76481992006301,"2":-0.80954056978225,"3":0.80947744846343,"4":0.0,"5":0.0,"0":-0.76478022336959},"y":{"1":-0.0,"2":0.0,"3":-0.0,"4":0.0,"5":0.0,"0":0.0}},"wheel":{"type":1},"colors":{"primary":[5,0,8],"colorType":[142,25],"pearly":81,"wheelColor":88,"secondary":[105,113,135],"smoke":[255,255,255],"xenon":false,"neon":false},"mods":{"1":-1,"2":-1,"3":-1,"4":-1,"5":1,"6":-1,"7":-1,"8":-1,"10":-1,"11":-1,"12":-1,"13":-1,"14":-1,"15":-1,"16":-1,"18":false,"19":-1,"23":-1,"24":-1,"25":-1,"27":-1,"28":-1,"29":-1,"30":-1,"31":-1,"32":-1,"33":-1,"35":0,"42":-1,"43":-1,"44":-1,"45":-1,"46":-1,"48":-1,"49":-1,"0":-1,"95":false,"96":false}}');
INSERT INTO `entitydata` VALUES ('1:hornet12:41BTO099', '{"mods":{"1":-1,"2":-1,"3":-1,"4":-1,"5":-1,"6":-1,"7":-1,"8":-1,"10":-1,"11":3,"12":2,"13":2,"14":-1,"15":-1,"16":-1,"18":1,"19":-1,"23":-1,"24":-1,"25":-1,"27":-1,"28":-1,"29":-1,"30":-1,"31":-1,"32":-1,"33":-1,"35":0,"42":-1,"43":-1,"44":-1,"45":-1,"46":-1,"48":-1,"49":-1,"0":-1,"95":false,"96":false},"wheelAngular":{"y":{"1":0.0,"2":0.0,"3":0.0,"4":0.0,"5":0.0,"0":0.0},"x":{"1":-0.00311564700677,"2":0.0,"3":0.0,"4":0.0,"5":0.0,"0":-0.01235295180231}},"colors":{"neon":false,"primary":[5,5,5],"xenon":false,"secondary":[255,255,255],"wheelColor":156,"pearly":44,"colorType":[33,127],"smoke":[0,0,0]},"wheel":{"type":6}}');
INSERT INTO `entitydata` VALUES ('1:skyline gt-:81OER012', '{"wheel":{"type":7},"colors":{"primary":[4,30,134],"colorType":[112,134],"smoke":[255,255,255],"xenon":false,"secondary":[105,105,105],"wheelColor":70,"neon":false,"pearly":4},"mods":{"1":-1,"2":-1,"3":-1,"4":-1,"5":-1,"6":-1,"7":-1,"8":-1,"10":-1,"11":-1,"12":-1,"13":-1,"14":-1,"15":-1,"16":-1,"18":false,"19":-1,"23":-1,"24":-1,"25":-1,"27":-1,"28":-1,"29":-1,"30":-1,"31":-1,"32":-1,"33":-1,"35":0,"42":-1,"43":-1,"44":-1,"45":-1,"46":-1,"48":-1,"49":-1,"0":-1,"95":false,"96":false},"wheelAngular":{"x":{"1":0.75436007976531,"2":-0.7733182311058,"3":0.7733182311058,"4":0.0,"5":0.0,"0":-0.75436007976531},"y":{"1":-0.0,"2":0.0,"3":-0.0,"4":0.0,"5":0.0,"0":0.0}}}');
INSERT INTO `entitydata` VALUES ('3:ferrari:73TTQ594', '{"wheel":{"type":0},"colors":{"primary":[218,11,11],"colorType":[2,2],"smoke":[255,255,255],"xenon":false,"secondary":[28,30,33],"wheelColor":2,"neon":false,"pearly":2},"mods":{"1":-1,"2":-1,"3":-1,"4":0,"5":-1,"6":-1,"7":-1,"8":-1,"10":-1,"11":3,"12":2,"13":2,"14":-1,"15":3,"16":-1,"18":1,"19":-1,"23":-1,"24":-1,"25":-1,"27":-1,"28":-1,"29":-1,"30":-1,"31":-1,"32":-1,"33":-1,"35":0,"42":-1,"43":-1,"44":-1,"45":-1,"46":0,"48":-1,"49":-1,"0":-1,"95":false,"96":true},"wheelAngular":{"x":{"1":0.85379463434219,"2":-0.77620142698287,"3":0.81823742389678,"4":0.0,"5":0.0,"0":-0.83347308635711},"y":{"1":0.00000104159119,"2":0.00000100622014,"3":0.00000100442798,"4":0.0,"5":0.0,"0":0.00000102177477}}}');
INSERT INTO `entitydata` VALUES ('3:ford mustan:74IBL748', '{"wheel":{"type":7},"mods":{"1":-1,"2":-1,"3":-1,"4":-1,"5":-1,"6":-1,"7":-1,"8":-1,"10":-1,"11":3,"12":-1,"13":-1,"14":-1,"15":-1,"16":-1,"18":false,"19":-1,"23":-1,"24":-1,"25":-1,"27":-1,"28":-1,"29":-1,"30":-1,"31":-1,"32":-1,"33":-1,"35":3,"42":-1,"43":-1,"44":-1,"45":-1,"46":-1,"48":-1,"49":-1,"0":-1,"95":false,"96":false},"colors":{"neon":false,"xenon":false,"pearly":0,"primary":[8,8,8],"secondary":[8,8,8],"wheelColor":0,"smoke":[255,255,255],"colorType":[0,0]},"wheelAngular":{"y":{"1":-0.0,"2":0.0,"3":-0.0,"4":0.0,"5":0.0,"0":0.0},"x":{"1":0.80212193727493,"2":-0.79189783334732,"3":0.78422546386718,"4":0.0,"5":0.0,"0":-0.79887717962265}}}');
INSERT INTO `entitydata` VALUES ('3:wrc7:46TGR401', '{"wheel":{"type":0},"mods":{"1":-1,"2":-1,"3":-1,"4":-1,"5":-1,"6":-1,"7":-1,"8":-1,"10":-1,"11":3,"12":2,"13":-1,"14":-1,"15":3,"16":-1,"18":false,"19":-1,"23":-1,"24":-1,"25":-1,"27":-1,"28":-1,"29":-1,"30":-1,"31":-1,"32":-1,"33":-1,"35":0,"42":-1,"43":-1,"44":-1,"45":-1,"46":3,"48":-1,"49":-1,"0":-1,"95":false,"96":false},"wheelAngular":{"y":{"1":-0.0,"2":0.0,"3":-0.0,"4":0.0,"5":0.0,"0":0.0},"x":{"1":0.7975730895996,"2":-0.78308057785034,"3":0.7830011844635,"4":0.0,"5":0.0,"0":-0.7977527976036}},"colors":{"secondary":[196,3,3],"smoke":[255,255,255],"wheelColor":63,"pearly":43,"primary":[245,0,0],"colorType":[12,0],"neon":false,"xenon":false}}');
INSERT INTO `entitydata` VALUES ('Chest:Bennys', '[]');
INSERT INTO `entitydata` VALUES ('Chest:Paramedic', '[]');
INSERT INTO `entitydata` VALUES ('Chest:Paramedic-2', '[]');
INSERT INTO `entitydata` VALUES ('Chest:Police', '[]');
INSERT INTO `entitydata` VALUES ('Glove:0THIAGO0', '[]');
INSERT INTO `entitydata` VALUES ('Glove:73TTQ594', '[]');
INSERT INTO `entitydata` VALUES ('Glove:TH14G000', '[]');
INSERT INTO `entitydata` VALUES ('Glove:THIAGOOO', '[]');
INSERT INTO `entitydata` VALUES ('Outfit:1', '{"shoes":{"item":140,"texture":6},"vest":{"item":0,"texture":0},"arms":{"item":0,"texture":0},"decals":{"item":0,"texture":0},"pants":{"item":165,"texture":1},"accessory":{"item":207,"texture":0},"torso":{"item":348,"texture":7},"ear":{"item":-1,"texture":0},"glass":{"item":-1,"texture":0},"backpack":{"item":0,"texture":0},"watch":{"item":32,"texture":3},"hat":{"item":-1,"texture":0},"tshirt":{"item":15,"texture":0},"bracelet":{"item":-1,"texture":0},"mask":{"item":0,"texture":0}}');
INSERT INTO `entitydata` VALUES ('Outfit:11', '[]');
INSERT INTO `entitydata` VALUES ('Outfit:2', '[]');
INSERT INTO `entitydata` VALUES ('Outfit:3', '{"glass":{"texture":0,"item":-1},"vest":{"texture":0,"item":0},"accessory":{"texture":0,"item":0},"bracelet":{"texture":0,"item":-1},"arms":{"texture":0,"item":4},"tshirt":{"texture":0,"item":15},"hat":{"texture":0,"item":191},"torso":{"texture":7,"item":70},"ear":{"texture":0,"item":-1},"shoes":{"texture":0,"item":0},"pants":{"texture":0,"item":199},"backpack":{"texture":0,"item":0},"watch":{"texture":0,"item":-1},"decals":{"texture":0,"item":0},"mask":{"texture":0,"item":0}}');
INSERT INTO `entitydata` VALUES ('Outfit:4', '{"watch":{"item":-1,"texture":0},"backpack":{"item":0,"texture":0},"bracelet":{"item":-1,"texture":0},"glass":{"item":62,"texture":2},"arms":{"item":12,"texture":0},"vest":{"item":58,"texture":0},"tshirt":{"item":72,"texture":5},"pants":{"item":37,"texture":2},"hat":{"item":-1,"texture":0},"mask":{"item":0,"texture":0},"shoes":{"item":20,"texture":0},"torso":{"item":338,"texture":0},"decals":{"item":0,"texture":0},"accessory":{"item":127,"texture":0},"ear":{"item":17,"texture":1}}');
INSERT INTO `entitydata` VALUES ('Outfit:6', '{"ear":{"item":-1,"texture":0},"backpack":{"item":0,"texture":0},"bracelet":{"item":-1,"texture":0},"accessory":{"item":127,"texture":0},"arms":{"item":12,"texture":0},"vest":{"item":0,"texture":0},"tshirt":{"item":15,"texture":0},"pants":{"item":24,"texture":0},"hat":{"item":-1,"texture":0},"mask":{"item":0,"texture":0},"shoes":{"item":10,"texture":0},"torso":{"item":349,"texture":10},"decals":{"item":0,"texture":0},"glass":{"item":54,"texture":0},"watch":{"item":-1,"texture":0}}');
INSERT INTO `entitydata` VALUES ('Outfit:8', '{"ear":{"item":-1,"texture":0},"glass":{"item":-1,"texture":0},"bracelet":{"item":-1,"texture":0},"accessory":{"item":0,"texture":0},"arms":{"item":280,"texture":0},"vest":{"item":63,"texture":2},"hat":{"item":-1,"texture":0},"pants":{"item":172,"texture":6},"tshirt":{"item":14,"texture":0},"mask":{"item":-1,"texture":0},"shoes":{"item":35,"texture":0},"torso":{"item":570,"texture":11},"decals":{"item":-1,"texture":0},"backpack":{"item":122,"texture":4},"watch":{"item":4,"texture":0}}');
INSERT INTO `entitydata` VALUES ('Outfit:9', '{"shoes":{"item":150,"texture":15},"vest":{"item":0,"texture":0},"mask":{"item":179,"texture":7},"arms":{"item":15,"texture":0},"watch":{"item":-1,"texture":0},"pants":{"item":185,"texture":0},"tshirt":{"item":7,"texture":1},"hat":{"item":-1,"texture":0},"torso":{"item":521,"texture":4},"glass":{"item":-1,"texture":0},"decals":{"item":0,"texture":0},"backpack":{"item":0,"texture":0},"accessory":{"item":209,"texture":0},"ear":{"item":-1,"texture":0},"bracelet":{"item":-1,"texture":0}}');
INSERT INTO `entitydata` VALUES ('Permissions:Admin', '{"15":1,"9":1,"6":1,"10":1,"7":1,"2":1,"1":1,"4":1,"3":1,"12":1,"11":1,"14":1,"13":1}');
INSERT INTO `entitydata` VALUES ('Permissions:AutoExotic', '{"12":1,"1":1}');
INSERT INTO `entitydata` VALUES ('Permissions:Bennys', '{"3":1}');
INSERT INTO `entitydata` VALUES ('Permissions:CentralCustoms', '{"1":1}');
INSERT INTO `entitydata` VALUES ('Permissions:DKing', '{}');
INSERT INTO `entitydata` VALUES ('Permissions:EstagiarioHP', '{"6":3,"1":1,"4":1,"7":3}');
INSERT INTO `entitydata` VALUES ('Permissions:Grove', '[]');
INSERT INTO `entitydata` VALUES ('Permissions:Mafia', '{}');
INSERT INTO `entitydata` VALUES ('Permissions:Magnata', '{"1":1}');
INSERT INTO `entitydata` VALUES ('Permissions:Ouro', '{"1":1}');
INSERT INTO `entitydata` VALUES ('Permissions:Paramedic', '{"1":1,"8":3,"7":6,"6":5,"5":5,"4":1}');
INSERT INTO `entitydata` VALUES ('Permissions:Playboy', '[]');
INSERT INTO `entitydata` VALUES ('Permissions:player.som', '{"9":1,"4":1,"6":1,"10":1,"8":1}');
INSERT INTO `entitydata` VALUES ('Permissions:Police', '{"9":1,"8":1,"6":1,"10":1,"2":1,"1":1,"15":1,"13":1,"14":1}');
INSERT INTO `entitydata` VALUES ('Permissions:Premium', '{"1":0}');
INSERT INTO `entitydata` VALUES ('Permissions:Prf', '[]');
INSERT INTO `entitydata` VALUES ('Permissions:Vagos', '{}');
INSERT INTO `entitydata` VALUES ('Permissions:Vanilla', '{"1":1}');
INSERT INTO `entitydata` VALUES ('Premiumfit:4', '[]');
INSERT INTO `entitydata` VALUES ('Premiumfit:6', '[]');
INSERT INTO `entitydata` VALUES ('Premiumfit:8', '[]');

DROP TABLE IF EXISTS `fidentity`;
CREATE TABLE `fidentity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `name2` varchar(50) NOT NULL DEFAULT '',
  `port` int(1) NOT NULL DEFAULT 1,
  `blood` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `fines`;
CREATE TABLE `fines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Passport` int(10) NOT NULL DEFAULT 0,
  `Name` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL,
  `Hour` varchar(50) NOT NULL,
  `Value` int(11) NOT NULL,
  `Message` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Passport` (`Passport`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `gas_station_balance`;
CREATE TABLE `gas_station_balance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gas_station_id` varchar(50) NOT NULL,
  `income` bit(1) NOT NULL,
  `title` varchar(255) NOT NULL,
  `amount` int(10) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `gas_station_business`;
CREATE TABLE `gas_station_business` (
  `gas_station_id` varchar(50) NOT NULL DEFAULT '',
  `user_id` varchar(50) NOT NULL,
  `stock` int(10) unsigned NOT NULL DEFAULT 0,
  `price` int(10) unsigned NOT NULL DEFAULT 0,
  `stock_upgrade` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `truck_upgrade` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `relationship_upgrade` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `money` int(10) unsigned NOT NULL DEFAULT 0,
  `total_money_earned` int(10) unsigned NOT NULL DEFAULT 0,
  `total_money_spent` int(10) unsigned NOT NULL DEFAULT 0,
  `gas_bought` int(10) unsigned NOT NULL DEFAULT 0,
  `gas_sold` int(10) unsigned NOT NULL DEFAULT 0,
  `distance_traveled` double unsigned NOT NULL DEFAULT 0,
  `total_visits` int(10) unsigned NOT NULL DEFAULT 0,
  `customers` int(10) unsigned NOT NULL DEFAULT 0,
  `timer` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`gas_station_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `gas_station_jobs`;
CREATE TABLE `gas_station_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gas_station_id` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL,
  `reward` int(10) unsigned NOT NULL DEFAULT 0,
  `amount` int(11) NOT NULL DEFAULT 0,
  `progress` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `groups_control`;
CREATE TABLE `groups_control` (
  `name` varchar(50) DEFAULT NULL,
  `money` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `groups_donates`;
CREATE TABLE `groups_donates` (
  `user_id` int(11) NOT NULL,
  `groupname` varchar(50) DEFAULT NULL,
  `donate` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `groups_maps`;
CREATE TABLE `groups_maps` (
  `name` varchar(50) DEFAULT NULL,
  `maps` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `hydrus_credits`;
CREATE TABLE `hydrus_credits` (
  `player_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `amount` int(11) DEFAULT 0,
  PRIMARY KEY (`player_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `hydrus_scheduler`;
CREATE TABLE `hydrus_scheduler` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `player_id` varchar(100) NOT NULL,
  `command` varchar(100) NOT NULL,
  `args` varchar(4096) NOT NULL,
  `execute_at` bigint(20) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `player_index` (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `investments`;
CREATE TABLE `investments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Passport` int(10) NOT NULL DEFAULT 0,
  `Liquid` int(20) NOT NULL DEFAULT 0,
  `Monthly` int(20) NOT NULL DEFAULT 0,
  `Deposit` int(20) NOT NULL DEFAULT 0,
  `Last` int(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `Passport` (`Passport`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Passport` int(10) NOT NULL DEFAULT 0,
  `Received` int(10) NOT NULL DEFAULT 0,
  `Type` varchar(50) NOT NULL,
  `Reason` longtext NOT NULL,
  `Holder` varchar(50) NOT NULL,
  `Value` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `Passport` (`Passport`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `invoices` VALUES ('1', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('2', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('3', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('4', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('5', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('6', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('7', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('8', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('9', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('10', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Fisica', '910');
INSERT INTO `invoices` VALUES ('11', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('12', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('13', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('14', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('15', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('16', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('17', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('18', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('19', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('20', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('21', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('22', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('23', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('24', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Compra De Veiculo', '100');
INSERT INTO `invoices` VALUES ('25', '6', '0', 'received', 'Cartão de Crédito', 'Loja: Fisica', '330');
INSERT INTO `invoices` VALUES ('26', '6', '0', 'received', 'Cartão de Crédito', 'Loja: Fisica', '65');
INSERT INTO `invoices` VALUES ('27', '6', '0', 'received', 'Cartão de Crédito', 'Loja: Fisica', '180');
INSERT INTO `invoices` VALUES ('28', '1', '0', 'received', 'Cartão de Crédito', 'Loja: Banco', '500');
INSERT INTO `invoices` VALUES ('29', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('30', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('31', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('32', '4', '0', 'received', 'Cartão de Crédito', 'Loja: Retirou Veiculo', '50');
INSERT INTO `invoices` VALUES ('33', '6', '0', 'received', 'Cartão de Crédito', 'Loja: Fisica', '750');

DROP TABLE IF EXISTS `mrlt_hp_consultas`;
CREATE TABLE `mrlt_hp_consultas` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_user_id` int(11) NOT NULL,
  `c_esp` varchar(255) NOT NULL,
  `c_date` longtext NOT NULL,
  `c_status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `mrlt_hp_data`;
CREATE TABLE `mrlt_hp_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `ocorrencia` text CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `datahora` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`,`user_id`) USING BTREE,
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `mrlt_hp_fotos`;
CREATE TABLE `mrlt_hp_fotos` (
  `user_id` int(11) NOT NULL,
  `imageUrl` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `org_transactions`;
CREATE TABLE `org_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `Type` varchar(50) NOT NULL,
  `Value` int(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `organizations`;
CREATE TABLE `organizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `bank` int(20) NOT NULL DEFAULT 0,
  `premium` int(20) NOT NULL DEFAULT 0,
  `buff` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `organizations` VALUES ('1', 'Police', '0', '0', '0');
INSERT INTO `organizations` VALUES ('2', 'Bennys', '0', '0', '0');
INSERT INTO `organizations` VALUES ('3', 'Paramedic', '0', '0', '0');
INSERT INTO `organizations` VALUES ('4', 'EstagiarioHP', '0', '0', '0');
INSERT INTO `organizations` VALUES ('5', 'AutoExotic', '0', '0', '0');
INSERT INTO `organizations` VALUES ('6', 'Playboy', '0', '0', '0');
INSERT INTO `organizations` VALUES ('7', 'Grove', '0', '0', '0');
INSERT INTO `organizations` VALUES ('8', 'Prf', '0', '0', '0');

DROP TABLE IF EXISTS `playerdata`;
CREATE TABLE `playerdata` (
  `Passport` int(11) NOT NULL,
  `dkey` varchar(100) NOT NULL,
  `dvalue` longtext DEFAULT NULL,
  PRIMARY KEY (`Passport`,`dkey`),
  KEY `Passport` (`Passport`),
  KEY `dkey` (`dkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `playerdata` VALUES ('1', 'Ammos', '{"AMMO_9":39}');
INSERT INTO `playerdata` VALUES ('1', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('1', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('1', 'Clothings', '{"tshirt":{"texture":0,"item":15},"decals":{"texture":0,"item":0},"watch":{"texture":3,"item":32},"ear":{"texture":0,"item":-1},"accessory":{"texture":0,"item":207},"vest":{"texture":0,"item":0},"arms":{"texture":0,"item":0},"mask":{"texture":0,"item":0},"backpack":{"texture":0,"item":0},"torso":{"texture":2,"item":454},"hat":{"texture":0,"item":-1},"bracelet":{"texture":0,"item":-1},"shoes":{"texture":6,"item":140},"pants":{"texture":2,"item":164},"glass":{"texture":0,"item":-1}}');
INSERT INTO `playerdata` VALUES ('1', 'Datatable', '{"Inventory":{"2":{"amount":3,"item":"roadsigns"},"1":{"amount":3,"item":"rope-1738124280"},"4":{"amount":68419,"item":"dollars2"},"3":{"amount":1,"item":"cellphone-1738127026"},"6":{"amount":199,"item":"dollars"},"5":{"amount":2,"item":"homekey-082039-179"}},"Hunger":49,"Skin":"mp_m_freemode_01","Thirst":49,"Weight":160,"Health":191,"Pos":{"z":49.98,"y":-282.14,"x":537.75},"Armour":0,"Stress":0}');
INSERT INTO `playerdata` VALUES ('1', 'Experience', '{"Taxi":16,"Fisherman":0,"Boosting":0,"Hunting":0,"Garbageman":0,"Minerman":2,"Bus":0,"Postal":0,"Transporter":0,"Dismantle":0,"Postalman":8,"Milkman":0,"Delivery":0,"Tractor":0,"Lumberman":0,"Trucker":12,"Tows":0}');
INSERT INTO `playerdata` VALUES ('1', 'nation_char', '{"facialHair-color":0,"chestHair-color":0,"skinThird":0,"facialHair":3,"eyesOpenning":0.0,"shapeSecond":2,"shapeFirst":23,"eyebrows":16,"skinSecond":15,"chinHole":0.0,"ageing":-1,"ageing-opacity":1.0,"noseWidth":0.0,"lipstick-color":0,"gender":"male","sunDamage-opacity":1.0,"chestHair":3,"overlay":0,"chinBoneWidth":0.0,"nosePeakHeight":0.0,"jawBoneWidth":0.0,"lipstick-opacity":1.0,"hair-color":0,"noseBoneHigh":0.0,"chinBoneLowering":0.0,"complexion":-1,"blush-color":0,"freckles-opacity":1.0,"ageing-color":0,"hair":47,"makeup":4,"freckles-color":0,"addBodyBlemishes-color":0,"shapeMix":1.0,"addBodyBlemishes-opacity":1.0,"jawBoneBackLength":0.0,"eyebrows-opacity":1.0,"thirdMix":0.0,"blemishes-opacity":1.0,"eyebrows-color":61,"complexion-color":0,"complexion-opacity":1.0,"nosePeakLength":0.0,"cheeksBoneHigh":0.0,"bodyBlemishes-opacity":1.0,"freckles":-1,"chestHair-opacity":1.0,"lipstick":-1,"blemishes":-1,"skinFirst":21,"sunDamage":-1,"eyes":13,"blush":-1,"blush-opacity":1.0,"cheeksBoneWidth":0.0,"noseBoneTwist":0.0,"makeup-opacity":1.0,"shapeThird":0,"nosePeakLowering":0.0,"blemishes-color":0,"eyeBrownForward":0.0,"facialHair-opacity":1.0,"lipsThickness":0.0,"sunDamage-color":0,"chinBoneLength":0.0,"neckThickness":0.0,"addBodyBlemishes":-1,"makeup-color":-1,"skinMix":0.80000001192092,"cheeksWidth":0.0,"eyeBrownHigh":0.0,"bodyBlemishes-color":0,"hair-highlightcolor":13,"bodyBlemishes":-1}');
INSERT INTO `playerdata` VALUES ('1', 'Rolepass', '{"Premium":0,"Points":1,"RolepassBuy":true,"Finish":1738375200.0,"Free":0}');
INSERT INTO `playerdata` VALUES ('1', 'Tatuagens', '[]');
INSERT INTO `playerdata` VALUES ('2', 'Ammos', '[]');
INSERT INTO `playerdata` VALUES ('2', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('2', 'Backpack', '{"backpackg":1739714094,"backpackm":1739714096,"backpackp":1739714097}');
INSERT INTO `playerdata` VALUES ('2', 'Clothings', '{"shoes":{"item":25,"texture":0},"torso":{"item":556,"texture":2},"bracelet":{"item":-1,"texture":0},"ear":{"item":-1,"texture":0},"arms":{"item":151,"texture":0},"accessory":{"item":125,"texture":0},"decals":{"item":-1,"texture":0},"hat":{"item":-1,"texture":0},"pants":{"item":205,"texture":0},"tshirt":{"item":225,"texture":0},"glass":{"item":0,"texture":0},"watch":{"item":-1,"texture":0},"mask":{"item":-1,"texture":0},"backpack":{"item":0,"texture":0},"vest":{"item":69,"texture":0}}');
INSERT INTO `playerdata` VALUES ('2', 'Datatable', '{"Skin":"mp_m_freemode_01","Pos":{"z":53.19,"x":147.31,"y":-334.94},"Weight":110,"Inventory":{"6":{"item":"cellphone-1737034292","amount":1},"12":{"item":"coal","amount":1},"8":{"amount":1,"item":"vape-1737825328"},"14":{"item":"radio","amount":1},"10":{"item":"GADGET_PARACHUTE","amount":2},"11":{"item":"dollars","amount":51058},"21":{"amount":1,"item":"debitcard-2"},"20":{"item":"WEAPON_SHOVEL","amount":1},"24":{"amount":5494,"item":"dollars2"},"23":{"amount":4,"item":"c4"},"22":{"amount":1,"item":"creditcard-2"},"1":{"item":"WEAPON_PARAFAL","amount":1},"2":{"item":"WEAPON_PISTOL_MK2","amount":1},"3":{"amount":1,"item":"WEAPON_HK416-1737833014-UZ86CO"},"4":{"item":"WEAPON_KARAMBIT","amount":1},"5":{"item":"WEAPON_KNUCKLE","amount":1},"16":{"amount":9,"item":"vest"},"17":{"item":"dmvdocs-2-{\"1\":\"A\"}-[]-[]","amount":1},"18":{"amount":7,"item":"sapphireore"},"9":{"amount":201,"item":"AMMO_556"},"7":{"item":"jackham","amount":1},"15":{"amount":150,"item":"AMMO_9"},"13":{"item":"identity-2","amount":1}},"Hunger":99,"Health":200,"Thirst":99,"Stress":0,"Armour":0}');
INSERT INTO `playerdata` VALUES ('2', 'Experience', '{"Tractor":0,"Tows":0,"Trucker":0,"Boosting":0,"Delivery":0,"Milkman":0,"Hunting":0,"Transporter":0,"Dismantle":0,"Bus":0,"Garbageman":0,"Lumberman":0,"Minerman":104,"Fisherman":0,"Postal":0,"Taxi":0}');
INSERT INTO `playerdata` VALUES ('2', 'nation_char', '{"skinMix":1.0,"facialHair":1,"shapeSecond":0,"blush-opacity":1.0,"eyeBrownHigh":0.0,"thirdMix":0.0,"freckles-color":0,"nosePeakLength":-0.12,"eyeBrownForward":0.0,"eyebrows-color":0,"cheeksBoneHigh":0.29,"facialHair-color":29,"chestHair-color":0,"overlay":30,"shapeFirst":21,"shapeMix":0.80000001192092,"cheeksBoneWidth":0.13,"sunDamage":-1,"sunDamage-color":0,"lipstick-color":0,"chinBoneWidth":0.32,"skinSecond":0,"ageing-color":0,"ageing-opacity":1.0,"eyebrows":33,"eyebrows-opacity":1.0,"noseBoneHigh":0.32,"blemishes-opacity":1.0,"cheeksWidth":0.08,"skinFirst":21,"noseWidth":0.0,"nosePeakLowering":-0.42,"blemishes-color":0,"lipstick":-1,"lipstick-opacity":1.0,"freckles-opacity":1.0,"blemishes":-1,"chinBoneLength":0.25,"facialHair-opacity":1.0,"bodyBlemishes-opacity":1.0,"blush":-1,"addBodyBlemishes-opacity":1.0,"jawBoneBackLength":0.18,"noseBoneTwist":0.0,"makeup-opacity":1.0,"eyesOpenning":-0.35,"chinHole":0.0,"makeup-color":-1,"shapeThird":0,"lipsThickness":0.0,"hair":11,"bodyBlemishes-color":0,"chinBoneLowering":0.29,"freckles":0,"hair-color":29,"skinThird":0,"complexion-color":0,"addBodyBlemishes":-1,"eyes":1,"chestHair-opacity":1.0,"sunDamage-opacity":1.0,"makeup":-1,"jawBoneWidth":0.24,"complexion-opacity":1.0,"addBodyBlemishes-color":0,"nosePeakHeight":0.22,"bodyBlemishes":-1,"blush-color":0,"gender":"male","hair-highlightcolor":29,"ageing":-1,"chestHair":-1,"neckThickness":0.0,"complexion":-1}');
INSERT INTO `playerdata` VALUES ('2', 'Rolepass', '{"Points":104}');
INSERT INTO `playerdata` VALUES ('2', 'Tatuagens', '[]');
INSERT INTO `playerdata` VALUES ('3', 'Ammos', '{"AMMO_556":56}');
INSERT INTO `playerdata` VALUES ('3', 'Attachs', '{"WEAPON_HEAVYRIFLE":{"ATTACH_SILENCER":true,"ATTACH_CROSSHAIR":true,"ATTACH_FLASHLIGHT":true,"ATTACH_MAGAZINE":true}}');
INSERT INTO `playerdata` VALUES ('3', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('3', 'Clothings', '{"vest":{"texture":0,"item":0},"tshirt":{"texture":0,"item":15},"watch":{"texture":0,"item":-1},"ear":{"texture":0,"item":44},"glass":{"texture":0,"item":58},"bracelet":{"texture":0,"item":-1},"arms":{"texture":0,"item":4},"mask":{"texture":0,"item":0},"backpack":{"texture":0,"item":0},"torso":{"texture":11,"item":275},"hat":{"texture":0,"item":191},"decals":{"texture":0,"item":0},"shoes":{"texture":0,"item":0},"pants":{"texture":0,"item":47},"accessory":{"texture":1,"item":207}}');
INSERT INTO `playerdata` VALUES ('3', 'Datatable', '{"Pos":{"z":30.09,"y":-1327.45,"x":-226.2},"Inventory":{"2":{"amount":4909,"item":"dollars2"},"1":{"amount":1,"item":"WEAPON_HEAVYRIFLE-1738167579-03PUM5"},"4":{"amount":1,"item":"lighter-1738173675"},"11":{"item":"dollars","amount":992515},"13":{"item":"cellphone-1738110196","amount":1},"3":{"amount":1,"item":"platepremium"}},"Stress":0,"Hunger":62,"Thirst":62,"Weight":160,"Armour":0,"Health":190,"Skin":"mp_m_freemode_01"}');
INSERT INTO `playerdata` VALUES ('3', 'Experience', '{"Boosting":0,"Lumberman":0,"Tractor":0,"Postal":0,"Bus":0,"Transporter":0,"Delivery":0,"Minerman":16,"Tows":0,"Milkman":0,"Taxi":0,"Hunting":0,"Trucker":0,"Fisherman":0,"Garbageman":0}');
INSERT INTO `playerdata` VALUES ('3', 'nation_char', '{"facialHair-opacity":1.0,"makeup-color":-1,"chestHair-color":0,"hair":21,"makeup-opacity":1.0,"complexion-opacity":1.0,"blemishes":-1,"ageing-color":0,"chinBoneWidth":0.0,"skinSecond":0,"complexion-color":0,"ageing":-1,"overlay":0,"facialHair":20,"eyesOpenning":0.33,"skinThird":0,"skinMix":0.80000001192092,"neckThickness":0.0,"blemishes-color":0,"gender":"male","chestHair":0,"chinBoneLowering":0.0,"bodyBlemishes":-1,"jawBoneWidth":0.0,"noseWidth":-0.16,"shapeFirst":21,"freckles-color":0,"bodyBlemishes-color":0,"lipstick-color":0,"freckles-opacity":1.0,"eyebrows-color":0,"sunDamage-color":0,"hair-highlightcolor":0,"noseBoneHigh":0.24,"shapeMix":0.80000001192092,"nosePeakLowering":-0.34,"blush-opacity":1.0,"thirdMix":0.0,"ageing-opacity":1.0,"lipstick-opacity":1.0,"jawBoneBackLength":0.0,"eyeBrownHigh":0.45,"lipsThickness":0.0,"chinBoneLength":0.0,"blush-color":56,"makeup":21,"sunDamage":-1,"skinFirst":21,"cheeksBoneHigh":0.0,"eyeBrownForward":0.0,"cheeksBoneWidth":0.0,"shapeThird":0,"sunDamage-opacity":1.0,"shapeSecond":0,"addBodyBlemishes-color":0,"complexion":-1,"eyebrows-opacity":1.0,"eyebrows":30,"chestHair-opacity":1.0,"eyes":0,"bodyBlemishes-opacity":1.0,"blemishes-opacity":1.0,"hair-color":0,"facialHair-color":0,"chinHole":0.0,"nosePeakLength":0.34,"nosePeakHeight":0.0,"lipstick":-1,"freckles":-1,"blush":32,"noseBoneTwist":0.0,"addBodyBlemishes-opacity":1.0,"addBodyBlemishes":-1,"cheeksWidth":0.0}');
INSERT INTO `playerdata` VALUES ('3', 'Rolepass', '{"Premium":0,"Points":0,"RolepassBuy":false,"Finish":1738375200.0,"Free":0}');
INSERT INTO `playerdata` VALUES ('3', 'Tatuagens', '[]');
INSERT INTO `playerdata` VALUES ('4', 'Ammos', '{"AMMO_9":41,"AMMO_556":24}');
INSERT INTO `playerdata` VALUES ('4', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('4', 'Backpack', '{"backpackp":1739758695,"backpackm":1739758692,"backpackg":1739758619}');
INSERT INTO `playerdata` VALUES ('4', 'Clothings', '{"bracelet":{"texture":0,"item":-1},"arms":{"texture":0,"item":12},"hat":{"texture":0,"item":-1},"glass":{"texture":2,"item":62},"backpack":{"texture":0,"item":0},"ear":{"texture":1,"item":17},"pants":{"texture":2,"item":37},"vest":{"texture":0,"item":58},"accessory":{"texture":0,"item":127},"watch":{"texture":0,"item":-1},"torso":{"texture":0,"item":338},"shoes":{"texture":0,"item":20},"decals":{"texture":0,"item":0},"tshirt":{"texture":5,"item":72},"mask":{"texture":0,"item":0}}');
INSERT INTO `playerdata` VALUES ('4', 'Datatable', '{"Pos":{"x":-623.52,"y":-148.95,"z":38.57},"Health":131,"Stress":0,"Inventory":{"10":{"item":"debitcard-4","amount":1},"9":{"item":"deck","amount":1},"3":{"item":"WEAPON_PISTOL_MK2","amount":1},"2":{"item":"WEAPON_REVOLVER_MK2","amount":1},"1":{"item":"handcuff","amount":1},"4":{"item":"vest","amount":9},"12":{"item":"AMMO_9","amount":488},"11":{"item":"dollars","amount":49030},"14":{"item":"scuba","amount":4},"13":{"item":"rope-1737753711","amount":1},"7":{"item":"card05","amount":2},"8":{"item":"cellphone-1737865279","amount":1},"5":{"item":"creditcard-4","amount":1},"6":{"item":"slipper","amount":1},"17":{"item":"WEAPON_PARAFAL","amount":1},"18":{"item":"WEAPON_GLOCK22","amount":1},"15":{"item":"c4","amount":1},"16":{"item":"AMMO_556","amount":750}},"Weight":110,"Armour":0,"Hunger":50,"Skin":"mp_m_freemode_01","Thirst":50}');
INSERT INTO `playerdata` VALUES ('4', 'Experience', '{"Boosting":0,"Tractor":0,"Delivery":0,"Transporter":0,"Postal":0,"Taxi":0,"Hunting":0,"Tows":0,"Lumberman":0,"Bus":0,"Minerman":0,"Fisherman":0,"Trucker":0,"Garbageman":0,"Milkman":0}');
INSERT INTO `playerdata` VALUES ('4', 'nation_char', '{"lipsThickness":-0.32,"cheeksBoneWidth":0.25,"makeup-opacity":1.0,"nosePeakHeight":0.44,"shapeFirst":31,"complexion":-1,"thirdMix":0.0,"blemishes-opacity":1.0,"eyebrows-opacity":1.0,"blush-color":0,"hair-color":4,"nosePeakLowering":-0.3,"ageing":-1,"shapeSecond":0,"addBodyBlemishes":-1,"shapeThird":0,"blush":-1,"neckThickness":1.0,"complexion-color":0,"skinMix":0.80000001192092,"chestHair":-1,"eyes":14,"eyeBrownForward":0.27,"blemishes-color":0,"makeup":-1,"blush-opacity":1.0,"lipstick":-1,"chestHair-opacity":1.0,"chinHole":0.33,"eyeBrownHigh":0.95,"hair":129,"skinFirst":21,"facialHair-opacity":1.0,"gender":"male","skinThird":0,"bodyBlemishes-color":0,"jawBoneBackLength":0.21,"cheeksWidth":0.31,"ageing-color":0,"addBodyBlemishes-opacity":1.0,"bodyBlemishes-opacity":1.0,"complexion-opacity":1.0,"freckles-opacity":1.0,"addBodyBlemishes-color":0,"noseBoneHigh":-0.18,"skinSecond":27,"freckles":-1,"eyebrows-color":0,"jawBoneWidth":0.44,"ageing-opacity":1.0,"hair-highlightcolor":4,"noseBoneTwist":0.0,"cheeksBoneHigh":-0.24,"lipstick-opacity":1.0,"nosePeakLength":0.25,"chinBoneLowering":-0.33,"chinBoneWidth":-0.45,"facialHair":20,"chestHair-color":0,"sunDamage-opacity":1.0,"overlay":0,"shapeMix":0.80000001192092,"sunDamage":-1,"chinBoneLength":0.55,"blemishes":-1,"sunDamage-color":0,"freckles-color":0,"makeup-color":-1,"eyesOpenning":-0.02,"eyebrows":29,"facialHair-color":4,"bodyBlemishes":-1,"noseWidth":0.07,"lipstick-color":0}');
INSERT INTO `playerdata` VALUES ('4', 'Rolepass', '{"Finish":1738375200.0,"Premium":0,"Free":0,"Points":0,"RolepassBuy":false}');
INSERT INTO `playerdata` VALUES ('4', 'Tatuagens', '{"MP_MP_Biker_Tat_057_M":"mpbiker_overlays","MP_MP_Stunt_tat_036_M":"mpstunt_overlays","FM_Hip_M_Tat_018":"mphipster_overlays","MP_Christmas2017_Tattoo_029_M":"mpchristmas2017_overlays","MP_MP_Biker_Tat_042_M":"mpbiker_overlays","MP_MP_Stunt_Tat_000_M":"mpstunt_overlays","NG_M_Hair_001":"multiplayer_overlays","FM_Hip_M_Tat_005":"mphipster_overlays","MP_Xmas2_M_Tat_003":"mpchristmas2_overlays","MP_MP_Biker_Tat_040_M":"mpbiker_overlays"}');
INSERT INTO `playerdata` VALUES ('5', 'Ammos', '[]');
INSERT INTO `playerdata` VALUES ('5', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('5', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('5', 'Clothings', '{"pants":{"texture":0,"item":20},"ear":{"texture":0,"item":-1},"torso":{"texture":7,"item":30},"bracelet":{"texture":0,"item":-1},"hat":{"texture":0,"item":-1},"watch":{"texture":0,"item":-1},"mask":{"texture":0,"item":0},"decals":{"texture":0,"item":0},"accessory":{"texture":0,"item":127},"shoes":{"texture":0,"item":42},"glass":{"texture":0,"item":8},"backpack":{"texture":0,"item":0},"vest":{"texture":0,"item":0},"arms":{"texture":0,"item":6},"tshirt":{"texture":0,"item":11}}');
INSERT INTO `playerdata` VALUES ('5', 'Datatable', '{"Stress":0,"Skin":"mp_m_freemode_01","Health":179,"Hunger":59,"Pos":{"z":38.0,"y":-672.02,"x":244.87},"Thirst":59,"Weight":40,"Armour":0,"Inventory":{"2":{"item":"plasticbottle","amount":1},"1":{"amount":1,"item":"identity-5"},"4":{"amount":410,"item":"dollars"},"3":{"amount":1,"item":"cellphone-1737239316"},"6":{"amount":3,"item":"hamburger-1737239316"}}}');
INSERT INTO `playerdata` VALUES ('5', 'Experience', '{"Fisherman":0,"Tractor":0,"Transporter":0,"Lumberman":0,"Trucker":0,"Hunting":0,"Delivery":0,"Milkman":0,"Taxi":0,"Tows":0,"Boosting":0,"Minerman":0,"Bus":0,"Garbageman":0,"Postal":0}');
INSERT INTO `playerdata` VALUES ('5', 'nation_char', '{"makeup-color":-1,"blush-opacity":1.0,"blemishes":-1,"eyesOpenning":-1.0,"cheeksBoneWidth":0.0,"nosePeakLowering":0.0,"noseWidth":0.0,"eyeBrownHigh":0.0,"facialHair-opacity":1.0,"cheeksBoneHigh":0.0,"skinThird":0,"freckles-opacity":1.0,"freckles-color":0,"sunDamage-color":0,"shapeFirst":24,"ageing":-1,"hair":5,"chinBoneLowering":0.0,"blemishes-opacity":1.0,"nosePeakHeight":0.0,"blemishes-color":0,"gender":"male","eyebrows-opacity":1.0,"skinMix":0.80000001192092,"freckles":-1,"shapeSecond":10,"blush-color":0,"tattoos":[],"facialHair":2,"chinHole":0.0,"skinSecond":14,"neckThickness":0.0,"complexion-color":0,"shapeMix":0.80000001192092,"jawBoneBackLength":0.0,"cheeksWidth":0.0,"hair-color":0,"jawBoneWidth":0.0,"sunDamage-opacity":1.0,"facialHair-color":0,"sunDamage":-1,"complexion-opacity":1.0,"addBodyBlemishes":-1,"addBodyBlemishes-color":0,"makeup-opacity":1.0,"makeup":-1,"eyebrows":-1,"eyebrows-color":0,"lipstick":-1,"complexion":-1,"eyes":4,"chestHair-opacity":1.0,"chestHair-color":0,"ageing-opacity":1.0,"bodyBlemishes":-1,"addBodyBlemishes-opacity":1.0,"ageing-color":0,"lipstick-opacity":1.0,"overlay":0,"chestHair":-1,"hair-highlightcolor":0,"eyeBrownForward":0.0,"bodyBlemishes-opacity":1.0,"lipsThickness":0.0,"bodyBlemishes-color":0,"noseBoneHigh":0.0,"nosePeakLength":0.0,"lipstick-color":0,"chinBoneWidth":0.0,"thirdMix":0.0,"noseBoneTwist":0.0,"chinBoneLength":0.0,"skinFirst":28,"shapeThird":0,"blush":-1}');
INSERT INTO `playerdata` VALUES ('5', 'Rolepass', '{"Points":0,"Free":0,"RolepassBuy":false,"Finish":1738375200.0,"Premium":0}');
INSERT INTO `playerdata` VALUES ('6', 'Ammos', '{"AMMO_9":181}');
INSERT INTO `playerdata` VALUES ('6', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('6', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('6', 'Clothings', '{"pants":{"texture":6,"item":200},"watch":{"texture":0,"item":-1},"backpack":{"texture":0,"item":0},"glass":{"texture":0,"item":34},"vest":{"texture":0,"item":0},"decals":{"texture":0,"item":0},"arms":{"texture":0,"item":215},"torso":{"texture":0,"item":15},"shoes":{"texture":0,"item":34},"hat":{"texture":0,"item":-1},"accessory":{"texture":1,"item":141},"bracelet":{"texture":0,"item":-1},"tshirt":{"texture":0,"item":15},"mask":{"texture":0,"item":0},"ear":{"texture":0,"item":-1}}');
INSERT INTO `playerdata` VALUES ('6', 'Datatable', '{"Pos":{"x":334.73,"y":-2014.49,"z":22.39},"Health":200,"Stress":0,"Inventory":{"23":{"amount":2,"item":"c4"},"22":{"amount":1,"item":"WEAPON_KATANA"},"21":{"amount":1,"item":"WEAPON_SHOVEL"},"3":{"amount":1,"item":"WEAPON_GLOCK22"},"2":{"amount":1,"item":"WEAPON_STUNGUN"},"10":{"amount":134343,"item":"dollars"},"4":{"item":"WEAPON_KARAMBIT","amount":1},"12":{"amount":2,"item":"water"},"11":{"item":"identity-6","amount":1},"9":{"item":"debitcard-6","amount":1},"13":{"amount":1,"item":"radio-1737734335"},"7":{"amount":1,"item":"creditcard-6"},"8":{"item":"cellphone-1738090954","amount":1},"5":{"item":"GADGET_PARACHUTE","amount":2},"6":{"amount":150,"item":"AMMO_9"},"1":{"amount":1,"item":"WEAPON_SCARH"}},"Weight":40,"Hunger":100,"Armour":0,"Skin":"mp_m_freemode_01","Thirst":100}');
INSERT INTO `playerdata` VALUES ('6', 'Experience', '{"Boosting":0,"Lumberman":0,"Bus":0,"Minerman":0,"Postal":0,"Taxi":1,"Hunting":0,"Transporter":0,"Tows":0,"Milkman":0,"Trucker":0,"Fisherman":0,"Tractor":0,"Garbageman":0,"Delivery":0}');
INSERT INTO `playerdata` VALUES ('6', 'nation_char', '{"bodyBlemishes-color":0,"eyebrows-opacity":1.0,"hair-highlightcolor":0,"addBodyBlemishes":-1,"freckles-color":0,"blush":25,"complexion-opacity":1.0,"chestHair":-1,"freckles-opacity":1.0,"nosePeakHeight":0.0,"skinSecond":4,"lipsThickness":0.0,"skinThird":0,"blemishes":-1,"complexion":-1,"makeup":-1,"shapeMix":0.80000001192092,"overlay":0,"cheeksBoneWidth":0.0,"eyebrows":16,"chestHair-opacity":1.0,"eyeBrownForward":0.11,"chinBoneWidth":0.0,"noseWidth":0.0,"eyeBrownHigh":0.0,"shapeThird":0,"chinHole":0.0,"facialHair-color":0,"bodyBlemishes-opacity":1.0,"lipstick":-1,"skinFirst":21,"ageing-opacity":1.0,"chinBoneLowering":0.0,"lipstick-opacity":1.0,"eyesOpenning":0.18,"complexion-color":0,"sunDamage-opacity":1.0,"jawBoneWidth":0.0,"lipstick-color":0,"nosePeakLength":0.0,"blush-color":56,"chinBoneLength":0.0,"jawBoneBackLength":0.0,"addBodyBlemishes-opacity":1.0,"hair":21,"neckThickness":0.0,"ageing":-1,"blush-opacity":1.0,"makeup-opacity":1.0,"chestHair-color":0,"bodyBlemishes":-1,"gender":"male","eyebrows-color":0,"hair-color":0,"freckles":-1,"ageing-color":0,"makeup-color":-1,"eyes":4,"cheeksWidth":0.0,"addBodyBlemishes-color":0,"nosePeakLowering":0.0,"shapeFirst":24,"sunDamage-color":0,"facialHair-opacity":1.0,"noseBoneHigh":0.0,"facialHair":2,"skinMix":0.72000002861022,"thirdMix":0.0,"sunDamage":-1,"blemishes-opacity":1.0,"shapeSecond":2,"cheeksBoneHigh":0.0,"noseBoneTwist":0.0,"blemishes-color":0}');
INSERT INTO `playerdata` VALUES ('6', 'Rolepass', '{"RolepassBuy":false,"Free":0,"Points":1,"Finish":1738375200.0,"Premium":0}');
INSERT INTO `playerdata` VALUES ('6', 'Tatuagens', '[]');
INSERT INTO `playerdata` VALUES ('7', 'Ammos', '[]');
INSERT INTO `playerdata` VALUES ('7', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('7', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('7', 'Clothings', '{"torso":{"item":367,"texture":3},"glass":{"item":36,"texture":1},"hat":{"item":-1,"texture":0},"arms":{"item":3,"texture":0},"watch":{"item":-1,"texture":0},"backpack":{"item":122,"texture":4},"ear":{"item":-1,"texture":0},"tshirt":{"item":2,"texture":0},"shoes":{"item":138,"texture":4},"pants":{"item":23,"texture":0},"bracelet":{"item":-1,"texture":0},"vest":{"item":0,"texture":0},"decals":{"item":0,"texture":0},"accessory":{"item":97,"texture":0},"mask":{"item":0,"texture":0}}');
INSERT INTO `playerdata` VALUES ('7', 'Datatable', '{"Health":200,"Hunger":99,"Armour":0,"Stress":0,"Skin":"mp_f_freemode_01","Pos":{"x":294.8,"y":-591.3,"z":43.03},"Thirst":99,"Weight":40,"Inventory":{"4":{"item":"identity-7","amount":1},"5":{"item":"dollars","amount":70},"6":{"item":"hamburger-1737247614","amount":3},"1":{"item":"gift","amount":1},"2":{"item":"water","amount":2},"3":{"item":"cellphone-1737247614","amount":1}}}');
INSERT INTO `playerdata` VALUES ('7', 'Experience', '{"Fisherman":0,"Trucker":0,"Transporter":0,"Lumberman":0,"Garbageman":0,"Delivery":0,"Tows":0,"Bus":0,"Boosting":0,"Tractor":0,"Hunting":0,"Taxi":0,"Milkman":0,"Minerman":0,"Postal":0}');
INSERT INTO `playerdata` VALUES ('7', 'nation_char', '{"eyebrows":12,"blush":2,"ageing-color":0,"eyebrows-opacity":1.0,"addBodyBlemishes-color":0,"noseBoneHigh":0.59,"makeup":22,"noseWidth":-0.83,"sunDamage-opacity":1.0,"eyesOpenning":0.38,"skinSecond":37,"noseBoneTwist":0.0,"tattoos":[],"blush-opacity":0.61,"chestHair-color":0,"ageing-opacity":1.0,"lipstick":4,"cheeksWidth":-0.42,"chinBoneLength":-0.71,"makeup-opacity":1.0,"eyes":2,"bodyBlemishes-opacity":1.0,"facialHair-opacity":1.0,"shapeFirst":45,"eyebrows-color":61,"blemishes-color":0,"cheeksBoneWidth":-0.5,"hair":128,"blush-color":0,"shapeThird":0,"chestHair":10,"eyeBrownHigh":0.0,"nosePeakLowering":0.35,"lipstick-color":0,"cheeksBoneHigh":-0.65,"complexion-opacity":1.0,"nosePeakHeight":-0.2,"lipstick-opacity":1.0,"skinMix":0.74000000953674,"hair-color":38,"ageing":-1,"nosePeakLength":0.33,"complexion-color":0,"complexion":5,"jawBoneBackLength":-0.14,"chinHole":0.0,"jawBoneWidth":-0.69,"eyeBrownForward":-0.46,"thirdMix":0.0,"shapeMix":0.20000000298023,"hair-highlightcolor":0,"overlay":0,"skinThird":0,"skinFirst":34,"facialHair-color":0,"sunDamage-color":0,"freckles-color":0,"neckThickness":0.0,"makeup-color":-1,"chinBoneWidth":-0.1,"bodyBlemishes":-1,"addBodyBlemishes-opacity":1.0,"shapeSecond":0,"addBodyBlemishes":-1,"bodyBlemishes-color":0,"chinBoneLowering":-0.52,"gender":"female","blemishes":-1,"chestHair-opacity":1.0,"blemishes-opacity":1.0,"facialHair":-1,"freckles":4,"lipsThickness":0.48,"freckles-opacity":1.0,"sunDamage":-1}');
INSERT INTO `playerdata` VALUES ('7', 'Tatuagens', '[]');
INSERT INTO `playerdata` VALUES ('8', 'Ammos', '[]');
INSERT INTO `playerdata` VALUES ('8', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('8', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('8', 'Clothings', '{"backpack":{"texture":4,"item":122},"hat":{"texture":0,"item":-1},"glass":{"texture":0,"item":-1},"bracelet":{"texture":0,"item":-1},"tshirt":{"texture":0,"item":14},"decals":{"texture":0,"item":162},"arms":{"texture":0,"item":276},"watch":{"texture":0,"item":4},"mask":{"texture":0,"item":-1},"shoes":{"texture":0,"item":35},"accessory":{"texture":2,"item":190},"vest":{"texture":2,"item":63},"pants":{"texture":3,"item":230},"ear":{"texture":0,"item":-1},"torso":{"texture":8,"item":596}}');
INSERT INTO `playerdata` VALUES ('8', 'Datatable', '{"Pos":{"x":-2675.52,"y":3228.14,"z":32.12},"Health":199,"Stress":0,"Inventory":{"14":{"item":"emeraldore","amount":5},"1":{"amount":1,"item":"WEAPON_STUNGUN"},"10":{"item":"lighter-1738091057","amount":1},"12":{"item":"dollars2","amount":5269},"11":{"item":"plasticbottle","amount":3},"9":{"item":"canopener","amount":1},"13":{"amount":1,"item":"WEAPON_KARAMBIT"},"7":{"amount":1,"item":"WEAPON_SCARH-1737122147-363R37"},"8":{"item":"c4","amount":1},"5":{"item":"dollars","amount":122739},"6":{"item":"debitcard-8","amount":1},"4":{"item":"identity-8","amount":1},"16":{"amount":1,"item":"WEAPON_FLAMETHROWER"}},"Weight":40,"Hunger":96,"Armour":0,"Skin":"mp_f_freemode_01","Thirst":96}');
INSERT INTO `playerdata` VALUES ('8', 'Experience', '{"Boosting":0,"Lumberman":0,"Tractor":0,"Trucker":0,"Postal":0,"Taxi":0,"Hunting":0,"Milkman":0,"Delivery":0,"Bus":0,"Tows":0,"Fisherman":0,"Minerman":0,"Garbageman":0,"Transporter":0}');
INSERT INTO `playerdata` VALUES ('8', 'nation_char', '{"makeup-opacity":1.0,"skinFirst":21,"blemishes":-1,"gender":"female","jawBoneBackLength":0.36,"hair":187,"noseWidth":-1.0,"skinThird":0,"cheeksWidth":0.13,"neckThickness":0.0,"facialHair-color":0,"chinBoneLowering":0.0,"lipstick":4,"blush":4,"nosePeakLowering":-0.52,"complexion-opacity":1.0,"eyebrows":7,"addBodyBlemishes-color":0,"freckles":-1,"hair-color":61,"freckles-opacity":1.0,"freckles-color":0,"complexion-color":0,"blush-color":24,"overlay":0,"sunDamage-color":0,"chinBoneLength":0.0,"nosePeakLength":0.91,"ageing-color":0,"addBodyBlemishes":-1,"blemishes-color":0,"chestHair":4,"shapeFirst":21,"eyeBrownHigh":0.61,"chestHair-opacity":1.0,"thirdMix":0.0,"eyes":16,"sunDamage-opacity":1.0,"chinHole":0.0,"bodyBlemishes-opacity":1.0,"chinBoneWidth":-0.1,"sunDamage":-1,"cheeksBoneHigh":-0.35,"hair-highlightcolor":61,"eyebrows-opacity":1.0,"eyeBrownForward":0.0,"facialHair":17,"skinSecond":0,"eyebrows-color":61,"lipstick-opacity":1.0,"shapeThird":0,"addBodyBlemishes-opacity":1.0,"nosePeakHeight":0.0,"blemishes-opacity":1.0,"makeup":25,"shapeMix":0.0,"noseBoneTwist":0.0,"eyesOpenning":0.22,"cheeksBoneWidth":-0.04,"shapeSecond":21,"blush-opacity":0.99,"ageing":-1,"complexion":-1,"bodyBlemishes":-1,"bodyBlemishes-color":0,"makeup-color":-1,"lipsThickness":-0.68,"facialHair-opacity":1.0,"noseBoneHigh":0.0,"skinMix":0.20000000298023,"chestHair-color":0,"jawBoneWidth":-0.16,"ageing-opacity":1.0,"lipstick-color":24}');
INSERT INTO `playerdata` VALUES ('8', 'Tatuagens', '{"MP_Christmas2017_Tattoo_017_F":"mpchristmas2017_overlays","MP_LR_Tat_012_F":"mplowrider2_overlays","MP_Smuggler_Tattoo_020_F":"mpsmuggler_overlays","MP_MP_Biker_Tat_057_F":"mpbiker_overlays","MP_LR_Tat_016_F":"mplowrider2_overlays","MP_LUXE_TAT_009_F":"mpluxe_overlays"}');
INSERT INTO `playerdata` VALUES ('9', 'Ammos', '{"AMMO_9":128}');
INSERT INTO `playerdata` VALUES ('9', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('9', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('9', 'Clothings', '{"arms":{"texture":0,"item":15},"mask":{"texture":7,"item":179},"accessory":{"texture":0,"item":209},"ear":{"texture":0,"item":-1},"tshirt":{"texture":1,"item":7},"glass":{"texture":0,"item":-1},"vest":{"texture":0,"item":0},"decals":{"texture":0,"item":0},"backpack":{"texture":0,"item":0},"torso":{"texture":4,"item":521},"hat":{"texture":0,"item":-1},"bracelet":{"texture":0,"item":-1},"shoes":{"texture":15,"item":150},"pants":{"texture":0,"item":185},"watch":{"texture":0,"item":-1}}');
INSERT INTO `playerdata` VALUES ('9', 'Datatable', '{"Hunger":99,"Skin":"mp_m_freemode_01","Armour":0,"Inventory":{"1":{"item":"WEAPON_SPECIALCARBINE_MK2","amount":1},"9":{"item":"card04","amount":7},"16":{"item":"AMMO_9","amount":1278},"5":{"item":"dollars","amount":8790},"4":{"item":"WEAPON_SHOVEL","amount":1},"3":{"item":"WEAPON_PISTOL_MK2","amount":1},"2":{"item":"WEAPON_GLOCK18C","amount":1},"19":{"item":"AMMO_762","amount":1285},"8":{"item":"card01","amount":3},"7":{"item":"card05","amount":7},"6":{"item":"card03","amount":7},"20":{"item":"AMMO_762","amount":1500},"21":{"item":"AMMO_762","amount":1000},"11":{"item":"dollars2","amount":330},"10":{"item":"card02","amount":7}},"Stress":0,"Weight":40,"Pos":{"y":-900.18,"x":226.26,"z":29.59},"Thirst":99,"Health":200}');
INSERT INTO `playerdata` VALUES ('9', 'Experience', '{"Taxi":0,"Bus":0,"Transporter":0,"Lumberman":0,"Boosting":0,"Milkman":0,"Minerman":0,"Postal":0,"Tows":0,"Trucker":0,"Fisherman":0,"Delivery":0,"Garbageman":0,"Hunting":0,"Tractor":0}');
INSERT INTO `playerdata` VALUES ('9', 'nation_char', '{"eyebrows":2,"blush":23,"ageing-color":0,"makeup-color":-1,"addBodyBlemishes-color":0,"noseBoneHigh":0.3,"addBodyBlemishes-opacity":1.0,"noseWidth":-0.45,"sunDamage-opacity":1.0,"eyesOpenning":0.49,"gender":"male","noseBoneTwist":0.0,"blemishes":-1,"blush-opacity":1.0,"chestHair-color":61,"overlay":0,"lipstick":-1,"cheeksWidth":-1.0,"chinBoneLength":0.57,"makeup-opacity":1.0,"eyes":1,"bodyBlemishes-opacity":1.0,"facialHair-opacity":1.0,"shapeFirst":21,"eyebrows-color":61,"blemishes-color":0,"cheeksBoneWidth":-0.27,"hair":129,"blush-color":58,"shapeThird":0,"chestHair":7,"eyeBrownHigh":0.66,"nosePeakLowering":-0.41,"lipstick-color":0,"cheeksBoneHigh":-0.16,"complexion-opacity":1.0,"nosePeakHeight":0.59,"lipstick-opacity":1.0,"skinMix":0.0,"hair-color":61,"ageing":-1,"nosePeakLength":0.66,"complexion-color":0,"complexion":-1,"jawBoneBackLength":-0.04,"chinBoneLowering":0.08,"jawBoneWidth":-0.56,"eyeBrownForward":-0.23,"thirdMix":0.0,"shapeMix":0.63999998569488,"hair-highlightcolor":61,"ageing-opacity":1.0,"skinThird":0,"skinFirst":29,"bodyBlemishes":-1,"sunDamage-color":0,"bodyBlemishes-color":0,"neckThickness":1.0,"skinSecond":45,"chinBoneWidth":-0.62,"freckles-opacity":1.0,"chestHair-opacity":1.0,"shapeSecond":0,"addBodyBlemishes":-1,"chinHole":0.68,"facialHair":0,"freckles-color":0,"makeup":18,"blemishes-opacity":1.0,"eyebrows-opacity":1.0,"freckles":-1,"facialHair-color":61,"lipsThickness":1.0,"tattoos":[],"sunDamage":-1}');
INSERT INTO `playerdata` VALUES ('9', 'Tatuagens', '[]');
INSERT INTO `playerdata` VALUES ('10', 'Ammos', '[]');
INSERT INTO `playerdata` VALUES ('10', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('10', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('10', 'Clothings', '{"glass":{"texture":0,"item":0},"vest":{"texture":0,"item":69},"accessory":{"texture":0,"item":125},"ear":{"texture":0,"item":-1},"arms":{"texture":0,"item":151},"mask":{"texture":0,"item":-1},"tshirt":{"texture":0,"item":225},"decals":{"texture":0,"item":-1},"backpack":{"texture":0,"item":0},"torso":{"texture":2,"item":556},"hat":{"texture":0,"item":-1},"bracelet":{"texture":0,"item":-1},"shoes":{"texture":0,"item":25},"pants":{"texture":0,"item":205},"watch":{"texture":0,"item":-1}}');
INSERT INTO `playerdata` VALUES ('10', 'Datatable', '{"Pos":{"z":35.86,"y":-223.63,"x":-358.33},"Inventory":{"9":{"item":"miningpan","amount":1},"8":{"item":"weedleaf","amount":1},"7":{"item":"grape","amount":4},"6":{"item":"weedclone","amount":1},"5":{"item":"handcuff-1738013889","amount":1},"10":{"item":"lighter-1738012450","amount":1},"3":{"item":"dollars2","amount":64622},"2":{"item":"dollars","amount":9999996545},"1":{"item":"identity-10","amount":1},"4":{"item":"WEAPON_SHOVEL-1737940280","amount":1},"11":{"item":"lockpick-1738020042","amount":1}},"Stress":0,"Hunger":63,"Thirst":63,"Weight":160,"Armour":0,"Health":181,"Skin":"mp_m_freemode_01"}');
INSERT INTO `playerdata` VALUES ('10', 'Experience', '{"Boosting":0,"Lumberman":0,"Trucker":0,"Tractor":0,"Postal":0,"Bus":0,"Milkman":0,"Tows":0,"Minerman":8,"Postalman":11,"Delivery":0,"Taxi":0,"Hunting":0,"Transporter":0,"Fisherman":0,"Garbageman":0}');
INSERT INTO `playerdata` VALUES ('10', 'nation_char', '{"freckles":-1,"facialHair-color":61,"eyeBrownHigh":0.22,"lipstick":-1,"chinHole":0.21,"complexion":-1,"makeup-opacity":1.0,"chinBoneLowering":0.32,"cheeksWidth":0.09,"facialHair":11,"facialHair-opacity":1.0,"lipsThickness":-0.27,"thirdMix":0.0,"jawBoneWidth":0.35,"cheeksBoneWidth":0.4,"blush":-1,"shapeMix":0.80000001192092,"bodyBlemishes-opacity":1.0,"freckles-color":0,"ageing-opacity":1.0,"eyes":0,"chestHair-opacity":1.0,"makeup":4,"freckles-opacity":1.0,"eyebrows-color":61,"lipstick-color":0,"blemishes-opacity":1.0,"hair-highlightcolor":0,"sunDamage":-1,"bodyBlemishes":-1,"complexion-color":0,"hair-color":0,"jawBoneBackLength":0.38,"noseBoneTwist":0.0,"cheeksBoneHigh":-0.26,"nosePeakLowering":0.03,"makeup-color":-1,"chinBoneLength":0.28,"shapeFirst":31,"ageing":-1,"skinSecond":16,"nosePeakHeight":0.66,"sunDamage-color":0,"addBodyBlemishes-opacity":1.0,"ageing-color":0,"complexion-opacity":1.0,"skinThird":0,"gender":"male","overlay":0,"chinBoneWidth":0.42,"skinMix":0.80000001192092,"bodyBlemishes-color":0,"blush-opacity":1.0,"eyebrows":27,"shapeThird":0,"skinFirst":25,"shapeSecond":2,"eyeBrownForward":0.32,"tattoos":[],"blush-color":0,"nosePeakLength":-0.03,"noseBoneHigh":0.22,"blemishes-color":0,"chestHair":3,"eyebrows-opacity":1.0,"sunDamage-opacity":1.0,"lipstick-opacity":0.0,"noseWidth":-0.28,"neckThickness":1.0,"addBodyBlemishes":-1,"hair":0,"blemishes":-1,"chestHair-color":61,"eyesOpenning":0.3,"addBodyBlemishes-color":0}');
INSERT INTO `playerdata` VALUES ('10', 'Rolepass', '{"Points":16}');
INSERT INTO `playerdata` VALUES ('11', 'Ammos', '[]');
INSERT INTO `playerdata` VALUES ('11', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('11', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('11', 'Clothings', '{"ear":{"item":-1,"texture":0},"torso":{"item":556,"texture":3},"shoes":{"item":59,"texture":20},"backpack":{"item":0,"texture":0},"decals":{"item":-1,"texture":0},"mask":{"item":-1,"texture":0},"hat":{"item":-1,"texture":0},"glass":{"item":0,"texture":0},"arms":{"item":0,"texture":0},"vest":{"item":68,"texture":0},"watch":{"item":-1,"texture":0},"tshirt":{"item":224,"texture":0},"accessory":{"item":-1,"texture":0},"bracelet":{"item":-1,"texture":0},"pants":{"item":129,"texture":1}}');
INSERT INTO `playerdata` VALUES ('11', 'Datatable', '{"Health":200,"Armour":0,"Weight":160,"Inventory":{"1":{"amount":1,"item":"cellphone-1738045960"}},"Pos":{"y":-897.2,"z":29.59,"x":222.97},"Thirst":42,"Stress":0,"Hunger":42,"Skin":"mp_m_freemode_01"}');
INSERT INTO `playerdata` VALUES ('11', 'Experience', '{"Lumberman":0,"Delivery":0,"Trucker":0,"Transporter":0,"Tows":0,"Tractor":0,"Bus":0,"Garbageman":0,"Taxi":0,"Fisherman":0,"Milkman":0,"Hunting":0,"Minerman":0,"Postal":0,"Boosting":0}');
INSERT INTO `playerdata` VALUES ('12', 'Ammos', '[]');
INSERT INTO `playerdata` VALUES ('12', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('12', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('12', 'Clothings', '{"shoes":{"item":0,"texture":0},"torso":{"item":0,"texture":0},"bracelet":{"item":-1,"texture":0},"ear":{"item":-1,"texture":0},"arms":{"item":0,"texture":0},"accessory":{"item":0,"texture":0},"hat":{"item":-1,"texture":0},"decals":{"item":0,"texture":0},"pants":{"item":0,"texture":0},"tshirt":{"item":1,"texture":0},"glass":{"item":0,"texture":0},"watch":{"item":-1,"texture":0},"mask":{"item":0,"texture":0},"backpack":{"item":0,"texture":0},"vest":{"item":0,"texture":0}}');
INSERT INTO `playerdata` VALUES ('12', 'Datatable', '{"Skin":"mp_m_freemode_01","Pos":{"z":30.43,"x":56.15,"y":-874.9},"Weight":40,"Inventory":{"6":{"amount":1,"item":"identity-12"},"2":{"amount":5,"item":"hamburger-1737824401"},"3":{"amount":1,"item":"cellphone-1737824401"},"4":{"amount":1500,"item":"dollars"},"5":{"amount":2,"item":"water"}},"Hunger":52,"Health":170,"Stress":0,"Thirst":52,"Armour":0}');
INSERT INTO `playerdata` VALUES ('12', 'Experience', '{"Tractor":0,"Tows":0,"Trucker":0,"Delivery":0,"Bus":0,"Hunting":0,"Transporter":0,"Taxi":0,"Postal":0,"Milkman":0,"Garbageman":0,"Minerman":0,"Fisherman":0,"Lumberman":0,"Boosting":0}');
INSERT INTO `playerdata` VALUES ('13', 'Ammos', '{"AMMO_9":195,"AMMO_556":134}');
INSERT INTO `playerdata` VALUES ('13', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('13', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('13', 'Clothings', '{"shoes":{"texture":0,"item":145},"ear":{"texture":0,"item":-1},"mask":{"texture":2,"item":210},"watch":{"texture":0,"item":22},"hat":{"texture":0,"item":-1},"backpack":{"texture":0,"item":0},"decals":{"texture":0,"item":199},"tshirt":{"texture":0,"item":382},"bracelet":{"texture":0,"item":-1},"arms":{"texture":0,"item":288},"accessory":{"texture":2,"item":83},"vest":{"texture":0,"item":0},"glass":{"texture":2,"item":8},"pants":{"texture":2,"item":240},"torso":{"texture":1,"item":672}}');
INSERT INTO `playerdata` VALUES ('13', 'Datatable', '{"Hunger":70,"Skin":"mp_f_freemode_01","Armour":0,"Inventory":{"14":{"item":"dollars2","amount":27920},"8":{"item":"cellphone-1737857975","amount":1},"12":{"item":"card03","amount":1},"13":{"item":"card04","amount":54},"11":{"item":"creditcard-13","amount":1},"10":{"item":"dollars","amount":810},"1":{"item":"WEAPON_GLOCK22","amount":1},"5":{"item":"AMMO_9","amount":1268},"4":{"item":"AMMO_9","amount":1034},"3":{"item":"energetic","amount":15},"2":{"item":"WEAPON_GLOCK18C","amount":1},"19":{"item":"identity-13","amount":1},"6":{"item":"gift","amount":1},"7":{"item":"hamburger-1737857975","amount":5},"15":{"item":"debitcard-13","amount":1},"9":{"item":"water","amount":2}},"Stress":0,"Weight":40,"Pos":{"y":-825.98,"x":159.67,"z":149.24},"Thirst":70,"Health":200}');
INSERT INTO `playerdata` VALUES ('13', 'Experience', '{"Boosting":0,"Tractor":0,"Transporter":0,"Lumberman":0,"Trucker":0,"Garbageman":0,"Minerman":0,"Postal":0,"Tows":0,"Milkman":0,"Fisherman":0,"Delivery":0,"Taxi":0,"Hunting":0,"Bus":0}');
INSERT INTO `playerdata` VALUES ('13', 'nation_char', '{"bodyBlemishes-opacity":1.0,"ageing-color":0,"sunDamage-opacity":1.0,"addBodyBlemishes-color":0,"eyeBrownHigh":1.0,"complexion-color":0,"blush":11,"noseWidth":-1.0,"lipsThickness":0.0,"ageing":-1,"cheeksBoneWidth":0.0,"shapeSecond":0,"nosePeakHeight":0.0,"chinBoneLowering":0.0,"eyebrows":10,"overlay":0,"bodyBlemishes-color":0,"blush-color":56,"skinSecond":5,"ageing-opacity":1.0,"jawBoneWidth":0.0,"freckles":0,"addBodyBlemishes":-1,"nosePeakLowering":0.0,"eyesOpenning":1.0,"eyebrows-color":61,"thirdMix":0.0,"hair-color":29,"complexion":5,"freckles-color":0,"eyeBrownForward":0.0,"blemishes-color":0,"jawBoneBackLength":0.0,"nosePeakLength":0.0,"bodyBlemishes":-1,"noseBoneHigh":0.0,"chestHair-color":61,"blush-opacity":1.0,"makeup":64,"makeup-opacity":1.0,"makeup-color":56,"blemishes-opacity":1.0,"neckThickness":0.0,"facialHair":19,"skinMix":0.0,"addBodyBlemishes-opacity":1.0,"lipstick-color":0,"shapeFirst":24,"chestHair":10,"eyebrows-opacity":1.0,"eyes":26,"skinFirst":41,"sunDamage-color":0,"cheeksWidth":0.0,"lipstick":5,"sunDamage":-1,"chinBoneWidth":0.0,"chinBoneLength":0.0,"gender":"female","facialHair-color":29,"facialHair-opacity":1.0,"shapeThird":0,"complexion-opacity":1.0,"hair":205,"shapeMix":0.0,"freckles-opacity":1.0,"noseBoneTwist":0.0,"chinHole":0.0,"cheeksBoneHigh":0.0,"lipstick-opacity":0.33,"skinThird":0,"blemishes":-1,"chestHair-opacity":1.0,"hair-highlightcolor":29}');
INSERT INTO `playerdata` VALUES ('14', 'Ammos', '[]');
INSERT INTO `playerdata` VALUES ('14', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('14', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('14', 'Clothings', '{"pants":{"item":0,"texture":0},"backpack":{"item":0,"texture":0},"vest":{"item":0,"texture":0},"ear":{"item":-1,"texture":0},"hat":{"item":-1,"texture":0},"tshirt":{"item":1,"texture":0},"glass":{"item":0,"texture":0},"mask":{"item":0,"texture":0},"shoes":{"item":0,"texture":0},"bracelet":{"item":-1,"texture":0},"accessory":{"item":0,"texture":0},"arms":{"item":0,"texture":0},"decals":{"item":0,"texture":0},"watch":{"item":-1,"texture":0},"torso":{"item":0,"texture":0}}');
INSERT INTO `playerdata` VALUES ('14', 'Datatable', '{"Hunger":61,"Skin":"mp_m_freemode_01","Armour":0,"Inventory":{"1":{"item":"WEAPON_SHOVEL","amount":1},"5":{"item":"water","amount":2},"4":{"item":"dollars","amount":1500},"3":{"item":"identity-14","amount":1},"2":{"item":"hamburger-1737859815","amount":5},"9":{"item":"cellphone-1737859815","amount":1},"7":{"item":"cocaine","amount":10},"6":{"item":"gift","amount":1}},"Stress":0,"Health":200,"Pos":{"y":-860.05,"x":178.58,"z":30.89},"Thirst":61,"Weight":40}');
INSERT INTO `playerdata` VALUES ('14', 'Experience', '{"Boosting":0}');
INSERT INTO `playerdata` VALUES ('15', 'Ammos', '[]');
INSERT INTO `playerdata` VALUES ('15', 'Attachs', '[]');
INSERT INTO `playerdata` VALUES ('15', 'Backpack', '[]');
INSERT INTO `playerdata` VALUES ('15', 'Clothings', '{"backpack":{"item":0,"texture":0},"hat":{"item":-1,"texture":0},"ear":{"item":10,"texture":0},"bracelet":{"item":8,"texture":0},"tshirt":{"item":15,"texture":0},"decals":{"item":0,"texture":0},"arms":{"item":0,"texture":0},"vest":{"item":0,"texture":0},"glass":{"item":15,"texture":0},"watch":{"item":16,"texture":0},"shoes":{"item":5,"texture":0},"pants":{"item":167,"texture":0},"accessory":{"item":0,"texture":0},"torso":{"item":10,"texture":0},"mask":{"item":0,"texture":0}}');
INSERT INTO `playerdata` VALUES ('15', 'Datatable', '{"Pos":{"x":209.79,"y":-913.55,"z":29.66},"Health":197,"Stress":0,"Inventory":{"9":{"amount":30,"item":"AMMO_9"},"7":{"item":"hamburger-1738114436","amount":4},"8":{"item":"cellphone-1738114436","amount":1},"5":{"item":"water","amount":1},"6":{"item":"dollars","amount":1400},"10":{"amount":1,"item":"ammo9box-A1V3U1I6W8","data":[]},"4":{"item":"identity-15","amount":1},"1":{"item":"WEAPON_M1911-1738118446-HA471M","amount":1},"2":{"item":"plasticbottle","amount":1}},"Weight":40,"Armour":0,"Hunger":86,"Skin":"mp_m_freemode_01","Thirst":86}');
INSERT INTO `playerdata` VALUES ('15', 'Experience', '{"Boosting":0,"Tows":0,"Milkman":0,"Minerman":0,"Delivery":0,"Taxi":0,"Hunting":0,"Tractor":0,"Lumberman":0,"Postal":0,"Transporter":0,"Fisherman":0,"Bus":0,"Garbageman":0,"Trucker":0}');
INSERT INTO `playerdata` VALUES ('15', 'nation_char', '{"bodyBlemishes-color":0,"chestHair-opacity":1.0,"hair":16,"blemishes":-1,"lipstick-opacity":1.0,"lipstick":-1,"neckThickness":0.0,"sunDamage-color":0,"thirdMix":0.0,"eyebrows":29,"chinBoneLowering":-1.0,"jawBoneBackLength":0.0,"cheeksBoneHigh":0.0,"noseBoneHigh":0.0,"overlay":0,"eyebrows-color":0,"addBodyBlemishes":-1,"skinSecond":26,"hair-highlightcolor":0,"eyebrows-opacity":1.0,"freckles-opacity":1.0,"ageing":-1,"addBodyBlemishes-opacity":1.0,"shapeMix":0.5,"makeup-color":-1,"skinFirst":0,"gender":"male","facialHair-opacity":1.0,"bodyBlemishes-opacity":1.0,"lipsThickness":0.94,"shapeThird":0,"sunDamage":-1,"complexion-color":0,"freckles":-1,"bodyBlemishes":-1,"makeup":-1,"complexion-opacity":1.0,"ageing-color":0,"eyeBrownHigh":0.0,"skinThird":0,"facialHair-color":54,"chestHair-color":0,"blush-color":0,"noseBoneTwist":0.0,"nosePeakLowering":0.0,"lipstick-color":0,"chestHair":-1,"shapeSecond":2,"ageing-opacity":1.0,"blush-opacity":1.0,"shapeFirst":23,"chinBoneLength":-1.0,"chinBoneWidth":0.0,"sunDamage-opacity":1.0,"skinMix":0.80000001192092,"addBodyBlemishes-color":0,"facialHair":3,"eyeBrownForward":0.0,"eyes":1,"freckles-color":0,"noseWidth":-0.84,"blemishes-opacity":1.0,"cheeksBoneWidth":0.0,"cheeksWidth":0.0,"eyesOpenning":0.0,"jawBoneWidth":-1.0,"blemishes-color":0,"chinHole":0.0,"hair-color":54,"nosePeakHeight":0.0,"nosePeakLength":0.0,"complexion":-1,"makeup-opacity":1.0,"blush":-1}');
INSERT INTO `playerdata` VALUES ('15', 'Rolepass', '{"Premium":0,"Finish":1738375200.0,"RolepassBuy":false,"Points":0,"Free":0}');

DROP TABLE IF EXISTS `port`;
CREATE TABLE `port` (
  `portId` int(11) NOT NULL AUTO_INCREMENT,
  `identity` longtext DEFAULT NULL,
  `user_id` text DEFAULT NULL,
  `portType` longtext DEFAULT NULL,
  `serial` longtext DEFAULT NULL,
  `nidentity` longtext DEFAULT NULL,
  `exam` longtext DEFAULT NULL,
  `date` text DEFAULT NULL,
  PRIMARY KEY (`portId`),
  KEY `portId` (`portId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


DROP TABLE IF EXISTS `prison`;
CREATE TABLE `prison` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `police` varchar(255) DEFAULT '0',
  `nuser_id` int(11) NOT NULL DEFAULT 0,
  `services` int(11) NOT NULL DEFAULT 0,
  `fines` int(20) NOT NULL DEFAULT 0,
  `text` longtext DEFAULT NULL,
  `date` text DEFAULT NULL,
  `cops` longtext NOT NULL DEFAULT '0',
  `association` longtext NOT NULL DEFAULT '0',
  `residual` text DEFAULT NULL,
  `url` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `prison` VALUES ('1', 'Not Braga', '1', '5', '8000', '<p data-criminal="true">USO INDEVIDO DA FARDA POLICIAL,</p>', '25/01/2025 ás 17:10', '1', '1', 'Não', '1');

DROP TABLE IF EXISTS `propertys`;
CREATE TABLE `propertys` (
  `Number` int(20) NOT NULL,
  `Passport` int(11) NOT NULL DEFAULT 0,
  `Interior` int(11) NOT NULL DEFAULT 0,
  `Keychain` int(11) NOT NULL DEFAULT 0,
  `Tax` int(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Number`) USING BTREE,
  KEY `Passport` (`Passport`),
  KEY `id` (`Number`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `propertys` VALUES ('104', '4', '3', '594338', '1739938701');
INSERT INTO `propertys` VALUES ('106', '4', '3', '688760', '1739938729');
INSERT INTO `propertys` VALUES ('107', '4', '3', '57012', '1739937704');
INSERT INTO `propertys` VALUES ('179', '1', '3', '82039', '1740719812');

DROP TABLE IF EXISTS `races`;
CREATE TABLE `races` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Race` int(3) NOT NULL DEFAULT 0,
  `Passport` int(5) NOT NULL DEFAULT 0,
  `Name` varchar(100) NOT NULL DEFAULT 'Individuo Indigente',
  `Vehicle` varchar(50) NOT NULL DEFAULT 'Sultan RS',
  `Points` int(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `Passport` (`Passport`),
  KEY `Race` (`Race`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `reports`;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `victim_id` text DEFAULT NULL,
  `police_name` text DEFAULT NULL,
  `solved` text DEFAULT NULL,
  `victim_name` text DEFAULT NULL,
  `created_at` text DEFAULT NULL,
  `victim_report` text DEFAULT NULL,
  `updated_at` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `portId` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


DROP TABLE IF EXISTS `skdev_blacklist`;
CREATE TABLE `skdev_blacklist` (
  `user_id` varchar(250) NOT NULL DEFAULT '',
  `valor` varchar(250) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `skdev_groups`;
CREATE TABLE `skdev_groups` (
  `grupo` varchar(250) NOT NULL DEFAULT '',
  `valores` varchar(10000) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `skdev_groupstaff`;
CREATE TABLE `skdev_groupstaff` (
  `nomedogrupo` varchar(250) NOT NULL DEFAULT '',
  `imagemdogrupo` varchar(250) NOT NULL DEFAULT '',
  `logdeenviarimagens` varchar(250) NOT NULL DEFAULT '',
  `logdecriacaodeorgs` varchar(250) NOT NULL DEFAULT '',
  `logdegerenciarorgs` varchar(250) NOT NULL DEFAULT '',
  `logdegerenciarstaff` varchar(250) NOT NULL DEFAULT '',
  `logdealteracaodelogs` varchar(250) NOT NULL DEFAULT '',
  `logdegerenciarcidadoes` varchar(250) NOT NULL DEFAULT '',
  `logdeupamentodemembros` varchar(250) NOT NULL DEFAULT '',
  `logderebaixamentodemembros` varchar(250) NOT NULL DEFAULT '',
  `logderemocaodemembros` varchar(250) NOT NULL DEFAULT '',
  `logdeadicaodemembros` varchar(250) NOT NULL DEFAULT '',
  `cargos` varchar(10000) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `skdev_groupstaff` VALUES ('Administração', './skdev/img/perfil-criar-grupo.png', '', '', '', '', '', '', '', '', '', '', '[{"Moderador":{"cargoingame":["Admin"],"cargoinvisivelstatus":false,"permissoes":[["Membros Protegidos","Criar Organizações","Gerenciar Organizações","Gerenciar Staff","Adicionar Membros","Upar Membros","Rebaixar Membros","Remover Membros","Gerenciar Cidadoes"]]}}]');

DROP TABLE IF EXISTS `skdev_permissoes`;
CREATE TABLE `skdev_permissoes` (
  `user_id` varchar(250) NOT NULL DEFAULT '',
  `imagemlink` varchar(250) NOT NULL DEFAULT '',
  `cargos` varchar(10000) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `skdev_punicoes_paineladm`;
CREATE TABLE `skdev_punicoes_paineladm` (
  `user_id` int(50) NOT NULL,
  `staff_id` int(50) NOT NULL,
  `advertencia` varchar(100) NOT NULL DEFAULT '',
  `motivo` varchar(100) NOT NULL DEFAULT '',
  `data` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_bank_invoices`;
CREATE TABLE `smartphone_bank_invoices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payee_id` int(11) NOT NULL,
  `payer_id` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL DEFAULT '',
  `value` int(11) NOT NULL,
  `paid` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_bank_invoices` VALUES ('1', '8', '6', 'Dia de pagamento', '100000', '0', '1738092609', '1738092609');

DROP TABLE IF EXISTS `smartphone_blocks`;
CREATE TABLE `smartphone_blocks` (
  `user_id` int(11) NOT NULL,
  `phone` varchar(32) NOT NULL,
  PRIMARY KEY (`user_id`,`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_calls`;
CREATE TABLE `smartphone_calls` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `initiator` varchar(50) NOT NULL,
  `target` varchar(50) NOT NULL,
  `duration` int(11) NOT NULL DEFAULT 0,
  `status` varchar(255) NOT NULL,
  `video` tinyint(4) NOT NULL DEFAULT 0,
  `anonymous` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `initiator_index` (`initiator`),
  KEY `target_index` (`target`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_calls` VALUES ('1', '259-423', '902-893', '8', 'ok', '0', '0', '1737379972');
INSERT INTO `smartphone_calls` VALUES ('2', '259-423', '902-893', '0', 'unanswered', '0', '0', '1737755857');
INSERT INTO `smartphone_calls` VALUES ('3', '259-423', '902-893', '0', 'unanswered', '0', '0', '1737757515');
INSERT INTO `smartphone_calls` VALUES ('4', '259-423', '902-893', '0', 'unanswered', '0', '0', '1737757747');
INSERT INTO `smartphone_calls` VALUES ('5', '741-879', '875-124', '10', 'ok', '0', '0', '1737763730');
INSERT INTO `smartphone_calls` VALUES ('6', '741-879', '875-124', '16', 'ok', '0', '0', '1737763748');
INSERT INTO `smartphone_calls` VALUES ('7', '741-879', '875-124', '14', 'ok', '0', '0', '1737763770');
INSERT INTO `smartphone_calls` VALUES ('8', '741-879', '295-435', '36', 'ok', '0', '0', '1737763811');
INSERT INTO `smartphone_calls` VALUES ('9', '259-423', '902-893', '0', 'unanswered', '0', '0', '1737848962');
INSERT INTO `smartphone_calls` VALUES ('10', '902-893', '259-423', '11', 'ok', '0', '0', '1737848978');
INSERT INTO `smartphone_calls` VALUES ('11', '902-893', '259-423', '0', 'unanswered', '0', '0', '1737855445');
INSERT INTO `smartphone_calls` VALUES ('12', '902-893', '259-423', '0', 'unanswered', '0', '0', '1737855449');
INSERT INTO `smartphone_calls` VALUES ('13', '902-893', '259-423', '0', 'unanswered', '0', '0', '1737855476');
INSERT INTO `smartphone_calls` VALUES ('14', '902-893', '259-423', '0', 'unanswered', '0', '0', '1737855556');
INSERT INTO `smartphone_calls` VALUES ('15', '902-893', '259-423', '0', 'unanswered', '1', '0', '1737855558');
INSERT INTO `smartphone_calls` VALUES ('16', '259-423', '902-893', '0', 'unanswered', '0', '0', '1738092564');
INSERT INTO `smartphone_calls` VALUES ('17', '259-423', '902-893', '15', 'ok', '0', '0', '1738092875');

DROP TABLE IF EXISTS `smartphone_casino`;
CREATE TABLE `smartphone_casino` (
  `user_id` int(11) NOT NULL,
  `balance` bigint(20) NOT NULL DEFAULT 0,
  `double` bigint(20) NOT NULL DEFAULT 0,
  `crash` bigint(20) NOT NULL DEFAULT 0,
  `mine` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_casino` VALUES ('2', '0', '0', '0', '0');
INSERT INTO `smartphone_casino` VALUES ('10', '0', '0', '0', '0');

DROP TABLE IF EXISTS `smartphone_contacts`;
CREATE TABLE `smartphone_contacts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner` varchar(50) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `owner_index` (`owner`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_contacts` VALUES ('1', '259-423', '902-893', 'Alcione');

DROP TABLE IF EXISTS `smartphone_gallery`;
CREATE TABLE `smartphone_gallery` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `folder` varchar(255) NOT NULL DEFAULT '/',
  `url` varchar(255) NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_gallery` VALUES ('1', '8', '/instagram', 'https://cdn.discordapp.com/attachments/1302814736538271805/1330427156844515369/1737268956925.jpg?ex=678df058&is=678c9ed8&hm=655abbc18e93dac920f409c8476b580e3f0e36e99c0423bd21d1d4e8a150d2c6&', '1737265345');
INSERT INTO `smartphone_gallery` VALUES ('2', '8', '/', 'https://cdn.discordapp.com/attachments/1302814736538271805/1330835265211600906/1737366257570.jpg?ex=678f6c6c&is=678e1aec&hm=cc1af4900061be2737caf62184ff6579448bb43b3fd8a8da788a6a62537c0982&', '1737362646');
INSERT INTO `smartphone_gallery` VALUES ('3', '8', '/', 'https://cdn.discordapp.com/attachments/1302814736538271805/1330933766843142164/1737389742664.jpg?ex=678fc829&is=678e76a9&hm=2aa7eeb772f2d8a69165df0f38c051bb230d8adcb81fbd4e5249fb008ecdc92b&', '1737386130');
INSERT INTO `smartphone_gallery` VALUES ('4', '8', '/whatsapp', 'https://cdn.discordapp.com/attachments/1302814736538271805/1330946402175418533/1737392755082.jpg?ex=678fd3ee&is=678e826e&hm=b279c85cc8aced807f44a1146122265c0ada159a927e2f1810c087c0f29fd3f3&', '1737389143');
INSERT INTO `smartphone_gallery` VALUES ('5', '6', '/whatsapp', 'https://cdn.discordapp.com/attachments/1302814736538271805/1330999185360683170/1737405333554.jpg?ex=67900516&is=678eb396&hm=61388ddd23045ec7e141fcc1aa47a632bfa20a0c5d0ad57cb06779c58e825315&', '1737401727');
INSERT INTO `smartphone_gallery` VALUES ('6', '8', '/whatsapp', 'https://cdn.discordapp.com/attachments/1302814736538271805/1332499995181449278/1737763165102.jpg?ex=67957ad3&is=67942953&hm=dbe5cc367499e6ff3a296f433b3091983fc7021bf8020995688344f4428af83d&', '1737759548');
INSERT INTO `smartphone_gallery` VALUES ('7', '8', '/whatsapp', 'https://cdn.discordapp.com/attachments/1302814736538271805/1332508415121031258/1737765172562.jpg?ex=679582aa&is=6794312a&hm=9f334eb4a8e6582a756e9abebe33e8e7aa6122224d87e66c7c1f668fb52e0566&', '1737761556');
INSERT INTO `smartphone_gallery` VALUES ('8', '10', '/olx', 'https://cdn.discordapp.com/attachments/1302814736538271805/1332561529865900052/1737777825823.jpg?ex=6795b422&is=679462a2&hm=a49c1bdd9847e2795cd6301a68d3f9b98b18f9f57dbdb6df2b1cad4f49130d1b&', '1737774219');
INSERT INTO `smartphone_gallery` VALUES ('9', '8', '/whatsapp', 'https://cdn.discordapp.com/attachments/1302814736538271805/1332906917739106304/1737860184528.jpg?ex=6796f5cd&is=6795a44d&hm=037c1205e3fb48fc9497cbfdbea158f3bcde46d3fe2cf06e367c23965e582769&', '1737856566');
INSERT INTO `smartphone_gallery` VALUES ('10', '8', '/whatsapp', 'https://cdn.discordapp.com/attachments/1302814736538271805/1332912459844948028/1737861505884.jpg?ex=6796faf6&is=6795a976&hm=3ea981c3bb1726958b7b00b6dee0082a70393acbc529019c2781c2169d0dae99&', '1737857887');
INSERT INTO `smartphone_gallery` VALUES ('11', '6', '/instagram', 'https://cdn.discordapp.com/attachments/1302814736538271805/1334009463165943881/1738123045468.jpg?ex=679af8a0&is=6799a720&hm=2d7821d05da49ee78832e8b5518339c9b54795716e9da61a29b62681b0b7c2e0&', '1738119440');

DROP TABLE IF EXISTS `smartphone_instagram`;
CREATE TABLE `smartphone_instagram` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `bio` varchar(255) NOT NULL,
  `avatarURL` varchar(255) DEFAULT NULL,
  `verified` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_instagram` VALUES ('1', '8', 'Beckeer', 'Rubi', '...', 'https://cdn.discordapp.com/attachments/1302814736538271805/1330427156844515369/1737268956925.jpg?ex=678df058&is=678c9ed8&hm=655abbc18e93dac920f409c8476b580e3f0e36e99c0423bd21d1d4e8a150d2c6&', '0');
INSERT INTO `smartphone_instagram` VALUES ('2', '6', 'Silva', 'Sertaneijo', 'Medico', 'https://cdn.discordapp.com/attachments/1302814736538271805/1334009463165943881/1738123045468.jpg?ex=679af8a0&is=6799a720&hm=2d7821d05da49ee78832e8b5518339c9b54795716e9da61a29b62681b0b7c2e0&', '1');

DROP TABLE IF EXISTS `smartphone_instagram_followers`;
CREATE TABLE `smartphone_instagram_followers` (
  `follower_id` bigint(20) NOT NULL,
  `profile_id` bigint(20) NOT NULL,
  PRIMARY KEY (`follower_id`,`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_instagram_likes`;
CREATE TABLE `smartphone_instagram_likes` (
  `post_id` bigint(20) NOT NULL,
  `profile_id` bigint(20) NOT NULL,
  PRIMARY KEY (`post_id`,`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_instagram_notifications`;
CREATE TABLE `smartphone_instagram_notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `content` varchar(512) NOT NULL,
  `saw` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_id_index` (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_instagram_posts`;
CREATE TABLE `smartphone_instagram_posts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) NOT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `created_at` bigint(20) NOT NULL,
  `comments` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_id_index` (`profile_id`),
  KEY `post_id_index` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_olx`;
CREATE TABLE `smartphone_olx` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `description` varchar(1024) NOT NULL,
  `images` varchar(1024) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_paypal_transactions`;
CREATE TABLE `smartphone_paypal_transactions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `target` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'payment',
  `description` varchar(255) DEFAULT NULL,
  `value` bigint(20) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_index` (`user_id`),
  KEY `target_index` (`target`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_paypal_transactions` VALUES ('1', '10', '10', 'deposit', NULL, '1301609', '1737871918');

DROP TABLE IF EXISTS `smartphone_tinder`;
CREATE TABLE `smartphone_tinder` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `bio` varchar(1024) NOT NULL,
  `age` tinyint(4) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `show_gender` tinyint(4) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `show_tags` tinyint(4) NOT NULL,
  `target` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_index` (`user_id`),
  KEY `gender_index` (`gender`),
  KEY `target_index` (`target`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_tinder_messages`;
CREATE TABLE `smartphone_tinder_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sender` int(11) NOT NULL,
  `target` int(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `liked` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_index` (`sender`),
  KEY `target_index` (`target`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_tinder_rating`;
CREATE TABLE `smartphone_tinder_rating` (
  `profile_id` int(11) NOT NULL,
  `rated_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`profile_id`,`rated_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_tor_messages`;
CREATE TABLE `smartphone_tor_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel` varchar(24) NOT NULL DEFAULT 'geral',
  `sender` varchar(50) NOT NULL,
  `image` varchar(512) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `channel_index` (`channel`),
  KEY `sender_index` (`sender`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_tor_payments`;
CREATE TABLE `smartphone_tor_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sender` bigint(20) NOT NULL,
  `target` bigint(20) NOT NULL,
  `amount` int(11) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_index` (`sender`),
  KEY `target_index` (`target`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_twitter_followers`;
CREATE TABLE `smartphone_twitter_followers` (
  `follower_id` bigint(20) NOT NULL,
  `profile_id` bigint(20) NOT NULL,
  KEY `profile_id_index` (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_twitter_likes`;
CREATE TABLE `smartphone_twitter_likes` (
  `tweet_id` bigint(20) NOT NULL,
  `profile_id` bigint(20) NOT NULL,
  KEY `tweet_id_index` (`tweet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_twitter_profiles`;
CREATE TABLE `smartphone_twitter_profiles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `avatarURL` varchar(255) NOT NULL,
  `bannerURL` varchar(255) NOT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `verified` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_twitter_tweets`;
CREATE TABLE `smartphone_twitter_tweets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) NOT NULL,
  `tweet_id` bigint(20) DEFAULT NULL,
  `content` varchar(280) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_id_index` (`profile_id`),
  KEY `tweet_id_index` (`tweet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_weazel`;
CREATE TABLE `smartphone_weazel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `tag` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(4096) NOT NULL,
  `imageURL` varchar(255) DEFAULT NULL,
  `videoURL` varchar(255) DEFAULT NULL,
  `views` int(11) NOT NULL DEFAULT 0,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_whatsapp`;
CREATE TABLE `smartphone_whatsapp` (
  `owner` varchar(32) NOT NULL,
  `avatarURL` varchar(255) DEFAULT NULL,
  `read_receipts` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_whatsapp` VALUES ('259-423', NULL, '1');
INSERT INTO `smartphone_whatsapp` VALUES ('295-435', NULL, '1');
INSERT INTO `smartphone_whatsapp` VALUES ('571-361', NULL, '1');
INSERT INTO `smartphone_whatsapp` VALUES ('666-666', NULL, '1');
INSERT INTO `smartphone_whatsapp` VALUES ('875-124', NULL, '1');
INSERT INTO `smartphone_whatsapp` VALUES ('902-893', NULL, '1');

DROP TABLE IF EXISTS `smartphone_whatsapp_channels`;
CREATE TABLE `smartphone_whatsapp_channels` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) NOT NULL,
  `target` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_index` (`sender`),
  KEY `target_index` (`target`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_whatsapp_channels` VALUES ('1', '259-423', '902-893');

DROP TABLE IF EXISTS `smartphone_whatsapp_groups`;
CREATE TABLE `smartphone_whatsapp_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `avatarURL` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `members` varchar(2048) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `smartphone_whatsapp_messages`;
CREATE TABLE `smartphone_whatsapp_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel_id` bigint(20) unsigned NOT NULL,
  `sender` varchar(50) NOT NULL,
  `image` varchar(512) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  `deleted_by` varchar(255) DEFAULT NULL,
  `readed` tinyint(4) NOT NULL DEFAULT 0,
  `saw_at` bigint(20) NOT NULL DEFAULT 0,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_index` (`sender`),
  KEY `channel_id_index` (`channel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `smartphone_whatsapp_messages` VALUES ('1', '1', '259-423', NULL, NULL, 'Oiee', '259-423', '1', '1737366403', '1737366378');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('2', '1', '259-423', 'https://cdn.discordapp.com/attachments/1302814736538271805/1330835265211600906/1737366257570.jpg?ex=678f6c6c&is=678e1aec&hm=cc1af4900061be2737caf62184ff6579448bb43b3fd8a8da788a6a62537c0982&', NULL, '', '259-423', '1', '1737366403', '1737366396');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('3', '1', '902-893', NULL, NULL, 'KKKKKKKKKKKK', '259-423', '1', '1737366911', '1737366411');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('4', '1', '259-423', NULL, NULL, 'Zeeba', '259-423', '1', '1737382771', '1737377502');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('5', '1', '259-423', NULL, NULL, 'Tudo que importa', '259-423', '1', '1737382771', '1737377508');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('6', '1', '902-893', NULL, NULL, 'vem aqui pra ver se vc ouve o tet tentando me ligar', '259-423', '1', '1737386199', '1737382815');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('7', '1', '259-423', 'https://cdn.discordapp.com/attachments/1302814736538271805/1330946402175418533/1737392755082.jpg?ex=678fd3ee&is=678e826e&hm=b279c85cc8aced807f44a1146122265c0ada159a927e2f1810c087c0f29fd3f3&', NULL, '', '259-423', '1', '1737389148', '1737389143');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('8', '1', '902-893', NULL, NULL, 'que houve com essa sujeira menina rsrsrsrs', '259-423', '1', '1737389173', '1737389164');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('9', '1', '259-423', NULL, NULL, 'É marca do tiro', '259-423', '1', '1737389229', '1737389179');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('10', '1', '902-893', NULL, NULL, 'rsrsrsrsrsrsrsrs', '259-423', '1', '1737396158', '1737389232');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('11', '1', '902-893', NULL, NULL, 'temos que tirar uma fr junto em', '259-423', '1', '1737396158', '1737389240');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('12', '1', '902-893', 'https://cdn.discordapp.com/attachments/1302814736538271805/1330999185360683170/1737405333554.jpg?ex=67900516&is=678eb396&hm=61388ddd23045ec7e141fcc1aa47a632bfa20a0c5d0ad57cb06779c58e825315&', NULL, '', '259-423', '1', '1737401732', '1737401727');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('13', '1', '902-893', NULL, NULL, 'foi fazer o tolete neh', '259-423', '1', '1737747755', '1737747555');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('14', '1', '902-893', NULL, NULL, 'rsrsrsrsrsrsrsrsrsrsrsrsrsrsrs', '259-423', '1', '1737747755', '1737747559');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('15', '1', '259-423', NULL, NULL, 'Andaaaaaaaaa', '259-423', '1', '1737757668', '1737757493');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('16', '1', '259-423', NULL, NULL, 'Me ajudaaaaaaaaa', '259-423', '1', '1737757668', '1737757663');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('17', '1', '259-423', NULL, NULL, 'Cadee voceeeeeeeeeeeee', '259-423', '1', '1737757668', '1737757668');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('18', '1', '902-893', NULL, NULL, 'que houve?', '259-423', '1', '1737757703', '1737757672');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('19', '1', '259-423', NULL, NULL, 'Tem um diabo eu acho na loja de cabelereito', '259-423', '1', '1737757683', '1737757683');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('20', '1', '902-893', NULL, NULL, 'como assim', '259-423', '1', '1737757703', '1737757694');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('21', '1', '902-893', NULL, NULL, '?', '259-423', '1', '1737757703', '1737757695');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('22', '1', '259-423', NULL, NULL, 'Uma voz feiaaaaaaaa', '259-423', '1', '1737761566', '1737757714');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('23', '1', '902-893', NULL, NULL, 'calma vo da tp ai', '259-423', '1', '1737757715', '1737757714');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('24', '1', '259-423', NULL, NULL, 'Vo conta pro atilaa', '259-423', '1', '1737761566', '1737757752');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('25', '1', '259-423', NULL, NULL, 'Que tem espirito aquiii na cidade', '259-423', '1', '1737761566', '1737757761');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('26', '1', '259-423', NULL, NULL, 'Eu não gosto dessas coisas', '259-423', '1', '1737761566', '1737757768');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('27', '1', '259-423', 'https://cdn.discordapp.com/attachments/1302814736538271805/1332499995181449278/1737763165102.jpg?ex=67957ad3&is=67942953&hm=dbe5cc367499e6ff3a296f433b3091983fc7021bf8020995688344f4428af83d&', NULL, '', '259-423', '1', '1737761566', '1737759548');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('28', '1', '259-423', 'https://cdn.discordapp.com/attachments/1302814736538271805/1332508415121031258/1737765172562.jpg?ex=679582aa&is=6794312a&hm=9f334eb4a8e6582a756e9abebe33e8e7aa6122224d87e66c7c1f668fb52e0566&', NULL, '', '259-423', '1', '1737761566', '1737761556');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('29', '1', '902-893', NULL, NULL, 'fui buscar minha esposa', '259-423', '1', '1737848960', '1737763240');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('30', '1', '902-893', NULL, NULL, 'fiquei dormindo la na cidade', '259-423', '1', '1737848960', '1737763248');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('31', '1', '902-893', NULL, NULL, 'ta onde?', '259-423', '1', '1737855678', '1737855479');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('32', '1', '259-423', NULL, NULL, 'HP', '259-423', '1', '1737855686', '1737855680');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('33', '1', '902-893', NULL, NULL, 'me deixou aqui abandonado na bahia', '259-423', '1', '1737856554', '1737855695');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('34', '1', '259-423', 'https://cdn.discordapp.com/attachments/1302814736538271805/1332906917739106304/1737860184528.jpg?ex=6796f5cd&is=6795a44d&hm=037c1205e3fb48fc9497cbfdbea158f3bcde46d3fe2cf06e367c23965e582769&', NULL, '', '259-423', '1', '1737856574', '1737856566');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('35', '1', '259-423', NULL, NULL, 'Ah paraa', '259-423', '1', '1737856574', '1737856568');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('36', '1', '902-893', NULL, NULL, 'kkkkkkkkkkkkkkkkkkkkkkkkkkkkkk', '259-423', '1', '1737857876', '1737856586');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('37', '1', '902-893', NULL, NULL, 'tu ja axa essas coisas neh', '259-423', '1', '1737857876', '1737856590');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('38', '1', '902-893', NULL, NULL, 'eu nem tinha visto', '259-423', '1', '1737857876', '1737856595');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('39', '1', '902-893', NULL, NULL, 'kkkkkkkkkkkkkkkkkkkkkkkkkkk', '259-423', '1', '1737857876', '1737856596');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('40', '1', '259-423', 'https://cdn.discordapp.com/attachments/1302814736538271805/1332912459844948028/1737861505884.jpg?ex=6796faf6&is=6795a976&hm=3ea981c3bb1726958b7b00b6dee0082a70393acbc529019c2781c2169d0dae99&', NULL, '', '259-423', '1', '1737857893', '1737857887');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('41', '1', '902-893', NULL, NULL, 'uma garça', '259-423', '1', '1738085156', '1737857906');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('42', '1', '902-893', NULL, NULL, 'que top', '259-423', '1', '1738085156', '1737857909');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('43', '1', '259-423', NULL, NULL, 'Conserta minha motooooooooo', '259-423', '1', '1738090963', '1738090860');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('44', '1', '259-423', NULL, '[-1603.78,-950.25,13.02]', '', '259-423', '1', '1738090963', '1738090862');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('45', '1', '259-423', NULL, NULL, 'Qual seu id?', NULL, '1', '1738092620', '1738092572');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('46', '1', '902-893', NULL, NULL, '6', NULL, '1', '1738092578', '1738092578');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('47', '1', '902-893', NULL, NULL, 'https://cdn.discordapp.com/attachments/1302814736538271805/1333897033110655008/1738096240248.webm?ex=679a8feb&is=67993e6b&hm=fcf3fa3753117fd2e04279012ee02a4b75f73dea15bb222f438daa4effde0485&.webm', NULL, '1', '1738092631', '1738092628');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('48', '1', '902-893', NULL, NULL, 'https://cdn.discordapp.com/attachments/1302814736538271805/1333897061631791185/1738096247010.webm?ex=679a8ff2&is=67993e72&hm=fcb35f17df29ba33ac2bcb7caa024318c79f3247d8b52f313b5a17b45ccefada&.webm', NULL, '1', '1738092635', '1738092635');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('49', '1', '259-423', NULL, NULL, 'Saiu nada', NULL, '1', '1738092640', '1738092640');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('50', '1', '902-893', NULL, NULL, 'https://cdn.discordapp.com/attachments/1302814736538271805/1333897087351525489/1738096253254.webm?ex=679a8ff8&is=67993e78&hm=b646cf43a5b32864b257be53c1df64a5dc37645c192b0ce45fc91a3621120fa3&.webm', NULL, '1', '1738092641', '1738092641');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('51', '1', '902-893', NULL, NULL, 'https://cdn.discordapp.com/attachments/1302814736538271805/1333897109216428113/1738096258464.webm?ex=679a8ffd&is=67993e7d&hm=248cf32c46710973236a5146a92949489015279a60d2ce3edd04e6e0611d75ea&.webm', NULL, '1', '1738092863', '1738092646');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('52', '1', '902-893', NULL, NULL, 'saiu nada?', NULL, '1', '1738092863', '1738092648');
INSERT INTO `smartphone_whatsapp_messages` VALUES ('53', '1', '902-893', NULL, NULL, 'chegou uma fatura sua pra eu pagar aqui', NULL, '1', '1738092863', '1738092663');

DROP TABLE IF EXISTS `taxs`;
CREATE TABLE `taxs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Passport` int(10) NOT NULL DEFAULT 0,
  `Name` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL,
  `Hour` varchar(50) NOT NULL,
  `Value` int(11) NOT NULL,
  `Message` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Passport` (`Passport`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `taxs` VALUES ('1', '1', 'Propriedades', '29/01/2025', '03:16', '1000000', 'Compra de propriedade.');

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Passport` int(10) NOT NULL DEFAULT 0,
  `Type` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL,
  `Value` int(11) NOT NULL,
  `Balance` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Passport` (`Passport`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=911 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `transactions` VALUES ('1', '1', 'entry', '16/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('2', '1', 'entry', '16/01/2025', '1100', '5000');
INSERT INTO `transactions` VALUES ('3', '1', 'entry', '16/01/2025', '998000', '6100');
INSERT INTO `transactions` VALUES ('4', '1', 'exit', '16/01/2025', '1000', '1004100');
INSERT INTO `transactions` VALUES ('5', '1', 'entry', '16/01/2025', '1100', '1003100');
INSERT INTO `transactions` VALUES ('6', '2', 'entry', '16/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('7', '1', 'entry', '16/01/2025', '1', '1004200');
INSERT INTO `transactions` VALUES ('8', '1', 'exit', '16/01/2025', '2000', '1004201');
INSERT INTO `transactions` VALUES ('9', '1', 'entry', '16/01/2025', '1100', '1002201');
INSERT INTO `transactions` VALUES ('10', '1', 'exit', '16/01/2025', '180', '1003301');
INSERT INTO `transactions` VALUES ('11', '1', 'entry', '16/01/2025', '1', '1003121');
INSERT INTO `transactions` VALUES ('12', '1', 'entry', '16/01/2025', '50', '1003122');
INSERT INTO `transactions` VALUES ('13', '1', 'entry', '16/01/2025', '1100', '1003172');
INSERT INTO `transactions` VALUES ('14', '1', 'entry', '16/01/2025', '1', '1004272');
INSERT INTO `transactions` VALUES ('15', '1', 'entry', '16/01/2025', '1100', '1004273');
INSERT INTO `transactions` VALUES ('16', '1', 'entry', '16/01/2025', '1', '1005373');
INSERT INTO `transactions` VALUES ('17', '3', 'entry', '16/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('18', '4', 'entry', '16/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('19', '1', 'entry', '16/01/2025', '1100', '1005374');
INSERT INTO `transactions` VALUES ('20', '1', 'entry', '16/01/2025', '1100', '1006474');
INSERT INTO `transactions` VALUES ('21', '1', 'exit', '16/01/2025', '7', '1007574');
INSERT INTO `transactions` VALUES ('22', '1', 'entry', '16/01/2025', '1100', '1007567');
INSERT INTO `transactions` VALUES ('23', '1', 'entry', '16/01/2025', '1100', '1008667');
INSERT INTO `transactions` VALUES ('24', '1', 'entry', '16/01/2025', '1100', '1009767');
INSERT INTO `transactions` VALUES ('25', '1', 'entry', '16/01/2025', '1100', '1010867');
INSERT INTO `transactions` VALUES ('26', '1', 'entry', '16/01/2025', '1100', '1011967');
INSERT INTO `transactions` VALUES ('27', '3', 'exit', '16/01/2025', '6', '5000');
INSERT INTO `transactions` VALUES ('28', '3', 'exit', '16/01/2025', '180', '4994');
INSERT INTO `transactions` VALUES ('29', '3', 'exit', '16/01/2025', '7', '4814');
INSERT INTO `transactions` VALUES ('30', '1', 'exit', '16/01/2025', '180', '1013067');
INSERT INTO `transactions` VALUES ('31', '1', 'entry', '16/01/2025', '1100', '1012887');
INSERT INTO `transactions` VALUES ('32', '1', 'entry', '16/01/2025', '1', '1013987');
INSERT INTO `transactions` VALUES ('33', '1', 'entry', '16/01/2025', '1100', '1013988');
INSERT INTO `transactions` VALUES ('34', '1', 'entry', '17/01/2025', '1', '1015088');
INSERT INTO `transactions` VALUES ('35', '1', 'exit', '17/01/2025', '100', '1015089');
INSERT INTO `transactions` VALUES ('36', '1', 'exit', '17/01/2025', '100', '1014989');
INSERT INTO `transactions` VALUES ('37', '1', 'exit', '17/01/2025', '100', '1014889');
INSERT INTO `transactions` VALUES ('38', '1', 'exit', '17/01/2025', '100', '1014789');
INSERT INTO `transactions` VALUES ('39', '1', 'entry', '17/01/2025', '1', '1014689');
INSERT INTO `transactions` VALUES ('40', '1', 'entry', '17/01/2025', '1100', '1014690');
INSERT INTO `transactions` VALUES ('41', '1', 'entry', '17/01/2025', '1', '1015790');
INSERT INTO `transactions` VALUES ('42', '1', 'entry', '17/01/2025', '1100', '1015791');
INSERT INTO `transactions` VALUES ('43', '1', 'entry', '17/01/2025', '1', '1016891');
INSERT INTO `transactions` VALUES ('44', '1', 'entry', '17/01/2025', '1100', '1016892');
INSERT INTO `transactions` VALUES ('45', '1', 'entry', '17/01/2025', '1', '1017992');
INSERT INTO `transactions` VALUES ('46', '1', 'entry', '17/01/2025', '1100', '1017993');
INSERT INTO `transactions` VALUES ('47', '1', 'entry', '17/01/2025', '1', '1019093');
INSERT INTO `transactions` VALUES ('48', '1', 'entry', '17/01/2025', '1100', '1019094');
INSERT INTO `transactions` VALUES ('49', '1', 'entry', '17/01/2025', '1100', '1020194');
INSERT INTO `transactions` VALUES ('50', '2', 'entry', '17/01/2025', '1', '5000');
INSERT INTO `transactions` VALUES ('51', '1', 'entry', '17/01/2025', '1100', '1021294');
INSERT INTO `transactions` VALUES ('52', '2', 'entry', '17/01/2025', '1', '5001');
INSERT INTO `transactions` VALUES ('53', '1', 'entry', '17/01/2025', '1100', '1022394');
INSERT INTO `transactions` VALUES ('54', '2', 'entry', '17/01/2025', '1', '5002');
INSERT INTO `transactions` VALUES ('55', '1', 'entry', '18/01/2025', '1', '1023494');
INSERT INTO `transactions` VALUES ('56', '1', 'entry', '18/01/2025', '1100', '1023495');
INSERT INTO `transactions` VALUES ('57', '1', 'entry', '18/01/2025', '1', '1024595');
INSERT INTO `transactions` VALUES ('58', '1', 'entry', '18/01/2025', '1100', '1024596');
INSERT INTO `transactions` VALUES ('59', '1', 'entry', '18/01/2025', '1', '1025696');
INSERT INTO `transactions` VALUES ('60', '1', 'entry', '18/01/2025', '1100', '1025697');
INSERT INTO `transactions` VALUES ('61', '1', 'entry', '18/01/2025', '1', '1026797');
INSERT INTO `transactions` VALUES ('62', '1', 'entry', '18/01/2025', '1100', '1026798');
INSERT INTO `transactions` VALUES ('63', '1', 'entry', '18/01/2025', '1', '1027898');
INSERT INTO `transactions` VALUES ('64', '1', 'entry', '18/01/2025', '1100', '1027899');
INSERT INTO `transactions` VALUES ('65', '5', 'entry', '18/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('66', '6', 'entry', '18/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('67', '7', 'entry', '18/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('68', '1', 'entry', '18/01/2025', '1100', '1028999');
INSERT INTO `transactions` VALUES ('69', '1', 'entry', '18/01/2025', '1', '1030099');
INSERT INTO `transactions` VALUES ('70', '1', 'entry', '18/01/2025', '1100', '1030100');
INSERT INTO `transactions` VALUES ('71', '1', 'entry', '18/01/2025', '1', '1031200');
INSERT INTO `transactions` VALUES ('72', '1', 'entry', '18/01/2025', '1100', '1031201');
INSERT INTO `transactions` VALUES ('73', '1', 'entry', '18/01/2025', '1', '1032301');
INSERT INTO `transactions` VALUES ('74', '1', 'entry', '19/01/2025', '1100', '1032302');
INSERT INTO `transactions` VALUES ('75', '1', 'entry', '19/01/2025', '1', '1033402');
INSERT INTO `transactions` VALUES ('76', '4', 'exit', '19/01/2025', '910', '5000');
INSERT INTO `transactions` VALUES ('77', '1', 'entry', '19/01/2025', '1100', '1033403');
INSERT INTO `transactions` VALUES ('78', '1', 'entry', '19/01/2025', '1', '1034503');
INSERT INTO `transactions` VALUES ('79', '6', 'exit', '19/01/2025', '500', '5000');
INSERT INTO `transactions` VALUES ('80', '1', 'entry', '19/01/2025', '1100', '1034504');
INSERT INTO `transactions` VALUES ('81', '1', 'entry', '19/01/2025', '1', '1035604');
INSERT INTO `transactions` VALUES ('82', '7', 'exit', '19/01/2025', '520', '5000');
INSERT INTO `transactions` VALUES ('83', '6', 'exit', '19/01/2025', '500', '4500');
INSERT INTO `transactions` VALUES ('84', '7', 'entry', '19/01/2025', '1', '4480');
INSERT INTO `transactions` VALUES ('85', '6', 'entry', '19/01/2025', '1', '4000');
INSERT INTO `transactions` VALUES ('86', '7', 'exit', '19/01/2025', '300', '4481');
INSERT INTO `transactions` VALUES ('87', '1', 'entry', '19/01/2025', '1', '1035605');
INSERT INTO `transactions` VALUES ('88', '1', 'entry', '19/01/2025', '1100', '1035606');
INSERT INTO `transactions` VALUES ('89', '6', 'exit', '19/01/2025', '520', '4001');
INSERT INTO `transactions` VALUES ('90', '6', 'exit', '19/01/2025', '190', '3481');
INSERT INTO `transactions` VALUES ('91', '8', 'entry', '19/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('92', '7', 'entry', '19/01/2025', '1', '4181');
INSERT INTO `transactions` VALUES ('93', '6', 'entry', '19/01/2025', '1', '3291');
INSERT INTO `transactions` VALUES ('94', '6', 'exit', '19/01/2025', '510', '3292');
INSERT INTO `transactions` VALUES ('95', '1', 'exit', '19/01/2025', '5', '1036706');
INSERT INTO `transactions` VALUES ('96', '6', 'exit', '19/01/2025', '610', '2782');
INSERT INTO `transactions` VALUES ('97', '7', 'exit', '19/01/2025', '610', '4182');
INSERT INTO `transactions` VALUES ('98', '7', 'exit', '19/01/2025', '90', '3572');
INSERT INTO `transactions` VALUES ('99', '7', 'exit', '19/01/2025', '200', '3482');
INSERT INTO `transactions` VALUES ('100', '7', 'exit', '19/01/2025', '470', '3282');
INSERT INTO `transactions` VALUES ('101', '7', 'entry', '19/01/2025', '1', '2812');
INSERT INTO `transactions` VALUES ('102', '6', 'entry', '19/01/2025', '1', '2172');
INSERT INTO `transactions` VALUES ('103', '6', 'exit', '19/01/2025', '880', '2173');
INSERT INTO `transactions` VALUES ('104', '9', 'entry', '19/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('105', '6', 'exit', '19/01/2025', '320', '1293');
INSERT INTO `transactions` VALUES ('106', '1', 'entry', '19/01/2025', '1100', '1036701');
INSERT INTO `transactions` VALUES ('107', '6', 'entry', '19/01/2025', '1', '973');
INSERT INTO `transactions` VALUES ('108', '1', 'entry', '19/01/2025', '1100', '1037801');
INSERT INTO `transactions` VALUES ('109', '8', 'entry', '19/01/2025', '1', '5000');
INSERT INTO `transactions` VALUES ('110', '1', 'entry', '19/01/2025', '1', '1038901');
INSERT INTO `transactions` VALUES ('111', '1', 'entry', '19/01/2025', '1100', '1038902');
INSERT INTO `transactions` VALUES ('112', '9', 'entry', '19/01/2025', '1', '5000');
INSERT INTO `transactions` VALUES ('113', '8', 'entry', '19/01/2025', '1', '5001');
INSERT INTO `transactions` VALUES ('114', '6', 'entry', '19/01/2025', '1', '974');
INSERT INTO `transactions` VALUES ('115', '1', 'entry', '19/01/2025', '1', '1040002');
INSERT INTO `transactions` VALUES ('116', '1', 'entry', '19/01/2025', '1100', '1040003');
INSERT INTO `transactions` VALUES ('117', '1', 'entry', '19/01/2025', '1100', '1041103');
INSERT INTO `transactions` VALUES ('118', '1', 'entry', '19/01/2025', '1', '1042203');
INSERT INTO `transactions` VALUES ('119', '1', 'entry', '19/01/2025', '1', '1042204');
INSERT INTO `transactions` VALUES ('120', '1', 'entry', '19/01/2025', '1100', '1042205');
INSERT INTO `transactions` VALUES ('121', '1', 'entry', '19/01/2025', '1', '1043305');
INSERT INTO `transactions` VALUES ('122', '1', 'entry', '19/01/2025', '1', '1043306');
INSERT INTO `transactions` VALUES ('123', '1', 'entry', '19/01/2025', '1100', '1043307');
INSERT INTO `transactions` VALUES ('124', '1', 'entry', '19/01/2025', '1', '1044407');
INSERT INTO `transactions` VALUES ('125', '1', 'entry', '19/01/2025', '1', '1044408');
INSERT INTO `transactions` VALUES ('126', '1', 'entry', '19/01/2025', '1100', '1044409');
INSERT INTO `transactions` VALUES ('127', '1', 'entry', '19/01/2025', '1', '1045509');
INSERT INTO `transactions` VALUES ('128', '1', 'entry', '19/01/2025', '1', '1045510');
INSERT INTO `transactions` VALUES ('129', '1', 'entry', '19/01/2025', '1100', '1045511');
INSERT INTO `transactions` VALUES ('130', '1', 'entry', '19/01/2025', '1', '1046611');
INSERT INTO `transactions` VALUES ('131', '1', 'entry', '19/01/2025', '1', '1046612');
INSERT INTO `transactions` VALUES ('132', '1', 'entry', '19/01/2025', '3500', '1046613');
INSERT INTO `transactions` VALUES ('133', '1', 'entry', '19/01/2025', '3500', '1050113');
INSERT INTO `transactions` VALUES ('134', '1', 'entry', '19/01/2025', '1100', '1053613');
INSERT INTO `transactions` VALUES ('135', '1', 'entry', '19/01/2025', '1', '1054713');
INSERT INTO `transactions` VALUES ('136', '4', 'exit', '19/01/2025', '100', '4090');
INSERT INTO `transactions` VALUES ('137', '4', 'exit', '19/01/2025', '50', '3990');
INSERT INTO `transactions` VALUES ('138', '4', 'exit', '19/01/2025', '50', '3940');
INSERT INTO `transactions` VALUES ('139', '4', 'exit', '19/01/2025', '50', '3890');
INSERT INTO `transactions` VALUES ('140', '1', 'entry', '19/01/2025', '1100', '1054714');
INSERT INTO `transactions` VALUES ('141', '1', 'entry', '19/01/2025', '3500', '1055814');
INSERT INTO `transactions` VALUES ('142', '1', 'entry', '19/01/2025', '1', '1059314');
INSERT INTO `transactions` VALUES ('143', '4', 'exit', '19/01/2025', '50', '3840');
INSERT INTO `transactions` VALUES ('144', '4', 'exit', '19/01/2025', '100', '3790');
INSERT INTO `transactions` VALUES ('145', '4', 'exit', '19/01/2025', '50', '3690');
INSERT INTO `transactions` VALUES ('146', '4', 'exit', '19/01/2025', '50', '3640');
INSERT INTO `transactions` VALUES ('147', '4', 'exit', '19/01/2025', '50', '3590');
INSERT INTO `transactions` VALUES ('148', '4', 'exit', '19/01/2025', '50', '3540');
INSERT INTO `transactions` VALUES ('149', '4', 'exit', '19/01/2025', '50', '3490');
INSERT INTO `transactions` VALUES ('150', '4', 'exit', '19/01/2025', '50', '3440');
INSERT INTO `transactions` VALUES ('151', '4', 'exit', '19/01/2025', '50', '3390');
INSERT INTO `transactions` VALUES ('152', '4', 'exit', '19/01/2025', '50', '3340');
INSERT INTO `transactions` VALUES ('153', '4', 'exit', '19/01/2025', '50', '3290');
INSERT INTO `transactions` VALUES ('154', '4', 'exit', '19/01/2025', '50', '3240');
INSERT INTO `transactions` VALUES ('155', '1', 'entry', '19/01/2025', '1100', '1059315');
INSERT INTO `transactions` VALUES ('156', '1', 'entry', '19/01/2025', '3500', '1060415');
INSERT INTO `transactions` VALUES ('157', '1', 'entry', '19/01/2025', '1', '1063915');
INSERT INTO `transactions` VALUES ('158', '4', 'exit', '19/01/2025', '100', '3190');
INSERT INTO `transactions` VALUES ('159', '1', 'entry', '19/01/2025', '1100', '1063916');
INSERT INTO `transactions` VALUES ('160', '1', 'entry', '19/01/2025', '3500', '1065016');
INSERT INTO `transactions` VALUES ('161', '1', 'entry', '19/01/2025', '1', '1068516');
INSERT INTO `transactions` VALUES ('162', '4', 'entry', '19/01/2025', '1', '3090');
INSERT INTO `transactions` VALUES ('163', '1', 'entry', '19/01/2025', '1100', '1068517');
INSERT INTO `transactions` VALUES ('164', '1', 'entry', '19/01/2025', '3500', '1069617');
INSERT INTO `transactions` VALUES ('165', '1', 'entry', '19/01/2025', '1', '1073117');
INSERT INTO `transactions` VALUES ('166', '4', 'entry', '19/01/2025', '1', '3091');
INSERT INTO `transactions` VALUES ('167', '1', 'entry', '19/01/2025', '1100', '1073118');
INSERT INTO `transactions` VALUES ('168', '1', 'entry', '19/01/2025', '3500', '1074218');
INSERT INTO `transactions` VALUES ('169', '1', 'entry', '19/01/2025', '1', '1077718');
INSERT INTO `transactions` VALUES ('170', '4', 'exit', '19/01/2025', '110', '3092');
INSERT INTO `transactions` VALUES ('171', '4', 'entry', '19/01/2025', '1', '2982');
INSERT INTO `transactions` VALUES ('172', '1', 'entry', '19/01/2025', '1100', '1077719');
INSERT INTO `transactions` VALUES ('173', '1', 'entry', '19/01/2025', '3500', '1078819');
INSERT INTO `transactions` VALUES ('174', '1', 'entry', '19/01/2025', '1', '1082319');
INSERT INTO `transactions` VALUES ('175', '4', 'exit', '19/01/2025', '100', '2983');
INSERT INTO `transactions` VALUES ('176', '4', 'exit', '19/01/2025', '100', '2883');
INSERT INTO `transactions` VALUES ('177', '1', 'entry', '19/01/2025', '1100', '1082320');
INSERT INTO `transactions` VALUES ('178', '1', 'entry', '19/01/2025', '3500', '1083420');
INSERT INTO `transactions` VALUES ('179', '4', 'entry', '19/01/2025', '1', '2783');
INSERT INTO `transactions` VALUES ('180', '1', 'entry', '19/01/2025', '1100', '1086920');
INSERT INTO `transactions` VALUES ('181', '1', 'entry', '19/01/2025', '3500', '1088020');
INSERT INTO `transactions` VALUES ('182', '1', 'entry', '20/01/2025', '1100', '1091520');
INSERT INTO `transactions` VALUES ('183', '1', 'entry', '20/01/2025', '3500', '1092620');
INSERT INTO `transactions` VALUES ('184', '1', 'entry', '20/01/2025', '1100', '1096120');
INSERT INTO `transactions` VALUES ('185', '1', 'entry', '20/01/2025', '3500', '1097220');
INSERT INTO `transactions` VALUES ('186', '1', 'entry', '20/01/2025', '1', '1100720');
INSERT INTO `transactions` VALUES ('187', '1', 'entry', '20/01/2025', '1100', '1100721');
INSERT INTO `transactions` VALUES ('188', '1', 'entry', '20/01/2025', '3500', '1101821');
INSERT INTO `transactions` VALUES ('189', '4', 'exit', '20/01/2025', '750', '2784');
INSERT INTO `transactions` VALUES ('190', '4', 'entry', '20/01/2025', '2000', '2034');
INSERT INTO `transactions` VALUES ('191', '4', 'entry', '20/01/2025', '2000', '4034');
INSERT INTO `transactions` VALUES ('192', '4', 'entry', '20/01/2025', '2000', '6034');
INSERT INTO `transactions` VALUES ('193', '4', 'entry', '20/01/2025', '2000', '8034');
INSERT INTO `transactions` VALUES ('194', '4', 'entry', '20/01/2025', '2000', '10034');
INSERT INTO `transactions` VALUES ('195', '4', 'entry', '20/01/2025', '2000', '12034');
INSERT INTO `transactions` VALUES ('196', '4', 'entry', '20/01/2025', '2000', '14034');
INSERT INTO `transactions` VALUES ('197', '4', 'entry', '20/01/2025', '2000', '16034');
INSERT INTO `transactions` VALUES ('198', '4', 'entry', '20/01/2025', '2000', '18034');
INSERT INTO `transactions` VALUES ('199', '4', 'entry', '20/01/2025', '2000', '20034');
INSERT INTO `transactions` VALUES ('200', '4', 'entry', '20/01/2025', '2000', '22034');
INSERT INTO `transactions` VALUES ('201', '4', 'entry', '20/01/2025', '2000', '24034');
INSERT INTO `transactions` VALUES ('202', '4', 'entry', '20/01/2025', '2000', '26034');
INSERT INTO `transactions` VALUES ('203', '4', 'entry', '20/01/2025', '2000', '28034');
INSERT INTO `transactions` VALUES ('204', '4', 'entry', '20/01/2025', '2000', '30034');
INSERT INTO `transactions` VALUES ('205', '4', 'entry', '20/01/2025', '2000', '32034');
INSERT INTO `transactions` VALUES ('206', '4', 'entry', '20/01/2025', '2000', '34034');
INSERT INTO `transactions` VALUES ('207', '4', 'entry', '20/01/2025', '2000', '36034');
INSERT INTO `transactions` VALUES ('208', '4', 'entry', '20/01/2025', '2000', '38034');
INSERT INTO `transactions` VALUES ('209', '4', 'entry', '20/01/2025', '2000', '40034');
INSERT INTO `transactions` VALUES ('210', '4', 'entry', '20/01/2025', '2000', '42034');
INSERT INTO `transactions` VALUES ('211', '4', 'entry', '20/01/2025', '2000', '44034');
INSERT INTO `transactions` VALUES ('212', '4', 'entry', '20/01/2025', '2000', '46034');
INSERT INTO `transactions` VALUES ('213', '4', 'entry', '20/01/2025', '2000', '48034');
INSERT INTO `transactions` VALUES ('214', '4', 'entry', '20/01/2025', '2000', '50034');
INSERT INTO `transactions` VALUES ('215', '4', 'entry', '20/01/2025', '2000', '52034');
INSERT INTO `transactions` VALUES ('216', '4', 'entry', '20/01/2025', '2000', '54034');
INSERT INTO `transactions` VALUES ('217', '4', 'entry', '20/01/2025', '2000', '56034');
INSERT INTO `transactions` VALUES ('218', '4', 'entry', '20/01/2025', '2000', '58034');
INSERT INTO `transactions` VALUES ('219', '4', 'entry', '20/01/2025', '2000', '60034');
INSERT INTO `transactions` VALUES ('220', '4', 'entry', '20/01/2025', '2000', '62034');
INSERT INTO `transactions` VALUES ('221', '4', 'entry', '20/01/2025', '2000', '64034');
INSERT INTO `transactions` VALUES ('222', '4', 'entry', '20/01/2025', '2000', '66034');
INSERT INTO `transactions` VALUES ('223', '4', 'entry', '20/01/2025', '2000', '68034');
INSERT INTO `transactions` VALUES ('224', '4', 'entry', '20/01/2025', '2000', '70034');
INSERT INTO `transactions` VALUES ('225', '4', 'entry', '20/01/2025', '2000', '72034');
INSERT INTO `transactions` VALUES ('226', '4', 'entry', '20/01/2025', '2000', '74034');
INSERT INTO `transactions` VALUES ('227', '4', 'entry', '20/01/2025', '2000', '76034');
INSERT INTO `transactions` VALUES ('228', '4', 'entry', '20/01/2025', '2000', '78034');
INSERT INTO `transactions` VALUES ('229', '4', 'entry', '20/01/2025', '2000', '80034');
INSERT INTO `transactions` VALUES ('230', '4', 'entry', '20/01/2025', '2000', '82034');
INSERT INTO `transactions` VALUES ('231', '4', 'entry', '20/01/2025', '2000', '84034');
INSERT INTO `transactions` VALUES ('232', '4', 'entry', '20/01/2025', '2000', '86034');
INSERT INTO `transactions` VALUES ('233', '4', 'entry', '20/01/2025', '2000', '88034');
INSERT INTO `transactions` VALUES ('234', '4', 'entry', '20/01/2025', '2000', '90034');
INSERT INTO `transactions` VALUES ('235', '4', 'entry', '20/01/2025', '2000', '92034');
INSERT INTO `transactions` VALUES ('236', '4', 'entry', '20/01/2025', '2000', '94034');
INSERT INTO `transactions` VALUES ('237', '4', 'entry', '20/01/2025', '2000', '96034');
INSERT INTO `transactions` VALUES ('238', '4', 'entry', '20/01/2025', '2000', '98034');
INSERT INTO `transactions` VALUES ('239', '4', 'entry', '20/01/2025', '2000', '100034');
INSERT INTO `transactions` VALUES ('240', '4', 'entry', '20/01/2025', '2000', '102034');
INSERT INTO `transactions` VALUES ('241', '4', 'entry', '20/01/2025', '2000', '104034');
INSERT INTO `transactions` VALUES ('242', '4', 'entry', '20/01/2025', '2000', '106034');
INSERT INTO `transactions` VALUES ('243', '4', 'entry', '20/01/2025', '2000', '108034');
INSERT INTO `transactions` VALUES ('244', '4', 'entry', '20/01/2025', '2000', '110034');
INSERT INTO `transactions` VALUES ('245', '4', 'entry', '20/01/2025', '2000', '112034');
INSERT INTO `transactions` VALUES ('246', '4', 'entry', '20/01/2025', '2000', '114034');
INSERT INTO `transactions` VALUES ('247', '4', 'entry', '20/01/2025', '2000', '116034');
INSERT INTO `transactions` VALUES ('248', '4', 'entry', '20/01/2025', '2000', '118034');
INSERT INTO `transactions` VALUES ('249', '4', 'entry', '20/01/2025', '2000', '120034');
INSERT INTO `transactions` VALUES ('250', '4', 'entry', '20/01/2025', '2000', '122034');
INSERT INTO `transactions` VALUES ('251', '4', 'entry', '20/01/2025', '2000', '124034');
INSERT INTO `transactions` VALUES ('252', '4', 'entry', '20/01/2025', '2000', '126034');
INSERT INTO `transactions` VALUES ('253', '4', 'entry', '20/01/2025', '2000', '128034');
INSERT INTO `transactions` VALUES ('254', '4', 'entry', '20/01/2025', '2000', '130034');
INSERT INTO `transactions` VALUES ('255', '4', 'entry', '20/01/2025', '2000', '132034');
INSERT INTO `transactions` VALUES ('256', '4', 'entry', '20/01/2025', '2000', '134034');
INSERT INTO `transactions` VALUES ('257', '4', 'entry', '20/01/2025', '2000', '136034');
INSERT INTO `transactions` VALUES ('258', '4', 'entry', '20/01/2025', '2000', '138034');
INSERT INTO `transactions` VALUES ('259', '4', 'entry', '20/01/2025', '2000', '140034');
INSERT INTO `transactions` VALUES ('260', '4', 'entry', '20/01/2025', '2000', '142034');
INSERT INTO `transactions` VALUES ('261', '4', 'entry', '20/01/2025', '2000', '144034');
INSERT INTO `transactions` VALUES ('262', '4', 'entry', '20/01/2025', '2000', '146034');
INSERT INTO `transactions` VALUES ('263', '4', 'entry', '20/01/2025', '2000', '148034');
INSERT INTO `transactions` VALUES ('264', '4', 'entry', '20/01/2025', '2000', '150034');
INSERT INTO `transactions` VALUES ('265', '4', 'entry', '20/01/2025', '2000', '152034');
INSERT INTO `transactions` VALUES ('266', '4', 'entry', '20/01/2025', '2000', '154034');
INSERT INTO `transactions` VALUES ('267', '4', 'entry', '20/01/2025', '2000', '156034');
INSERT INTO `transactions` VALUES ('268', '4', 'entry', '20/01/2025', '2000', '158034');
INSERT INTO `transactions` VALUES ('269', '4', 'entry', '20/01/2025', '2000', '160034');
INSERT INTO `transactions` VALUES ('270', '4', 'entry', '20/01/2025', '2000', '162034');
INSERT INTO `transactions` VALUES ('271', '4', 'entry', '20/01/2025', '2000', '164034');
INSERT INTO `transactions` VALUES ('272', '4', 'entry', '20/01/2025', '2000', '166034');
INSERT INTO `transactions` VALUES ('273', '4', 'entry', '20/01/2025', '2000', '168034');
INSERT INTO `transactions` VALUES ('274', '4', 'entry', '20/01/2025', '2000', '170034');
INSERT INTO `transactions` VALUES ('275', '4', 'entry', '20/01/2025', '2000', '172034');
INSERT INTO `transactions` VALUES ('276', '4', 'entry', '20/01/2025', '2000', '174034');
INSERT INTO `transactions` VALUES ('277', '4', 'entry', '20/01/2025', '2000', '176034');
INSERT INTO `transactions` VALUES ('278', '4', 'entry', '20/01/2025', '2000', '178034');
INSERT INTO `transactions` VALUES ('279', '4', 'entry', '20/01/2025', '2000', '180034');
INSERT INTO `transactions` VALUES ('280', '4', 'entry', '20/01/2025', '2000', '182034');
INSERT INTO `transactions` VALUES ('281', '4', 'entry', '20/01/2025', '2000', '184034');
INSERT INTO `transactions` VALUES ('282', '4', 'entry', '20/01/2025', '2000', '186034');
INSERT INTO `transactions` VALUES ('283', '4', 'entry', '20/01/2025', '2000', '188034');
INSERT INTO `transactions` VALUES ('284', '4', 'entry', '20/01/2025', '2000', '190034');
INSERT INTO `transactions` VALUES ('285', '4', 'entry', '20/01/2025', '2000', '192034');
INSERT INTO `transactions` VALUES ('286', '4', 'entry', '20/01/2025', '2000', '194034');
INSERT INTO `transactions` VALUES ('287', '4', 'entry', '20/01/2025', '2000', '196034');
INSERT INTO `transactions` VALUES ('288', '4', 'entry', '20/01/2025', '2000', '198034');
INSERT INTO `transactions` VALUES ('289', '4', 'entry', '20/01/2025', '2000', '200034');
INSERT INTO `transactions` VALUES ('290', '4', 'entry', '20/01/2025', '2000', '202034');
INSERT INTO `transactions` VALUES ('291', '4', 'entry', '20/01/2025', '2000', '204034');
INSERT INTO `transactions` VALUES ('292', '4', 'entry', '20/01/2025', '2000', '206034');
INSERT INTO `transactions` VALUES ('293', '4', 'entry', '20/01/2025', '2000', '208034');
INSERT INTO `transactions` VALUES ('294', '4', 'entry', '20/01/2025', '2000', '210034');
INSERT INTO `transactions` VALUES ('295', '4', 'entry', '20/01/2025', '2000', '212034');
INSERT INTO `transactions` VALUES ('296', '4', 'entry', '20/01/2025', '2000', '214034');
INSERT INTO `transactions` VALUES ('297', '4', 'entry', '20/01/2025', '2000', '216034');
INSERT INTO `transactions` VALUES ('298', '4', 'entry', '20/01/2025', '2000', '218034');
INSERT INTO `transactions` VALUES ('299', '4', 'entry', '20/01/2025', '2000', '220034');
INSERT INTO `transactions` VALUES ('300', '4', 'entry', '20/01/2025', '2000', '222034');
INSERT INTO `transactions` VALUES ('301', '4', 'entry', '20/01/2025', '2000', '224034');
INSERT INTO `transactions` VALUES ('302', '4', 'entry', '20/01/2025', '2000', '226034');
INSERT INTO `transactions` VALUES ('303', '4', 'entry', '20/01/2025', '2000', '228034');
INSERT INTO `transactions` VALUES ('304', '4', 'entry', '20/01/2025', '2000', '230034');
INSERT INTO `transactions` VALUES ('305', '4', 'entry', '20/01/2025', '2000', '232034');
INSERT INTO `transactions` VALUES ('306', '4', 'entry', '20/01/2025', '2000', '234034');
INSERT INTO `transactions` VALUES ('307', '4', 'entry', '20/01/2025', '2000', '236034');
INSERT INTO `transactions` VALUES ('308', '4', 'entry', '20/01/2025', '2000', '238034');
INSERT INTO `transactions` VALUES ('309', '4', 'entry', '20/01/2025', '2000', '240034');
INSERT INTO `transactions` VALUES ('310', '4', 'entry', '20/01/2025', '2000', '242034');
INSERT INTO `transactions` VALUES ('311', '4', 'entry', '20/01/2025', '2000', '244034');
INSERT INTO `transactions` VALUES ('312', '4', 'entry', '20/01/2025', '2000', '246034');
INSERT INTO `transactions` VALUES ('313', '4', 'entry', '20/01/2025', '2000', '248034');
INSERT INTO `transactions` VALUES ('314', '4', 'entry', '20/01/2025', '2000', '250034');
INSERT INTO `transactions` VALUES ('315', '4', 'entry', '20/01/2025', '2000', '252034');
INSERT INTO `transactions` VALUES ('316', '4', 'entry', '20/01/2025', '2000', '254034');
INSERT INTO `transactions` VALUES ('317', '4', 'entry', '20/01/2025', '2000', '256034');
INSERT INTO `transactions` VALUES ('318', '4', 'entry', '20/01/2025', '2000', '258034');
INSERT INTO `transactions` VALUES ('319', '4', 'entry', '20/01/2025', '2000', '260034');
INSERT INTO `transactions` VALUES ('320', '4', 'entry', '20/01/2025', '2000', '262034');
INSERT INTO `transactions` VALUES ('321', '4', 'entry', '20/01/2025', '2000', '264034');
INSERT INTO `transactions` VALUES ('322', '4', 'entry', '20/01/2025', '2000', '266034');
INSERT INTO `transactions` VALUES ('323', '4', 'entry', '20/01/2025', '2000', '268034');
INSERT INTO `transactions` VALUES ('324', '4', 'entry', '20/01/2025', '2000', '270034');
INSERT INTO `transactions` VALUES ('325', '4', 'entry', '20/01/2025', '2000', '272034');
INSERT INTO `transactions` VALUES ('326', '4', 'entry', '20/01/2025', '2000', '274034');
INSERT INTO `transactions` VALUES ('327', '4', 'entry', '20/01/2025', '2000', '276034');
INSERT INTO `transactions` VALUES ('328', '4', 'entry', '20/01/2025', '2000', '278034');
INSERT INTO `transactions` VALUES ('329', '4', 'entry', '20/01/2025', '2000', '280034');
INSERT INTO `transactions` VALUES ('330', '4', 'entry', '20/01/2025', '2000', '282034');
INSERT INTO `transactions` VALUES ('331', '4', 'entry', '20/01/2025', '2000', '284034');
INSERT INTO `transactions` VALUES ('332', '4', 'entry', '20/01/2025', '2000', '286034');
INSERT INTO `transactions` VALUES ('333', '4', 'entry', '20/01/2025', '2000', '288034');
INSERT INTO `transactions` VALUES ('334', '4', 'entry', '20/01/2025', '2000', '290034');
INSERT INTO `transactions` VALUES ('335', '4', 'entry', '20/01/2025', '2000', '292034');
INSERT INTO `transactions` VALUES ('336', '4', 'entry', '20/01/2025', '2000', '294034');
INSERT INTO `transactions` VALUES ('337', '4', 'entry', '20/01/2025', '2000', '296034');
INSERT INTO `transactions` VALUES ('338', '4', 'entry', '20/01/2025', '2000', '298034');
INSERT INTO `transactions` VALUES ('339', '4', 'entry', '20/01/2025', '2000', '300034');
INSERT INTO `transactions` VALUES ('340', '4', 'entry', '20/01/2025', '2000', '302034');
INSERT INTO `transactions` VALUES ('341', '4', 'entry', '20/01/2025', '2000', '304034');
INSERT INTO `transactions` VALUES ('342', '4', 'entry', '20/01/2025', '2000', '306034');
INSERT INTO `transactions` VALUES ('343', '4', 'entry', '20/01/2025', '2000', '308034');
INSERT INTO `transactions` VALUES ('344', '4', 'entry', '20/01/2025', '2000', '310034');
INSERT INTO `transactions` VALUES ('345', '4', 'entry', '20/01/2025', '2000', '312034');
INSERT INTO `transactions` VALUES ('346', '4', 'entry', '20/01/2025', '2000', '314034');
INSERT INTO `transactions` VALUES ('347', '4', 'entry', '20/01/2025', '2000', '316034');
INSERT INTO `transactions` VALUES ('348', '4', 'entry', '20/01/2025', '2000', '318034');
INSERT INTO `transactions` VALUES ('349', '4', 'entry', '20/01/2025', '2000', '320034');
INSERT INTO `transactions` VALUES ('350', '4', 'entry', '20/01/2025', '2000', '322034');
INSERT INTO `transactions` VALUES ('351', '4', 'entry', '20/01/2025', '2000', '324034');
INSERT INTO `transactions` VALUES ('352', '4', 'entry', '20/01/2025', '2000', '326034');
INSERT INTO `transactions` VALUES ('353', '4', 'entry', '20/01/2025', '2000', '328034');
INSERT INTO `transactions` VALUES ('354', '4', 'entry', '20/01/2025', '2000', '330034');
INSERT INTO `transactions` VALUES ('355', '4', 'entry', '20/01/2025', '2000', '332034');
INSERT INTO `transactions` VALUES ('356', '4', 'entry', '20/01/2025', '2000', '334034');
INSERT INTO `transactions` VALUES ('357', '4', 'entry', '20/01/2025', '2000', '336034');
INSERT INTO `transactions` VALUES ('358', '4', 'entry', '20/01/2025', '2000', '338034');
INSERT INTO `transactions` VALUES ('359', '4', 'entry', '20/01/2025', '2000', '340034');
INSERT INTO `transactions` VALUES ('360', '4', 'entry', '20/01/2025', '2000', '342034');
INSERT INTO `transactions` VALUES ('361', '4', 'entry', '20/01/2025', '2000', '344034');
INSERT INTO `transactions` VALUES ('362', '4', 'entry', '20/01/2025', '2000', '346034');
INSERT INTO `transactions` VALUES ('363', '4', 'entry', '20/01/2025', '2000', '348034');
INSERT INTO `transactions` VALUES ('364', '4', 'entry', '20/01/2025', '2000', '350034');
INSERT INTO `transactions` VALUES ('365', '4', 'entry', '20/01/2025', '2000', '352034');
INSERT INTO `transactions` VALUES ('366', '4', 'entry', '20/01/2025', '2000', '354034');
INSERT INTO `transactions` VALUES ('367', '4', 'entry', '20/01/2025', '2000', '356034');
INSERT INTO `transactions` VALUES ('368', '4', 'entry', '20/01/2025', '2000', '358034');
INSERT INTO `transactions` VALUES ('369', '4', 'entry', '20/01/2025', '2000', '360034');
INSERT INTO `transactions` VALUES ('370', '4', 'entry', '20/01/2025', '2000', '362034');
INSERT INTO `transactions` VALUES ('371', '4', 'entry', '20/01/2025', '2000', '364034');
INSERT INTO `transactions` VALUES ('372', '4', 'entry', '20/01/2025', '9000000', '366034');
INSERT INTO `transactions` VALUES ('373', '4', 'entry', '20/01/2025', '600000', '9366034');
INSERT INTO `transactions` VALUES ('374', '4', 'entry', '20/01/2025', '36000', '9966034');
INSERT INTO `transactions` VALUES ('375', '4', 'exit', '20/01/2025', '500', '10002034');
INSERT INTO `transactions` VALUES ('376', '4', 'exit', '20/01/2025', '50', '10001534');
INSERT INTO `transactions` VALUES ('377', '4', 'exit', '20/01/2025', '50', '10001484');
INSERT INTO `transactions` VALUES ('378', '4', 'exit', '20/01/2025', '30', '10001434');
INSERT INTO `transactions` VALUES ('379', '8', 'exit', '20/01/2025', '650', '5002');
INSERT INTO `transactions` VALUES ('380', '8', 'exit', '20/01/2025', '790', '4352');
INSERT INTO `transactions` VALUES ('381', '1', 'entry', '20/01/2025', '1100', '1105321');
INSERT INTO `transactions` VALUES ('382', '1', 'entry', '20/01/2025', '3500', '1106421');
INSERT INTO `transactions` VALUES ('383', '1', 'entry', '20/01/2025', '1', '1109921');
INSERT INTO `transactions` VALUES ('384', '1', 'entry', '20/01/2025', '1100', '1109922');
INSERT INTO `transactions` VALUES ('385', '1', 'entry', '20/01/2025', '3500', '1111022');
INSERT INTO `transactions` VALUES ('386', '1', 'entry', '20/01/2025', '1', '1114522');
INSERT INTO `transactions` VALUES ('387', '1', 'entry', '20/01/2025', '1100', '1114523');
INSERT INTO `transactions` VALUES ('388', '1', 'entry', '20/01/2025', '3500', '1115623');
INSERT INTO `transactions` VALUES ('389', '1', 'entry', '20/01/2025', '1', '1119123');
INSERT INTO `transactions` VALUES ('390', '1', 'entry', '20/01/2025', '1100', '1119124');
INSERT INTO `transactions` VALUES ('391', '1', 'entry', '20/01/2025', '3500', '1120224');
INSERT INTO `transactions` VALUES ('392', '1', 'entry', '20/01/2025', '1100', '1123724');
INSERT INTO `transactions` VALUES ('393', '1', 'entry', '20/01/2025', '3500', '1124824');
INSERT INTO `transactions` VALUES ('394', '1', 'entry', '20/01/2025', '1100', '1128324');
INSERT INTO `transactions` VALUES ('395', '1', 'entry', '20/01/2025', '3500', '1129424');
INSERT INTO `transactions` VALUES ('396', '1', 'entry', '20/01/2025', '1100', '1132924');
INSERT INTO `transactions` VALUES ('397', '1', 'entry', '20/01/2025', '3500', '1134024');
INSERT INTO `transactions` VALUES ('398', '1', 'entry', '20/01/2025', '1100', '1137524');
INSERT INTO `transactions` VALUES ('399', '1', 'entry', '20/01/2025', '3500', '1138624');
INSERT INTO `transactions` VALUES ('400', '1', 'entry', '20/01/2025', '1', '1142124');
INSERT INTO `transactions` VALUES ('401', '1', 'entry', '20/01/2025', '1100', '1142125');
INSERT INTO `transactions` VALUES ('402', '1', 'entry', '20/01/2025', '3500', '1143225');
INSERT INTO `transactions` VALUES ('403', '1', 'entry', '20/01/2025', '1', '1146725');
INSERT INTO `transactions` VALUES ('404', '4', 'exit', '20/01/2025', '100', '10001404');
INSERT INTO `transactions` VALUES ('405', '6', 'entry', '20/01/2025', '1', '975');
INSERT INTO `transactions` VALUES ('406', '8', 'entry', '20/01/2025', '1', '3562');
INSERT INTO `transactions` VALUES ('407', '1', 'entry', '20/01/2025', '1100', '1146726');
INSERT INTO `transactions` VALUES ('408', '1', 'entry', '20/01/2025', '3500', '1147826');
INSERT INTO `transactions` VALUES ('409', '6', 'entry', '20/01/2025', '1', '976');
INSERT INTO `transactions` VALUES ('410', '1', 'entry', '20/01/2025', '1', '1151326');
INSERT INTO `transactions` VALUES ('411', '1', 'entry', '20/01/2025', '1100', '1151327');
INSERT INTO `transactions` VALUES ('412', '1', 'entry', '20/01/2025', '3500', '1152427');
INSERT INTO `transactions` VALUES ('413', '1', 'entry', '20/01/2025', '3500', '1155927');
INSERT INTO `transactions` VALUES ('414', '1', 'entry', '20/01/2025', '1100', '1159427');
INSERT INTO `transactions` VALUES ('415', '4', 'exit', '20/01/2025', '10000', '10001304');
INSERT INTO `transactions` VALUES ('416', '4', 'exit', '20/01/2025', '500', '9991304');
INSERT INTO `transactions` VALUES ('417', '4', 'exit', '20/01/2025', '100', '9990804');
INSERT INTO `transactions` VALUES ('418', '1', 'entry', '20/01/2025', '3500', '1160527');
INSERT INTO `transactions` VALUES ('419', '1', 'entry', '20/01/2025', '1100', '1164027');
INSERT INTO `transactions` VALUES ('420', '4', 'exit', '20/01/2025', '50', '9990704');
INSERT INTO `transactions` VALUES ('421', '4', 'entry', '20/01/2025', '1', '9990654');
INSERT INTO `transactions` VALUES ('422', '4', 'exit', '20/01/2025', '50', '9990655');
INSERT INTO `transactions` VALUES ('423', '4', 'exit', '20/01/2025', '50', '9990605');
INSERT INTO `transactions` VALUES ('424', '4', 'exit', '20/01/2025', '50', '9990555');
INSERT INTO `transactions` VALUES ('425', '4', 'exit', '20/01/2025', '50', '9990505');
INSERT INTO `transactions` VALUES ('426', '3', 'entry', '20/01/2025', '3500', '4807');
INSERT INTO `transactions` VALUES ('427', '1', 'entry', '20/01/2025', '3500', '1165127');
INSERT INTO `transactions` VALUES ('428', '1', 'entry', '20/01/2025', '1100', '1168627');
INSERT INTO `transactions` VALUES ('429', '4', 'entry', '20/01/2025', '1', '9990455');
INSERT INTO `transactions` VALUES ('430', '3', 'entry', '20/01/2025', '3500', '8307');
INSERT INTO `transactions` VALUES ('431', '1', 'entry', '20/01/2025', '3500', '1169727');
INSERT INTO `transactions` VALUES ('432', '1', 'entry', '20/01/2025', '1100', '1173227');
INSERT INTO `transactions` VALUES ('433', '4', 'entry', '20/01/2025', '1', '9990456');
INSERT INTO `transactions` VALUES ('434', '4', 'exit', '20/01/2025', '50', '9990457');
INSERT INTO `transactions` VALUES ('435', '4', 'exit', '20/01/2025', '50', '9990407');
INSERT INTO `transactions` VALUES ('436', '1', 'entry', '20/01/2025', '3500', '1174327');
INSERT INTO `transactions` VALUES ('437', '1', 'entry', '20/01/2025', '1100', '1177827');
INSERT INTO `transactions` VALUES ('438', '4', 'entry', '20/01/2025', '1', '9990357');
INSERT INTO `transactions` VALUES ('439', '1', 'entry', '20/01/2025', '3500', '1178927');
INSERT INTO `transactions` VALUES ('440', '1', 'entry', '20/01/2025', '1100', '1182427');
INSERT INTO `transactions` VALUES ('441', '4', 'entry', '20/01/2025', '1', '9990358');
INSERT INTO `transactions` VALUES ('442', '1', 'entry', '20/01/2025', '1000', '1183527');
INSERT INTO `transactions` VALUES ('443', '1', 'entry', '20/01/2025', '3500', '1184527');
INSERT INTO `transactions` VALUES ('444', '1', 'entry', '20/01/2025', '1100', '1188027');
INSERT INTO `transactions` VALUES ('445', '4', 'entry', '20/01/2025', '1', '9990359');
INSERT INTO `transactions` VALUES ('446', '1', 'entry', '20/01/2025', '1000', '1189127');
INSERT INTO `transactions` VALUES ('447', '1', 'entry', '20/01/2025', '1000', '1190127');
INSERT INTO `transactions` VALUES ('448', '1', 'entry', '20/01/2025', '3500', '1191127');
INSERT INTO `transactions` VALUES ('449', '1', 'entry', '20/01/2025', '1100', '1194627');
INSERT INTO `transactions` VALUES ('450', '4', 'entry', '20/01/2025', '1', '9990360');
INSERT INTO `transactions` VALUES ('451', '1', 'entry', '20/01/2025', '3500', '1195727');
INSERT INTO `transactions` VALUES ('452', '1', 'entry', '20/01/2025', '1100', '1199227');
INSERT INTO `transactions` VALUES ('453', '4', 'entry', '20/01/2025', '1', '9990361');
INSERT INTO `transactions` VALUES ('454', '1', 'entry', '21/01/2025', '3500', '1200327');
INSERT INTO `transactions` VALUES ('455', '1', 'entry', '21/01/2025', '1100', '1203827');
INSERT INTO `transactions` VALUES ('456', '4', 'entry', '21/01/2025', '1', '9990362');
INSERT INTO `transactions` VALUES ('457', '1', 'entry', '21/01/2025', '3500', '1204927');
INSERT INTO `transactions` VALUES ('458', '1', 'entry', '21/01/2025', '1', '1208427');
INSERT INTO `transactions` VALUES ('459', '1', 'entry', '21/01/2025', '1100', '1208428');
INSERT INTO `transactions` VALUES ('460', '4', 'entry', '21/01/2025', '1', '9990363');
INSERT INTO `transactions` VALUES ('461', '7', 'exit', '21/01/2025', '270', '2813');
INSERT INTO `transactions` VALUES ('462', '1', 'entry', '21/01/2025', '1100', '1209528');
INSERT INTO `transactions` VALUES ('463', '7', 'exit', '21/01/2025', '300', '2543');
INSERT INTO `transactions` VALUES ('464', '6', 'entry', '21/01/2025', '1', '977');
INSERT INTO `transactions` VALUES ('465', '4', 'entry', '21/01/2025', '1', '9990364');
INSERT INTO `transactions` VALUES ('466', '7', 'exit', '21/01/2025', '200', '2243');
INSERT INTO `transactions` VALUES ('467', '7', 'exit', '21/01/2025', '200', '2043');
INSERT INTO `transactions` VALUES ('468', '7', 'exit', '21/01/2025', '200', '1843');
INSERT INTO `transactions` VALUES ('469', '7', 'exit', '21/01/2025', '170', '1643');
INSERT INTO `transactions` VALUES ('470', '1', 'entry', '21/01/2025', '1100', '1210628');
INSERT INTO `transactions` VALUES ('471', '6', 'entry', '21/01/2025', '1', '978');
INSERT INTO `transactions` VALUES ('472', '4', 'entry', '21/01/2025', '1', '9990365');
INSERT INTO `transactions` VALUES ('473', '4', 'exit', '21/01/2025', '100', '9990366');
INSERT INTO `transactions` VALUES ('474', '4', 'exit', '21/01/2025', '100', '9990266');
INSERT INTO `transactions` VALUES ('475', '4', 'exit', '21/01/2025', '100', '9990166');
INSERT INTO `transactions` VALUES ('476', '4', 'exit', '21/01/2025', '100', '9990066');
INSERT INTO `transactions` VALUES ('477', '4', 'exit', '21/01/2025', '100', '9989966');
INSERT INTO `transactions` VALUES ('478', '4', 'exit', '21/01/2025', '50', '9989866');
INSERT INTO `transactions` VALUES ('479', '1', 'entry', '21/01/2025', '1100', '1211728');
INSERT INTO `transactions` VALUES ('480', '1', 'entry', '21/01/2025', '1100', '1212828');
INSERT INTO `transactions` VALUES ('481', '3', 'exit', '21/01/2025', '5', '11807');
INSERT INTO `transactions` VALUES ('482', '3', 'entry', '21/01/2025', '3500', '11802');
INSERT INTO `transactions` VALUES ('483', '3', 'entry', '21/01/2025', '1', '15302');
INSERT INTO `transactions` VALUES ('484', '1', 'entry', '21/01/2025', '1100', '1213928');
INSERT INTO `transactions` VALUES ('485', '9', 'exit', '24/01/2025', '400', '5001');
INSERT INTO `transactions` VALUES ('486', '1', 'entry', '24/01/2025', '1100', '1215028');
INSERT INTO `transactions` VALUES ('487', '1', 'entry', '24/01/2025', '1100', '1216128');
INSERT INTO `transactions` VALUES ('488', '1', 'entry', '24/01/2025', '1100', '1217228');
INSERT INTO `transactions` VALUES ('489', '1', 'entry', '24/01/2025', '1100', '1218328');
INSERT INTO `transactions` VALUES ('490', '1', 'entry', '24/01/2025', '1100', '1219428');
INSERT INTO `transactions` VALUES ('491', '4', 'exit', '24/01/2025', '50', '9989816');
INSERT INTO `transactions` VALUES ('492', '1', 'entry', '24/01/2025', '1100', '1220528');
INSERT INTO `transactions` VALUES ('493', '1', 'entry', '24/01/2025', '1100', '1221628');
INSERT INTO `transactions` VALUES ('494', '3', 'entry', '24/01/2025', '1', '15303');
INSERT INTO `transactions` VALUES ('495', '1', 'entry', '24/01/2025', '1100', '1222728');
INSERT INTO `transactions` VALUES ('496', '3', 'entry', '24/01/2025', '1', '15304');
INSERT INTO `transactions` VALUES ('497', '2', 'entry', '24/01/2025', '1', '5003');
INSERT INTO `transactions` VALUES ('498', '1', 'entry', '24/01/2025', '1100', '1223828');
INSERT INTO `transactions` VALUES ('499', '1', 'entry', '24/01/2025', '1100', '1224928');
INSERT INTO `transactions` VALUES ('500', '1', 'entry', '24/01/2025', '1100', '1226028');
INSERT INTO `transactions` VALUES ('501', '6', 'entry', '24/01/2025', '1', '979');
INSERT INTO `transactions` VALUES ('502', '1', 'entry', '24/01/2025', '1100', '1227128');
INSERT INTO `transactions` VALUES ('503', '6', 'entry', '24/01/2025', '1', '980');
INSERT INTO `transactions` VALUES ('504', '1', 'entry', '24/01/2025', '1100', '1228228');
INSERT INTO `transactions` VALUES ('505', '6', 'entry', '24/01/2025', '1', '981');
INSERT INTO `transactions` VALUES ('506', '6', 'entry', '24/01/2025', '200', '982');
INSERT INTO `transactions` VALUES ('507', '6', 'entry', '24/01/2025', '200', '1182');
INSERT INTO `transactions` VALUES ('508', '6', 'entry', '24/01/2025', '200', '1382');
INSERT INTO `transactions` VALUES ('509', '6', 'entry', '24/01/2025', '200', '1582');
INSERT INTO `transactions` VALUES ('510', '6', 'entry', '24/01/2025', '200', '1782');
INSERT INTO `transactions` VALUES ('511', '6', 'entry', '24/01/2025', '200', '1982');
INSERT INTO `transactions` VALUES ('512', '6', 'entry', '24/01/2025', '200', '2182');
INSERT INTO `transactions` VALUES ('513', '6', 'entry', '24/01/2025', '200', '2382');
INSERT INTO `transactions` VALUES ('514', '6', 'entry', '24/01/2025', '200', '2582');
INSERT INTO `transactions` VALUES ('515', '6', 'entry', '24/01/2025', '200', '2782');
INSERT INTO `transactions` VALUES ('516', '6', 'entry', '24/01/2025', '200', '2982');
INSERT INTO `transactions` VALUES ('517', '6', 'entry', '24/01/2025', '2000', '3182');
INSERT INTO `transactions` VALUES ('518', '6', 'entry', '24/01/2025', '2000', '5182');
INSERT INTO `transactions` VALUES ('519', '6', 'entry', '24/01/2025', '2000', '7182');
INSERT INTO `transactions` VALUES ('520', '6', 'entry', '24/01/2025', '2000', '9182');
INSERT INTO `transactions` VALUES ('521', '6', 'entry', '24/01/2025', '2000', '11182');
INSERT INTO `transactions` VALUES ('522', '6', 'entry', '24/01/2025', '2000', '13182');
INSERT INTO `transactions` VALUES ('523', '6', 'entry', '24/01/2025', '2000', '15182');
INSERT INTO `transactions` VALUES ('524', '6', 'entry', '24/01/2025', '2000', '17182');
INSERT INTO `transactions` VALUES ('525', '6', 'entry', '24/01/2025', '2000', '19182');
INSERT INTO `transactions` VALUES ('526', '6', 'entry', '24/01/2025', '2000', '21182');
INSERT INTO `transactions` VALUES ('527', '6', 'entry', '24/01/2025', '2000', '23182');
INSERT INTO `transactions` VALUES ('528', '6', 'entry', '24/01/2025', '2000', '25182');
INSERT INTO `transactions` VALUES ('529', '6', 'entry', '24/01/2025', '2000', '27182');
INSERT INTO `transactions` VALUES ('530', '6', 'entry', '24/01/2025', '2000', '29182');
INSERT INTO `transactions` VALUES ('531', '6', 'entry', '24/01/2025', '2000', '31182');
INSERT INTO `transactions` VALUES ('532', '6', 'entry', '24/01/2025', '2000', '33182');
INSERT INTO `transactions` VALUES ('533', '6', 'entry', '24/01/2025', '2000', '35182');
INSERT INTO `transactions` VALUES ('534', '6', 'entry', '24/01/2025', '2000', '37182');
INSERT INTO `transactions` VALUES ('535', '6', 'entry', '24/01/2025', '2000', '39182');
INSERT INTO `transactions` VALUES ('536', '6', 'entry', '24/01/2025', '2000', '41182');
INSERT INTO `transactions` VALUES ('537', '6', 'entry', '24/01/2025', '2000', '43182');
INSERT INTO `transactions` VALUES ('538', '6', 'entry', '24/01/2025', '2000', '45182');
INSERT INTO `transactions` VALUES ('539', '6', 'entry', '24/01/2025', '2000', '47182');
INSERT INTO `transactions` VALUES ('540', '6', 'entry', '24/01/2025', '2000', '49182');
INSERT INTO `transactions` VALUES ('541', '6', 'entry', '24/01/2025', '2000', '51182');
INSERT INTO `transactions` VALUES ('542', '6', 'entry', '24/01/2025', '2000', '53182');
INSERT INTO `transactions` VALUES ('543', '6', 'entry', '24/01/2025', '2000', '55182');
INSERT INTO `transactions` VALUES ('544', '6', 'entry', '24/01/2025', '2000', '57182');
INSERT INTO `transactions` VALUES ('545', '6', 'entry', '24/01/2025', '2000', '59182');
INSERT INTO `transactions` VALUES ('546', '6', 'entry', '24/01/2025', '2000', '61182');
INSERT INTO `transactions` VALUES ('547', '6', 'entry', '24/01/2025', '2000', '63182');
INSERT INTO `transactions` VALUES ('548', '6', 'entry', '24/01/2025', '2000', '65182');
INSERT INTO `transactions` VALUES ('549', '6', 'entry', '24/01/2025', '2000', '67182');
INSERT INTO `transactions` VALUES ('550', '6', 'entry', '24/01/2025', '2000', '69182');
INSERT INTO `transactions` VALUES ('551', '6', 'entry', '24/01/2025', '2000', '71182');
INSERT INTO `transactions` VALUES ('552', '6', 'entry', '24/01/2025', '2000', '73182');
INSERT INTO `transactions` VALUES ('553', '6', 'entry', '24/01/2025', '2000', '75182');
INSERT INTO `transactions` VALUES ('554', '6', 'entry', '24/01/2025', '2000', '77182');
INSERT INTO `transactions` VALUES ('555', '6', 'entry', '24/01/2025', '2000', '79182');
INSERT INTO `transactions` VALUES ('556', '6', 'entry', '24/01/2025', '2000', '81182');
INSERT INTO `transactions` VALUES ('557', '6', 'entry', '24/01/2025', '2000', '83182');
INSERT INTO `transactions` VALUES ('558', '6', 'entry', '24/01/2025', '2000', '85182');
INSERT INTO `transactions` VALUES ('559', '6', 'entry', '24/01/2025', '2000', '87182');
INSERT INTO `transactions` VALUES ('560', '6', 'entry', '24/01/2025', '2000', '89182');
INSERT INTO `transactions` VALUES ('561', '6', 'entry', '24/01/2025', '2000', '91182');
INSERT INTO `transactions` VALUES ('562', '6', 'entry', '24/01/2025', '2000', '93182');
INSERT INTO `transactions` VALUES ('563', '6', 'entry', '24/01/2025', '2000', '95182');
INSERT INTO `transactions` VALUES ('564', '6', 'entry', '24/01/2025', '2000', '97182');
INSERT INTO `transactions` VALUES ('565', '6', 'entry', '24/01/2025', '2000', '99182');
INSERT INTO `transactions` VALUES ('566', '8', 'exit', '24/01/2025', '200', '3563');
INSERT INTO `transactions` VALUES ('567', '1', 'entry', '24/01/2025', '1100', '1229328');
INSERT INTO `transactions` VALUES ('568', '6', 'entry', '24/01/2025', '1', '101182');
INSERT INTO `transactions` VALUES ('569', '6', 'entry', '24/01/2025', '1', '101183');
INSERT INTO `transactions` VALUES ('570', '1', 'entry', '24/01/2025', '1', '1230428');
INSERT INTO `transactions` VALUES ('571', '8', 'entry', '24/01/2025', '1', '3363');
INSERT INTO `transactions` VALUES ('572', '6', 'entry', '24/01/2025', '1', '101184');
INSERT INTO `transactions` VALUES ('573', '6', 'entry', '24/01/2025', '1', '101185');
INSERT INTO `transactions` VALUES ('574', '8', 'entry', '24/01/2025', '1', '3364');
INSERT INTO `transactions` VALUES ('575', '1', 'entry', '24/01/2025', '1100', '1230429');
INSERT INTO `transactions` VALUES ('576', '6', 'entry', '24/01/2025', '1', '101186');
INSERT INTO `transactions` VALUES ('577', '8', 'exit', '24/01/2025', '20', '3365');
INSERT INTO `transactions` VALUES ('578', '6', 'entry', '24/01/2025', '1', '101187');
INSERT INTO `transactions` VALUES ('579', '8', 'entry', '24/01/2025', '1', '3345');
INSERT INTO `transactions` VALUES ('580', '10', 'entry', '24/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('581', '1', 'entry', '24/01/2025', '1100', '1231529');
INSERT INTO `transactions` VALUES ('582', '6', 'entry', '24/01/2025', '1', '101188');
INSERT INTO `transactions` VALUES ('583', '6', 'entry', '24/01/2025', '1', '101189');
INSERT INTO `transactions` VALUES ('584', '8', 'entry', '24/01/2025', '1', '3346');
INSERT INTO `transactions` VALUES ('585', '6', 'exit', '24/01/2025', '385', '101190');
INSERT INTO `transactions` VALUES ('586', '2', 'entry', '24/01/2025', '1', '5004');
INSERT INTO `transactions` VALUES ('587', '1', 'entry', '24/01/2025', '1100', '1232629');
INSERT INTO `transactions` VALUES ('588', '1', 'entry', '24/01/2025', '1', '1233729');
INSERT INTO `transactions` VALUES ('589', '2', 'entry', '24/01/2025', '1', '5005');
INSERT INTO `transactions` VALUES ('590', '1', 'entry', '24/01/2025', '1100', '1233730');
INSERT INTO `transactions` VALUES ('591', '1', 'entry', '24/01/2025', '1', '1234830');
INSERT INTO `transactions` VALUES ('592', '1', 'entry', '24/01/2025', '1', '1234831');
INSERT INTO `transactions` VALUES ('593', '2', 'entry', '24/01/2025', '1', '5006');
INSERT INTO `transactions` VALUES ('594', '1', 'entry', '24/01/2025', '1100', '1234832');
INSERT INTO `transactions` VALUES ('595', '1', 'entry', '24/01/2025', '1', '1235932');
INSERT INTO `transactions` VALUES ('596', '1', 'entry', '24/01/2025', '1', '1235933');
INSERT INTO `transactions` VALUES ('597', '2', 'entry', '24/01/2025', '1', '5007');
INSERT INTO `transactions` VALUES ('598', '1', 'entry', '24/01/2025', '1100', '1235934');
INSERT INTO `transactions` VALUES ('599', '1', 'entry', '24/01/2025', '1', '1237034');
INSERT INTO `transactions` VALUES ('600', '1', 'entry', '24/01/2025', '1', '1237035');
INSERT INTO `transactions` VALUES ('601', '9', 'exit', '25/01/2025', '6', '4601');
INSERT INTO `transactions` VALUES ('602', '10', 'entry', '25/01/2025', '1', '5000');
INSERT INTO `transactions` VALUES ('603', '1', 'entry', '25/01/2025', '1100', '1237036');
INSERT INTO `transactions` VALUES ('604', '10', 'entry', '25/01/2025', '1', '5001');
INSERT INTO `transactions` VALUES ('605', '1', 'entry', '25/01/2025', '1100', '1238136');
INSERT INTO `transactions` VALUES ('606', '1', 'exit', '25/01/2025', '400', '1239236');
INSERT INTO `transactions` VALUES ('607', '1', 'exit', '25/01/2025', '200', '1238836');
INSERT INTO `transactions` VALUES ('608', '1', 'exit', '25/01/2025', '400', '1238636');
INSERT INTO `transactions` VALUES ('609', '1', 'exit', '25/01/2025', '400', '1238236');
INSERT INTO `transactions` VALUES ('610', '10', 'entry', '25/01/2025', '1', '5002');
INSERT INTO `transactions` VALUES ('611', '1', 'exit', '25/01/2025', '400', '1237836');
INSERT INTO `transactions` VALUES ('612', '1', 'exit', '25/01/2025', '400', '1237436');
INSERT INTO `transactions` VALUES ('613', '1', 'exit', '25/01/2025', '320', '1237036');
INSERT INTO `transactions` VALUES ('614', '1', 'exit', '25/01/2025', '520', '1236716');
INSERT INTO `transactions` VALUES ('615', '1', 'exit', '25/01/2025', '520', '1236196');
INSERT INTO `transactions` VALUES ('616', '1', 'exit', '25/01/2025', '200', '1235676');
INSERT INTO `transactions` VALUES ('617', '1', 'entry', '25/01/2025', '1100', '1235476');
INSERT INTO `transactions` VALUES ('618', '1', 'exit', '25/01/2025', '1260', '1236576');
INSERT INTO `transactions` VALUES ('619', '1', 'exit', '25/01/2025', '110', '1235316');
INSERT INTO `transactions` VALUES ('620', '1', 'entry', '25/01/2025', '350', '1235206');
INSERT INTO `transactions` VALUES ('621', '1', 'entry', '25/01/2025', '1100', '1235556');
INSERT INTO `transactions` VALUES ('622', '1', 'entry', '25/01/2025', '350', '1236656');
INSERT INTO `transactions` VALUES ('623', '1', 'entry', '25/01/2025', '1100', '1237006');
INSERT INTO `transactions` VALUES ('624', '4', 'exit', '25/01/2025', '50', '9989766');
INSERT INTO `transactions` VALUES ('625', '4', 'exit', '25/01/2025', '50', '9989716');
INSERT INTO `transactions` VALUES ('626', '4', 'exit', '25/01/2025', '50', '9989666');
INSERT INTO `transactions` VALUES ('627', '4', 'exit', '25/01/2025', '50', '9989616');
INSERT INTO `transactions` VALUES ('628', '4', 'exit', '25/01/2025', '150000', '9989566');
INSERT INTO `transactions` VALUES ('629', '4', 'exit', '25/01/2025', '50', '9839566');
INSERT INTO `transactions` VALUES ('630', '4', 'exit', '25/01/2025', '50', '9839516');
INSERT INTO `transactions` VALUES ('631', '4', 'exit', '25/01/2025', '50', '9839466');
INSERT INTO `transactions` VALUES ('632', '4', 'entry', '25/01/2025', '1', '9839416');
INSERT INTO `transactions` VALUES ('633', '1', 'entry', '25/01/2025', '350', '1238106');
INSERT INTO `transactions` VALUES ('634', '1', 'entry', '25/01/2025', '1100', '1238456');
INSERT INTO `transactions` VALUES ('635', '9', 'exit', '25/01/2025', '260', '4595');
INSERT INTO `transactions` VALUES ('636', '1', 'entry', '25/01/2025', '350', '1239556');
INSERT INTO `transactions` VALUES ('637', '1', 'entry', '25/01/2025', '1100', '1239906');
INSERT INTO `transactions` VALUES ('638', '1', 'exit', '25/01/2025', '50', '1241006');
INSERT INTO `transactions` VALUES ('639', '3', 'entry', '25/01/2025', '1', '15305');
INSERT INTO `transactions` VALUES ('640', '1', 'exit', '25/01/2025', '7', '1240956');
INSERT INTO `transactions` VALUES ('641', '9', 'exit', '25/01/2025', '940', '4335');
INSERT INTO `transactions` VALUES ('642', '1', 'entry', '25/01/2025', '350', '1240949');
INSERT INTO `transactions` VALUES ('643', '1', 'entry', '25/01/2025', '1100', '1241299');
INSERT INTO `transactions` VALUES ('644', '1', 'entry', '25/01/2025', '1', '1242399');
INSERT INTO `transactions` VALUES ('645', '3', 'entry', '25/01/2025', '3500', '15306');
INSERT INTO `transactions` VALUES ('646', '1', 'entry', '25/01/2025', '3500', '1242400');
INSERT INTO `transactions` VALUES ('647', '12', 'entry', '25/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('648', '1', 'entry', '25/01/2025', '350', '1245900');
INSERT INTO `transactions` VALUES ('649', '1', 'entry', '25/01/2025', '1100', '1246250');
INSERT INTO `transactions` VALUES ('650', '1', 'entry', '25/01/2025', '1', '1247350');
INSERT INTO `transactions` VALUES ('651', '1', 'entry', '25/01/2025', '3500', '1247351');
INSERT INTO `transactions` VALUES ('652', '2', 'exit', '25/01/2025', '50', '5008');
INSERT INTO `transactions` VALUES ('653', '2', 'exit', '25/01/2025', '50', '4958');
INSERT INTO `transactions` VALUES ('654', '2', 'exit', '25/01/2025', '50', '4908');
INSERT INTO `transactions` VALUES ('655', '2', 'exit', '25/01/2025', '50', '4858');
INSERT INTO `transactions` VALUES ('656', '2', 'exit', '25/01/2025', '50', '4808');
INSERT INTO `transactions` VALUES ('657', '1', 'entry', '25/01/2025', '350', '1250851');
INSERT INTO `transactions` VALUES ('658', '1', 'entry', '25/01/2025', '1100', '1251201');
INSERT INTO `transactions` VALUES ('659', '2', 'exit', '25/01/2025', '50', '4758');
INSERT INTO `transactions` VALUES ('660', '1', 'entry', '25/01/2025', '1', '1252301');
INSERT INTO `transactions` VALUES ('661', '1', 'entry', '25/01/2025', '3500', '1252302');
INSERT INTO `transactions` VALUES ('662', '1', 'entry', '25/01/2025', '350', '1255802');
INSERT INTO `transactions` VALUES ('663', '2', 'entry', '25/01/2025', '1', '4708');
INSERT INTO `transactions` VALUES ('664', '1', 'entry', '25/01/2025', '1100', '1256152');
INSERT INTO `transactions` VALUES ('665', '1', 'entry', '25/01/2025', '1', '1257252');
INSERT INTO `transactions` VALUES ('666', '1', 'entry', '25/01/2025', '3500', '1257253');
INSERT INTO `transactions` VALUES ('667', '1', 'entry', '25/01/2025', '350', '1260753');
INSERT INTO `transactions` VALUES ('668', '2', 'entry', '25/01/2025', '1', '4709');
INSERT INTO `transactions` VALUES ('669', '1', 'entry', '25/01/2025', '1100', '1261103');
INSERT INTO `transactions` VALUES ('670', '2', 'entry', '25/01/2025', '1', '4710');
INSERT INTO `transactions` VALUES ('671', '9', 'entry', '25/01/2025', '1', '3395');
INSERT INTO `transactions` VALUES ('672', '1', 'entry', '25/01/2025', '350', '1262203');
INSERT INTO `transactions` VALUES ('673', '1', 'entry', '25/01/2025', '1100', '1262553');
INSERT INTO `transactions` VALUES ('674', '1', 'entry', '25/01/2025', '3500', '1263653');
INSERT INTO `transactions` VALUES ('675', '1', 'entry', '25/01/2025', '1', '1267153');
INSERT INTO `transactions` VALUES ('676', '2', 'exit', '25/01/2025', '10', '4711');
INSERT INTO `transactions` VALUES ('677', '2', 'exit', '25/01/2025', '10', '4701');
INSERT INTO `transactions` VALUES ('678', '2', 'exit', '25/01/2025', '10', '4691');
INSERT INTO `transactions` VALUES ('679', '2', 'exit', '25/01/2025', '10', '4681');
INSERT INTO `transactions` VALUES ('680', '2', 'exit', '25/01/2025', '10', '4671');
INSERT INTO `transactions` VALUES ('681', '2', 'exit', '25/01/2025', '2185', '4661');
INSERT INTO `transactions` VALUES ('682', '9', 'exit', '25/01/2025', '250', '3396');
INSERT INTO `transactions` VALUES ('683', '6', 'exit', '25/01/2025', '750', '100805');
INSERT INTO `transactions` VALUES ('684', '1', 'entry', '25/01/2025', '1100', '1267154');
INSERT INTO `transactions` VALUES ('685', '1', 'entry', '25/01/2025', '350', '1268254');
INSERT INTO `transactions` VALUES ('686', '1', 'entry', '25/01/2025', '3500', '1268604');
INSERT INTO `transactions` VALUES ('687', '13', 'entry', '26/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('688', '1', 'entry', '26/01/2025', '1100', '1272104');
INSERT INTO `transactions` VALUES ('689', '1', 'entry', '26/01/2025', '350', '1273204');
INSERT INTO `transactions` VALUES ('690', '1', 'entry', '26/01/2025', '3500', '1273554');
INSERT INTO `transactions` VALUES ('691', '1', 'entry', '26/01/2025', '1', '1277054');
INSERT INTO `transactions` VALUES ('692', '1', 'entry', '26/01/2025', '1100', '1277055');
INSERT INTO `transactions` VALUES ('693', '1', 'entry', '26/01/2025', '350', '1278155');
INSERT INTO `transactions` VALUES ('694', '1', 'entry', '26/01/2025', '3500', '1278505');
INSERT INTO `transactions` VALUES ('695', '14', 'entry', '26/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('696', '10', 'exit', '26/01/2025', '250', '5003');
INSERT INTO `transactions` VALUES ('697', '9', 'exit', '26/01/2025', '400', '3146');
INSERT INTO `transactions` VALUES ('698', '14', 'entry', '26/01/2025', '1', '5000');
INSERT INTO `transactions` VALUES ('699', '13', 'entry', '26/01/2025', '1', '5000');
INSERT INTO `transactions` VALUES ('700', '9', 'entry', '26/01/2025', '1', '2746');
INSERT INTO `transactions` VALUES ('701', '10', 'entry', '26/01/2025', '1', '4753');
INSERT INTO `transactions` VALUES ('702', '1', 'entry', '26/01/2025', '350', '1282005');
INSERT INTO `transactions` VALUES ('703', '1', 'entry', '26/01/2025', '1100', '1282355');
INSERT INTO `transactions` VALUES ('704', '1', 'entry', '26/01/2025', '3500', '1283455');
INSERT INTO `transactions` VALUES ('705', '4', 'exit', '26/01/2025', '500', '9839417');
INSERT INTO `transactions` VALUES ('706', '4', 'entry', '26/01/2025', '1000000', '9838917');
INSERT INTO `transactions` VALUES ('707', '4', 'entry', '26/01/2025', '800000', '10838917');
INSERT INTO `transactions` VALUES ('708', '4', 'entry', '26/01/2025', '800000', '11638917');
INSERT INTO `transactions` VALUES ('709', '4', 'entry', '26/01/2025', '800000', '12438917');
INSERT INTO `transactions` VALUES ('710', '4', 'entry', '26/01/2025', '800000', '13238917');
INSERT INTO `transactions` VALUES ('711', '4', 'entry', '26/01/2025', '800000', '14038917');
INSERT INTO `transactions` VALUES ('712', '4', 'entry', '26/01/2025', '800000', '14838917');
INSERT INTO `transactions` VALUES ('713', '4', 'entry', '26/01/2025', '800000', '15638917');
INSERT INTO `transactions` VALUES ('714', '4', 'entry', '26/01/2025', '800000', '16438917');
INSERT INTO `transactions` VALUES ('715', '4', 'entry', '26/01/2025', '800000', '17238917');
INSERT INTO `transactions` VALUES ('716', '4', 'entry', '26/01/2025', '800000', '18038917');
INSERT INTO `transactions` VALUES ('717', '4', 'entry', '26/01/2025', '800000', '18838917');
INSERT INTO `transactions` VALUES ('718', '4', 'entry', '26/01/2025', '1', '19638917');
INSERT INTO `transactions` VALUES ('719', '13', 'exit', '26/01/2025', '950', '5001');
INSERT INTO `transactions` VALUES ('720', '13', 'exit', '26/01/2025', '400', '4051');
INSERT INTO `transactions` VALUES ('721', '1', 'entry', '26/01/2025', '350', '1286955');
INSERT INTO `transactions` VALUES ('722', '1', 'entry', '26/01/2025', '1100', '1287305');
INSERT INTO `transactions` VALUES ('723', '1', 'entry', '26/01/2025', '3500', '1288405');
INSERT INTO `transactions` VALUES ('724', '1', 'entry', '26/01/2025', '350', '1291905');
INSERT INTO `transactions` VALUES ('725', '1', 'entry', '26/01/2025', '1100', '1292255');
INSERT INTO `transactions` VALUES ('726', '1', 'entry', '26/01/2025', '3500', '1293355');
INSERT INTO `transactions` VALUES ('727', '10', 'entry', '26/01/2025', '1296855', '4754');
INSERT INTO `transactions` VALUES ('728', '1', 'exit', '26/01/2025', '1296855', '1296855');
INSERT INTO `transactions` VALUES ('729', '10', 'exit', '26/01/2025', '1301609', '1301609');
INSERT INTO `transactions` VALUES ('730', '1', 'entry', '26/01/2025', '350', '0');
INSERT INTO `transactions` VALUES ('731', '1', 'entry', '26/01/2025', '1100', '350');
INSERT INTO `transactions` VALUES ('732', '1', 'entry', '26/01/2025', '3500', '1450');
INSERT INTO `transactions` VALUES ('733', '10', 'entry', '26/01/2025', '1', '0');
INSERT INTO `transactions` VALUES ('734', '1', 'entry', '26/01/2025', '1', '4950');
INSERT INTO `transactions` VALUES ('735', '1', 'entry', '26/01/2025', '350', '4951');
INSERT INTO `transactions` VALUES ('736', '1', 'entry', '26/01/2025', '1100', '5301');
INSERT INTO `transactions` VALUES ('737', '1', 'entry', '26/01/2025', '3500', '6401');
INSERT INTO `transactions` VALUES ('738', '1', 'entry', '26/01/2025', '1', '9901');
INSERT INTO `transactions` VALUES ('739', '1', 'entry', '26/01/2025', '350', '9902');
INSERT INTO `transactions` VALUES ('740', '1', 'entry', '26/01/2025', '1100', '10252');
INSERT INTO `transactions` VALUES ('741', '1', 'entry', '26/01/2025', '3500', '11352');
INSERT INTO `transactions` VALUES ('742', '1', 'entry', '27/01/2025', '1100', '14852');
INSERT INTO `transactions` VALUES ('743', '1', 'entry', '27/01/2025', '3500', '15952');
INSERT INTO `transactions` VALUES ('744', '1', 'entry', '27/01/2025', '350', '19452');
INSERT INTO `transactions` VALUES ('745', '1', 'entry', '27/01/2025', '3500', '19802');
INSERT INTO `transactions` VALUES ('746', '1', 'entry', '27/01/2025', '1100', '23302');
INSERT INTO `transactions` VALUES ('747', '1', 'entry', '27/01/2025', '3500', '24402');
INSERT INTO `transactions` VALUES ('748', '1', 'entry', '27/01/2025', '350', '27902');
INSERT INTO `transactions` VALUES ('749', '1', 'entry', '27/01/2025', '3500', '28252');
INSERT INTO `transactions` VALUES ('750', '1', 'entry', '27/01/2025', '3500', '31752');
INSERT INTO `transactions` VALUES ('751', '1', 'entry', '27/01/2025', '3500', '35252');
INSERT INTO `transactions` VALUES ('752', '1', 'entry', '27/01/2025', '1100', '38752');
INSERT INTO `transactions` VALUES ('753', '1', 'entry', '27/01/2025', '350', '39852');
INSERT INTO `transactions` VALUES ('754', '1', 'entry', '27/01/2025', '3500', '40202');
INSERT INTO `transactions` VALUES ('755', '1', 'entry', '27/01/2025', '3500', '43702');
INSERT INTO `transactions` VALUES ('756', '1', 'entry', '27/01/2025', '1100', '47202');
INSERT INTO `transactions` VALUES ('757', '1', 'entry', '27/01/2025', '350', '48302');
INSERT INTO `transactions` VALUES ('758', '1', 'entry', '27/01/2025', '3500', '48652');
INSERT INTO `transactions` VALUES ('759', '1', 'entry', '27/01/2025', '3500', '52152');
INSERT INTO `transactions` VALUES ('760', '1', 'entry', '27/01/2025', '1100', '55652');
INSERT INTO `transactions` VALUES ('761', '1', 'entry', '27/01/2025', '350', '56752');
INSERT INTO `transactions` VALUES ('762', '1', 'entry', '27/01/2025', '3500', '57102');
INSERT INTO `transactions` VALUES ('763', '1', 'entry', '27/01/2025', '3500', '60602');
INSERT INTO `transactions` VALUES ('764', '1', 'entry', '27/01/2025', '1100', '64102');
INSERT INTO `transactions` VALUES ('765', '1', 'entry', '27/01/2025', '350', '65202');
INSERT INTO `transactions` VALUES ('766', '1', 'entry', '27/01/2025', '3500', '65552');
INSERT INTO `transactions` VALUES ('767', '1', 'entry', '27/01/2025', '3500', '69052');
INSERT INTO `transactions` VALUES ('768', '1', 'entry', '27/01/2025', '1100', '72552');
INSERT INTO `transactions` VALUES ('769', '1', 'entry', '27/01/2025', '350', '73652');
INSERT INTO `transactions` VALUES ('770', '1', 'entry', '28/01/2025', '1100', '74002');
INSERT INTO `transactions` VALUES ('771', '1', 'entry', '28/01/2025', '350', '75102');
INSERT INTO `transactions` VALUES ('772', '1', 'entry', '28/01/2025', '3500', '75452');
INSERT INTO `transactions` VALUES ('773', '1', 'entry', '28/01/2025', '3500', '78952');
INSERT INTO `transactions` VALUES ('774', '1', 'entry', '28/01/2025', '350', '82452');
INSERT INTO `transactions` VALUES ('775', '1', 'entry', '28/01/2025', '1100', '82802');
INSERT INTO `transactions` VALUES ('776', '1', 'entry', '28/01/2025', '3500', '83902');
INSERT INTO `transactions` VALUES ('777', '1', 'entry', '28/01/2025', '3500', '87402');
INSERT INTO `transactions` VALUES ('778', '1', 'entry', '28/01/2025', '1', '90902');
INSERT INTO `transactions` VALUES ('779', '1', 'entry', '28/01/2025', '350', '90903');
INSERT INTO `transactions` VALUES ('780', '1', 'entry', '28/01/2025', '1100', '91253');
INSERT INTO `transactions` VALUES ('781', '1', 'entry', '28/01/2025', '3500', '92353');
INSERT INTO `transactions` VALUES ('782', '1', 'entry', '28/01/2025', '3500', '95853');
INSERT INTO `transactions` VALUES ('783', '1', 'entry', '28/01/2025', '350', '99353');
INSERT INTO `transactions` VALUES ('784', '1', 'entry', '28/01/2025', '3500', '99703');
INSERT INTO `transactions` VALUES ('785', '1', 'entry', '28/01/2025', '1100', '103203');
INSERT INTO `transactions` VALUES ('786', '1', 'entry', '28/01/2025', '3500', '104303');
INSERT INTO `transactions` VALUES ('787', '1', 'entry', '28/01/2025', '3500', '107803');
INSERT INTO `transactions` VALUES ('788', '1', 'entry', '28/01/2025', '350', '111303');
INSERT INTO `transactions` VALUES ('789', '1', 'entry', '28/01/2025', '3500', '111653');
INSERT INTO `transactions` VALUES ('790', '1', 'entry', '28/01/2025', '1100', '115153');
INSERT INTO `transactions` VALUES ('791', '8', 'exit', '28/01/2025', '90', '3347');
INSERT INTO `transactions` VALUES ('792', '8', 'exit', '28/01/2025', '135', '3257');
INSERT INTO `transactions` VALUES ('793', '8', 'exit', '28/01/2025', '45', '3122');
INSERT INTO `transactions` VALUES ('794', '8', 'exit', '28/01/2025', '225', '3077');
INSERT INTO `transactions` VALUES ('795', '8', 'exit', '28/01/2025', '225', '2852');
INSERT INTO `transactions` VALUES ('796', '8', 'exit', '28/01/2025', '25', '2627');
INSERT INTO `transactions` VALUES ('797', '1', 'entry', '28/01/2025', '3500', '116253');
INSERT INTO `transactions` VALUES ('798', '1', 'entry', '28/01/2025', '1100', '119753');
INSERT INTO `transactions` VALUES ('799', '1', 'entry', '28/01/2025', '350', '120853');
INSERT INTO `transactions` VALUES ('800', '1', 'entry', '28/01/2025', '3500', '121203');
INSERT INTO `transactions` VALUES ('801', '1', 'entry', '28/01/2025', '3500', '124703');
INSERT INTO `transactions` VALUES ('802', '1', 'entry', '28/01/2025', '1100', '128203');
INSERT INTO `transactions` VALUES ('803', '1', 'entry', '28/01/2025', '350', '129303');
INSERT INTO `transactions` VALUES ('804', '1', 'entry', '28/01/2025', '3500', '129653');
INSERT INTO `transactions` VALUES ('805', '1', 'entry', '28/01/2025', '3500', '133153');
INSERT INTO `transactions` VALUES ('806', '1', 'entry', '28/01/2025', '3500', '136653');
INSERT INTO `transactions` VALUES ('807', '1', 'entry', '28/01/2025', '1100', '140153');
INSERT INTO `transactions` VALUES ('808', '1', 'entry', '28/01/2025', '350', '141253');
INSERT INTO `transactions` VALUES ('809', '1', 'entry', '28/01/2025', '1', '141603');
INSERT INTO `transactions` VALUES ('810', '1', 'entry', '28/01/2025', '3500', '141604');
INSERT INTO `transactions` VALUES ('811', '1', 'entry', '28/01/2025', '3500', '145104');
INSERT INTO `transactions` VALUES ('812', '1', 'entry', '28/01/2025', '1100', '148604');
INSERT INTO `transactions` VALUES ('813', '1', 'entry', '28/01/2025', '350', '149704');
INSERT INTO `transactions` VALUES ('814', '1', 'entry', '28/01/2025', '1', '150054');
INSERT INTO `transactions` VALUES ('815', '1', 'entry', '28/01/2025', '3500', '150055');
INSERT INTO `transactions` VALUES ('816', '1', 'entry', '28/01/2025', '3500', '153555');
INSERT INTO `transactions` VALUES ('817', '1', 'entry', '28/01/2025', '1100', '157055');
INSERT INTO `transactions` VALUES ('818', '1', 'entry', '28/01/2025', '350', '158155');
INSERT INTO `transactions` VALUES ('819', '1', 'entry', '28/01/2025', '1', '158505');
INSERT INTO `transactions` VALUES ('820', '1', 'entry', '28/01/2025', '3500', '158506');
INSERT INTO `transactions` VALUES ('821', '1', 'entry', '28/01/2025', '3500', '162006');
INSERT INTO `transactions` VALUES ('822', '1', 'entry', '28/01/2025', '1100', '165506');
INSERT INTO `transactions` VALUES ('823', '1', 'entry', '28/01/2025', '350', '166606');
INSERT INTO `transactions` VALUES ('824', '1', 'entry', '28/01/2025', '1', '166956');
INSERT INTO `transactions` VALUES ('825', '15', 'entry', '28/01/2025', '5000', '0');
INSERT INTO `transactions` VALUES ('826', '1', 'entry', '28/01/2025', '3500', '166957');
INSERT INTO `transactions` VALUES ('827', '1', 'entry', '28/01/2025', '3500', '170457');
INSERT INTO `transactions` VALUES ('828', '1', 'entry', '28/01/2025', '1100', '173957');
INSERT INTO `transactions` VALUES ('829', '1', 'entry', '28/01/2025', '350', '175057');
INSERT INTO `transactions` VALUES ('830', '6', 'exit', '28/01/2025', '400', '100055');
INSERT INTO `transactions` VALUES ('831', '3', 'exit', '28/01/2025', '373', '18806');
INSERT INTO `transactions` VALUES ('832', '1', 'entry', '28/01/2025', '1', '175407');
INSERT INTO `transactions` VALUES ('833', '1', 'entry', '29/01/2025', '3500', '175408');
INSERT INTO `transactions` VALUES ('834', '1', 'entry', '29/01/2025', '3500', '178908');
INSERT INTO `transactions` VALUES ('835', '1', 'entry', '29/01/2025', '1100', '182408');
INSERT INTO `transactions` VALUES ('836', '1', 'entry', '29/01/2025', '350', '183508');
INSERT INTO `transactions` VALUES ('837', '1', 'entry', '29/01/2025', '1', '183858');
INSERT INTO `transactions` VALUES ('838', '6', 'exit', '29/01/2025', '1000', '99655');
INSERT INTO `transactions` VALUES ('839', '8', 'entry', '29/01/2025', '1', '2602');
INSERT INTO `transactions` VALUES ('840', '6', 'entry', '29/01/2025', '1', '98655');
INSERT INTO `transactions` VALUES ('841', '15', 'exit', '29/01/2025', '400', '5000');
INSERT INTO `transactions` VALUES ('842', '8', 'entry', '29/01/2025', '1', '2603');
INSERT INTO `transactions` VALUES ('843', '6', 'entry', '29/01/2025', '1', '98656');
INSERT INTO `transactions` VALUES ('844', '8', 'entry', '29/01/2025', '1', '2604');
INSERT INTO `transactions` VALUES ('845', '6', 'entry', '29/01/2025', '1', '98657');
INSERT INTO `transactions` VALUES ('846', '8', 'entry', '29/01/2025', '1', '2605');
INSERT INTO `transactions` VALUES ('847', '6', 'entry', '29/01/2025', '1', '98658');
INSERT INTO `transactions` VALUES ('848', '1', 'entry', '29/01/2025', '3500', '183859');
INSERT INTO `transactions` VALUES ('849', '1', 'entry', '29/01/2025', '3500', '187359');
INSERT INTO `transactions` VALUES ('850', '1', 'entry', '29/01/2025', '1100', '190859');
INSERT INTO `transactions` VALUES ('851', '1', 'entry', '29/01/2025', '350', '191959');
INSERT INTO `transactions` VALUES ('852', '8', 'entry', '29/01/2025', '1', '2606');
INSERT INTO `transactions` VALUES ('853', '1', 'entry', '29/01/2025', '1', '192309');
INSERT INTO `transactions` VALUES ('854', '6', 'entry', '29/01/2025', '1', '98659');
INSERT INTO `transactions` VALUES ('855', '1', 'entry', '29/01/2025', '3500', '192310');
INSERT INTO `transactions` VALUES ('856', '1', 'entry', '29/01/2025', '3500', '195810');
INSERT INTO `transactions` VALUES ('857', '1', 'entry', '29/01/2025', '1100', '199310');
INSERT INTO `transactions` VALUES ('858', '1', 'entry', '29/01/2025', '350', '200410');
INSERT INTO `transactions` VALUES ('859', '4', 'exit', '29/01/2025', '140', '19638918');
INSERT INTO `transactions` VALUES ('860', '4', 'exit', '29/01/2025', '40', '19638778');
INSERT INTO `transactions` VALUES ('861', '1', 'entry', '29/01/2025', '3500', '200760');
INSERT INTO `transactions` VALUES ('862', '1', 'entry', '29/01/2025', '3500', '204260');
INSERT INTO `transactions` VALUES ('863', '1', 'entry', '29/01/2025', '1100', '207760');
INSERT INTO `transactions` VALUES ('864', '1', 'entry', '29/01/2025', '350', '208860');
INSERT INTO `transactions` VALUES ('865', '4', 'exit', '29/01/2025', '100', '19638738');
INSERT INTO `transactions` VALUES ('866', '1', 'entry', '29/01/2025', '3500', '209210');
INSERT INTO `transactions` VALUES ('867', '1', 'entry', '29/01/2025', '3500', '212710');
INSERT INTO `transactions` VALUES ('868', '1', 'entry', '29/01/2025', '1100', '216210');
INSERT INTO `transactions` VALUES ('869', '1', 'entry', '29/01/2025', '350', '217310');
INSERT INTO `transactions` VALUES ('870', '1', 'entry', '29/01/2025', '1', '217660');
INSERT INTO `transactions` VALUES ('871', '1', 'entry', '29/01/2025', '3500', '217661');
INSERT INTO `transactions` VALUES ('872', '1', 'entry', '29/01/2025', '3500', '221161');
INSERT INTO `transactions` VALUES ('873', '1', 'entry', '29/01/2025', '1100', '224661');
INSERT INTO `transactions` VALUES ('874', '1', 'entry', '29/01/2025', '350', '225761');
INSERT INTO `transactions` VALUES ('875', '1', 'entry', '29/01/2025', '1', '226111');
INSERT INTO `transactions` VALUES ('876', '1', 'entry', '29/01/2025', '3500', '226112');
INSERT INTO `transactions` VALUES ('877', '1', 'entry', '29/01/2025', '3500', '229612');
INSERT INTO `transactions` VALUES ('878', '1', 'entry', '29/01/2025', '1100', '233112');
INSERT INTO `transactions` VALUES ('879', '1', 'entry', '29/01/2025', '350', '234212');
INSERT INTO `transactions` VALUES ('880', '1', 'entry', '29/01/2025', '1', '234562');
INSERT INTO `transactions` VALUES ('881', '1', 'entry', '29/01/2025', '3500', '234563');
INSERT INTO `transactions` VALUES ('882', '1', 'entry', '29/01/2025', '3500', '238063');
INSERT INTO `transactions` VALUES ('883', '1', 'entry', '29/01/2025', '1100', '241563');
INSERT INTO `transactions` VALUES ('884', '1', 'entry', '29/01/2025', '350', '242663');
INSERT INTO `transactions` VALUES ('885', '1', 'entry', '29/01/2025', '1', '243013');
INSERT INTO `transactions` VALUES ('886', '1', 'entry', '29/01/2025', '1100', '243014');
INSERT INTO `transactions` VALUES ('887', '1', 'entry', '29/01/2025', '3500', '244114');
INSERT INTO `transactions` VALUES ('888', '1', 'entry', '29/01/2025', '3500', '247614');
INSERT INTO `transactions` VALUES ('889', '1', 'entry', '29/01/2025', '350', '251114');
INSERT INTO `transactions` VALUES ('890', '1', 'entry', '29/01/2025', '3500', '251464');
INSERT INTO `transactions` VALUES ('891', '1', 'entry', '29/01/2025', '1100', '254964');
INSERT INTO `transactions` VALUES ('892', '1', 'entry', '29/01/2025', '350', '256064');
INSERT INTO `transactions` VALUES ('893', '1', 'entry', '29/01/2025', '3500', '256414');
INSERT INTO `transactions` VALUES ('894', '3', 'exit', '29/01/2025', '123', '18433');
INSERT INTO `transactions` VALUES ('895', '1', 'entry', '29/01/2025', '1', '259914');
INSERT INTO `transactions` VALUES ('896', '3', 'exit', '29/01/2025', '250', '18310');
INSERT INTO `transactions` VALUES ('897', '3', 'exit', '29/01/2025', '50', '18060');
INSERT INTO `transactions` VALUES ('898', '3', 'exit', '29/01/2025', '50', '18010');
INSERT INTO `transactions` VALUES ('899', '3', 'exit', '29/01/2025', '50', '17960');
INSERT INTO `transactions` VALUES ('900', '3', 'exit', '29/01/2025', '250', '17910');
INSERT INTO `transactions` VALUES ('901', '3', 'exit', '29/01/2025', '8', '17660');
INSERT INTO `transactions` VALUES ('902', '1', 'exit', '29/01/2025', '500', '259915');
INSERT INTO `transactions` VALUES ('903', '3', 'exit', '29/01/2025', '50', '17652');
INSERT INTO `transactions` VALUES ('904', '3', 'exit', '29/01/2025', '50', '17602');
INSERT INTO `transactions` VALUES ('905', '3', 'exit', '29/01/2025', '50', '17552');
INSERT INTO `transactions` VALUES ('906', '3', 'exit', '29/01/2025', '50', '17502');
INSERT INTO `transactions` VALUES ('907', '1', 'entry', '29/01/2025', '1100', '259415');
INSERT INTO `transactions` VALUES ('908', '1', 'entry', '29/01/2025', '350', '260515');
INSERT INTO `transactions` VALUES ('909', '1', 'entry', '29/01/2025', '3500', '260865');
INSERT INTO `transactions` VALUES ('910', '1', 'entry', '29/01/2025', '3500', '264365');

DROP TABLE IF EXISTS `vehicles`;
CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Passport` int(11) NOT NULL,
  `vehicle` varchar(100) NOT NULL,
  `tax` int(20) NOT NULL DEFAULT 0,
  `plate` varchar(10) DEFAULT NULL,
  `rental` int(20) NOT NULL DEFAULT 0,
  `arrest` int(20) NOT NULL DEFAULT 0,
  `engine` int(4) NOT NULL DEFAULT 1000,
  `body` int(4) NOT NULL DEFAULT 1000,
  `health` int(4) NOT NULL DEFAULT 1000,
  `fuel` int(3) NOT NULL DEFAULT 100,
  `nitro` int(5) NOT NULL DEFAULT 0,
  `work` varchar(5) NOT NULL DEFAULT 'false',
  `doors` longtext NOT NULL,
  `windows` longtext NOT NULL,
  `tyres` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Passport` (`Passport`),
  KEY `vehicle` (`vehicle`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `vehicles` VALUES ('1', '1', 'B412', '1740279492', '77OXM407', '0', '0', '981', '907', '907', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":1,"4":false,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('2', '1', 'polvic', '1737633176', '47BYZ305', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('3', '1', 'ambulance2', '1737633545', '69NBF384', '0', '0', '1000', '1000', '1000', '100', '2000', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('4', '1', 'samumav', '1737633817', '40UBO610', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('5', '1', 'maverick2', '1737637516', '86MSL649', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('6', '1', 'bmwm3', '1737641361', '44CZV790', '0', '0', '1000', '1000', '1000', '100', '2000', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('8', '1', 'bmwm5', '1737641378', '40BNF050', '0', '0', '1000', '1000', '1000', '65', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('9', '1', 'e63', '1737641386', '89NHL472', '0', '0', '1000', '1000', '1000', '99', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('10', '1', 'jettagli', '1737641393', '02ZQB700', '0', '0', '971', '968', '968', '100', '2000', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('11', '1', 'tiger900', '1737641402', '82OOF350', '0', '0', '988', '873', '986', '65', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('12', '1', 'tundra', '1737641411', '34AOE055', '0', '0', '972', '969', '969', '80', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('13', '2', 'bmwm3', '1737641626', '65TYM321', '0', '0', '913', '903', '903', '73', '393', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('14', '2', 'm4cs', '1737641699', '61VBE360', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('15', '2', 'e63', '1737642241', '79MEA656', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('17', '1', 'm4cs', '1737647128', '05MSV533', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('18', '1', '2f2fgtr34', '1740447610', '81OER012', '0', '0', '1000', '1000', '1000', '61', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('19', '1', '370zrubytiger', '1740447610', '82WFJ345', '0', '0', '1000', '990', '998', '80', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('20', '1', '160', '1740447610', '57CVX704', '1739652225', '0', '1000', '1000', '1000', '65', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('21', '1', 'cbhornet750', '1740447610', '42KUC489', '1739652230', '0', '1000', '1000', '1000', '65', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('22', '1', 'celta', '1740447610', '96NEW563', '1739652258', '0', '1000', '1000', '1000', '100', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('23', '1', 'hornet12', '1740447610', '41BTO099', '1739652293', '0', '772', '797', '797', '65', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('24', '1', 'g7cross', '1740447610', '42PEY253', '1739652343', '0', '1000', '1000', '1000', '65', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('25', '1', 'xreagstore', '1740447610', '42DTY722', '1739652377', '0', '493', '427', '371', '94', '2000', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":true,"7":false,"0":true}');
INSERT INTO `vehicles` VALUES ('26', '2', 'a45amg', '1737671592', '50MIH427', '1737671592', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('27', '3', 'bmwm5', '1737679064', '53VXJ356', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('28', '2', 'B412', '1737726349', '77TCC151', '0', '0', '967', '891', '890', '97', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('29', '2', 'WRtrailblazer22', '1740329458', '08DPV894', '0', '0', '950', '944', '361', '81', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":true,"2":true,"3":true,"4":true,"5":true,"6":true,"7":true,"0":true}');
INSERT INTO `vehicles` VALUES ('30', '2', 'wrmustang', '1740329437', '05NKG379', '0', '0', '986', '985', '985', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('31', '1', 'wrmustang', '1737733921', '17YTR754', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('32', '1', 'WRranger23', '1737733935', '95RNE510', '0', '0', '1000', '999', '999', '100', '2000', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('33', '1', 'WRtrailblazer22', '1740344350', '28FSU671', '0', '0', '756', '729', '729', '100', '1656', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('34', '1', 'WRr1200', '1737733954', '95JEG160', '0', '0', '1000', '1000', '1000', '65', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('35', '2', 'WRr1200', '1740329470', '04KNV571', '0', '0', '998', '998', '998', '98', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('36', '1', 'wrm5', '1737739964', '83MVC836', '0', '0', '1000', '1000', '1000', '65', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('37', '1', 'WRduster22', '1737739969', '41TIY732', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('38', '1', 'WRspeedoems', '1737755514', '64TBK949', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('39', '2', 'WRranger23', '1740424760', '29KDL728', '0', '0', '920', '100', '0', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('40', '2', 'wrm5', '1740424788', '17MTQ344', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":false}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('41', '2', 'WRduster22', '1740424812', '51XSA076', '0', '0', '1000', '997', '997', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('45', '1', 'WRcorollanew', '1737816349', '76BJD094', '0', '0', '1000', '820', '820', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('46', '1', 'wrimpala', '1737816358', '30TTU303', '0', '0', '1000', '801', '970', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('47', '1', 'WRc7', '1737816369', '01AKC026', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('48', '2', 'WRc7', '1740424799', '50WHM453', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('49', '2', 'WRcorollanew', '1740424824', '82GBZ374', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('50', '1', 'wrbuspol', '1737818495', '75IYH705', '0', '0', '1000', '1000', '1000', '91', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('51', '6', 'r1', '1737861327', '92FVB222', '1737861327', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('52', '1', 'energyr1200samu', '1737863340', '17RYT448', '0', '0', '1000', '853', '989', '65', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('53', '1', 'WRsprinter22', '1737863346', '66MIT231', '0', '0', '1000', '1000', '1000', '97', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('54', '1', 'wrx6mf96', '1737863357', '02ZKC923', '0', '0', '100', '100', '0', '65', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":false}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('55', '1', 'WRpolmav', '1737863447', '31BOO427', '0', '0', '1000', '1000', '1000', '97', '2000', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('56', '3', 'WRc7', '1737868612', '46TGR401', '0', '0', '1000', '1000', '999', '81', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":true,"7":false,"0":true}');
INSERT INTO `vehicles` VALUES ('57', '3', 'WRcorollanew', '1737868658', '85GYF403', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('58', '3', 'wrmustang', '1737868710', '74IBL748', '0', '0', '998', '998', '998', '95', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('59', '3', 'wrimpala', '1737868782', '95KJS999', '0', '0', '969', '965', '965', '99', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('60', '3', 'wrbuspol', '1737868889', '39UQU772', '0', '0', '1000', '1000', '1000', '99', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('61', '3', 'B412', '1737868955', '74LRX899', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('62', '9', 'a45amg', '1737869273', '65KHH848', '1737869273', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('63', '9', 'B412', '1737869694', '18QYJ438', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('64', '6', 'energyr1200samu', '1737870774', '23SQD760', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('65', '6', 'WRpolmav', '1737872765', '20MNE537', '0', '0', '1000', '1000', '1000', '99', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('66', '1', 'amarokeb', '1737925309', '94VKG303', '0', '0', '989', '982', '982', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":false}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('73', '1', 'HiluxSW4c', '1740607684', '57SQR785', '1739917623', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('82', '1', 'golfmk7', '1740607684', '02GOQ833', '1739918148', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('90', '1', 'motosamu', '1737984891', '85VIV311', '0', '0', '1000', '985', '1000', '65', '2000', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('91', '1', 'submersible', '1740607684', '76VCS219', '0', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('92', '6', 'motosamu', '1738006573', '32QDM743', '0', '0', '1000', '1000', '1000', '65', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('98', '1', 'taxi', '1738023965', '32NCY064', '0', '0', '1000', '945', '1000', '63', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('99', '5', 'rr14', '1738032233', '44VFB248', '1738032233', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('106', '2', 'wrimpala', '1738088016', '45LLX350', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('107', '2', 'wrbuspol', '1738088071', '62AVD100', '0', '0', '983', '829', '829', '93', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('108', '3', 'energyr1200samu', '1738112258', '21ART275', '0', '0', '997', '997', '997', '98', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('109', '3', 'WRsprinter22', '1738112330', '50XRW313', '0', '0', '1000', '1000', '1000', '99', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('110', '3', 'wrx6mf96', '1738112378', '50TZN061', '0', '0', '998', '998', '998', '97', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('111', '3', 'amarokeb', '1738112455', '57KJU339', '0', '0', '996', '996', '996', '98', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('112', '3', 'motosamu', '1738112523', '46TUW001', '0', '0', '1000', '1000', '1000', '98', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('113', '1', 'rcbandito', '1740722065', '39DWA613', '0', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('114', '9', 'WRtrailblazer22', '1738292432', '24WDA756', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('115', '1', 'wrforduber', '1738298457', '51KSE462', '0', '0', '990', '990', '990', '76', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('116', '3', 'wrforduber', '1738336022', '45CQR861', '0', '0', '1000', '1000', '999', '84', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":true,"7":false,"0":true}');
INSERT INTO `vehicles` VALUES ('117', '2', 'wrforduber', '1738336725', '51MEK084', '0', '0', '973', '977', '977', '95', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":false}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('118', '6', 'wrx6mf96', '1738351213', '29LFG161', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('119', '6', 'wrforduber', '1738351322', '22HZS928', '0', '0', '701', '744', '771', '37', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('120', '8', 'r1', '1738356130', '83EJB754', '1738356130', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('121', '10', 'r1', '1738368452', '87FWF869', '1738368452', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('129', '2', 'WRa45', '1738431375', '29QXT224', '0', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('130', '2', 'nimbus', '1738431554', '90FAS723', '0', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('131', '2', 'seabreeze', '1738431608', '61RAP346', '0', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('132', '12', 'a45amg', '1738432085', '10HSO165', '1738432085', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('133', '9', 'WRranger23', '1738435490', '16KFZ870', '0', '0', '928', '820', '820', '80', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('134', '1', 'civictyper', '1738460398', '18XZX334', '1740447598', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('135', '9', 'phantom2', '1738468002', '09CAW418', '0', '0', '979', '976', '976', '98', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('140', '4', 'urusd', '1738469378', '13CTJ467', '1740456578', '0', '947', '951', '951', '96', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":1,"5":false,"0":false}', '{"1":false,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('142', '4', 'civictyper', '1738469423', '88SHT757', '1740456623', '0', '999', '999', '999', '97', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":1,"5":1,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('143', '4', 'mustangeleanor', '1738470534', '77DEX567', '1740457734', '0', '1000', '1000', '1000', '94', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('144', '10', 'wrmustang', '1738476292', '11YBL154', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('145', '10', 'WRranger23', '1738476814', '85BRE892', '0', '0', '899', '888', '888', '98', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('146', '10', 'WRtrailblazer22', '1738476821', '87AKO900', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('147', '10', 'WRr1200', '1738476830', '24QQP442', '0', '0', '1000', '1000', '1000', '65', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":true,"2":true,"3":true,"4":false,"5":true,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('148', '10', 'hauler', '1738545304', '10IKH971', '0', '0', '1000', '1000', '1000', '99', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('149', '10', 'wrbuspol', '1738547246', '69QHG481', '0', '0', '1000', '1000', '1000', '99', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('150', '10', 'phantom', '1738609062', '93ZXT207', '0', '0', '1000', '1000', '1000', '98', '2000', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('151', '1', 'hauler', '1738609082', '78KUU199', '0', '0', '985', '984', '984', '99', '2000', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('152', '10', 'packer', '1738610374', '07POS832', '0', '0', '1000', '1000', '1000', '65', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('153', '10', 'wrforduber', '1738612230', '10IEY109', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('154', '1', 'boxville2', '1738614566', '63QSR987', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('155', '10', 'boxville2', '1738614578', '06ZAI426', '0', '0', '846', '829', '829', '67', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":false}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('156', '15', 'rr14', '1738722220', '24FCY372', '1738722220', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('157', '6', 'jetmax', '1738723085', '79MAK496', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":false,"3":false,"4":false,"5":false,"0":1}', '{"1":true,"2":true,"3":true,"4":true,"5":true,"6":true,"7":true,"0":true}');
INSERT INTO `vehicles` VALUES ('158', '15', 'vigilante', '1738724201', '21TIB484', '0', '0', '1000', '1000', '1000', '100', '0', 'false', '', '', '');
INSERT INTO `vehicles` VALUES ('159', '4', 'energyr1200samu', '1738734403', '99FIR239', '0', '0', '1000', '1000', '1000', '100', '0', 'true', '', '', '');
INSERT INTO `vehicles` VALUES ('160', '4', '350z', '1738734627', '64WUP495', '1740721827', '0', '945', '963', '963', '97', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":true,"2":true,"3":true,"4":true,"5":true,"6":true,"7":true,"0":true}');
INSERT INTO `vehicles` VALUES ('161', '3', 'locust', '1738778863', '0THIAGO0', '0', '0', '1000', '1000', '1000', '65', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('162', '3', 'sugoi', '1738779312', '91XSJ699', '0', '0', '1000', '1000', '1000', '60', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":1,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');
INSERT INTO `vehicles` VALUES ('163', '3', 'ferrariitalia', '1738779400', '73TTQ594', '1740766600', '0', '964', '961', '961', '97', '0', 'false', '{"1":false,"2":false,"3":false,"4":false,"5":false,"0":false}', '{"1":1,"2":1,"3":false,"4":false,"5":false,"0":1}', '{"1":false,"2":true,"3":true,"4":false,"5":false,"6":false,"7":false,"0":false}');

DROP TABLE IF EXISTS `vrp_properties`;
CREATE TABLE `vrp_properties` (
  `property_id` int(11) NOT NULL AUTO_INCREMENT,
  `property` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `owner` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tax` text CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT '{}',
  `information` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`property_id`,`property`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `warehouse`;
CREATE TABLE `warehouse` (
  `Number` int(20) NOT NULL,
  `Passport` int(10) NOT NULL DEFAULT 0,
  `Password` int(11) NOT NULL DEFAULT 0,
  `Tax` int(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Number`) USING BTREE,
  KEY `Passport` (`Passport`),
  KEY `id` (`Number`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `warrants`;
CREATE TABLE `warrants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` text DEFAULT NULL,
  `identity` text DEFAULT NULL,
  `status` text DEFAULT NULL,
  `nidentity` text DEFAULT NULL,
  `timeStamp` text DEFAULT NULL,
  `reason` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `portId` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

